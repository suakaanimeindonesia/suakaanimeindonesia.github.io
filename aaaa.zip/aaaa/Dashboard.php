<!DOCTYPE html>
<?php
$myfilepersegi = fopen("Hasil Persegi.txt", "r") or die("Unable to open file!");
$linepersegi = "";
while( !feof($myfilepersegi) ){
    $baris = fgets($myfilepersegi);
    $linepersegi=$linepersegi.$baris;
  }
$jumlahoperasipersegi = explode("<tr>",$linepersegi);


////

$myfilesegitiga = fopen("Hasil Segitiga.txt", "r") or die("Unable to open file!");
$linesegitiga = "";
while( !feof($myfilesegitiga) ){
    $baris = fgets($myfilesegitiga);
    $linesegitiga=$linesegitiga.$baris;
  }
$jumlahoperasisegitiga = explode("<tr>",$linesegitiga);


///

$myfilelingkaran = fopen("Hasil Lingkaran.txt", "r") or die("Unable to open file!");
$linelingkaran = "";
while( !feof($myfilelingkaran) ){
    $baris = fgets($myfilelingkaran);
    $linelingkaran=$linelingkaran.$baris;
  }
$jumlahoperasilingkaran = explode("<tr>",$linelingkaran);


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Jumlah total perhitungan sudah dilakukan :</h2>
    <div>Persegi : <?php echo count($jumlahoperasipersegi)-1; ?></div>
    <div>Segitiga :  <?php echo count($jumlahoperasisegitiga)-1; ?></div>
    <div>Lingkaran : <?php echo count($jumlahoperasilingkaran)-1; ?></div>
    <h2>Presentase Total Perhitungan :</h2>
</body>
</html>