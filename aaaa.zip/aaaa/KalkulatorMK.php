
<html>
<head>
  <title>Kalkulator Luas Bangun Datar</title>
</head>
<body>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 10px;
  height: auto;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>

<h1 style="text-align:center;">Kalkulator Luas Bangun Datar</h1>

<div class="row">

  <div class="column" style="background-color:#aaa; text-align:center;">
    <h2>Luas Persegi</h2>
    <?php
      if (isset($_POST["submit"])) {
        $operasi = $_POST["submit"];
        if($operasi=="persegi"){
          $sisi = $_POST["panjang"];
          $hasil = $sisi * $sisi;
          $myfile = fopen("Hasil Persegi.txt", "a") or die("Unable to open file!");
          $tanggalsekarang = date("Y/m/d");
          $jamsekarang = date("h:i:sa");
          $txt = "
              <tr>
              <td>$tanggalsekarang</td>
              <td>$jamsekarang</td>
              <td>$sisi</td>
              <td>$hasil</td>
              </tr>
              \n";
                      fwrite($myfile, $txt);
                      fclose($myfile);
                    }
  
        }
      
     ?>

  <style>
      table, th, td {border: 2px solid;}
  </style>
<div align="center">
  <table>
     <form method="post">
     <input type="hidden" name="submit" value="persegi">
      <tr>
          <td>Sisi </td><td><input type="number" name="panjang" value="<?php echo $panjang ?>"><br></td>
      </tr>
      <tr>
          <td>Luas  </td><td><input type="number" name="hasil" value="<?php echo $hasil ?>" readonly><br></td>
      </tr>
      <tr>
          <td><input type="reset" name="reset" value="Hapus"></td>   </td><td style="text-align:center;"><input type="submit" value="Hasil"><br></td>
      </tr>
     </form>
  </table>
</div>
<br>
<h2 style="text-align:center;">Hasil</h2>
<div align="center">
  <?php
    $myfile = fopen("Hasil Persegi.txt", "r") or die("Unable to open file!");
    echo "<table class=table table-striped>";
    echo "<tr>";
    echo "<th>Tanggal Simpan</th>";
    echo "<th>Jam Simpan</th>";
      echo "<th>Sisi</th>";
      echo "<th>Luas</th>";
      echo "</tr>";
    while( !feof($myfile) ){
      $baris = fgets($myfile);
      echo $baris;
    }
    echo "</table>";

  ?>
</div>
  </div>

  <div class="column" style="background-color:#bbb; text-align:center;">
    <h2>Luas Segitiga</h2>
    <?php
      if (isset($_POST["submit"])) {
        $operasi = $_POST["submit"];
        if($operasi=="segitiga"){
          $alas = $_POST["alas"];
          $tinggi = $_POST["tinggi"];
          $hasil = $alas * $tinggi / 2;
          $tanggalsekarang = date("Y/m/d");
          $jamsekarang = date("h:i:sa");
          $myfile = fopen("Hasil Segitiga.txt", "a") or die("Unable to open file!");
          $txt = "
          <tr>
          <td>$tanggalsekarang</td>
          <td>$jamsekarang</td>
          <td>$alas</td>
          <td>$tinggi</td>
          <td>$hasil</td>
          </tr>
          \n";
                  fwrite($myfile, $txt);
                  fclose($myfile);
                }
        }

     ?>

  <style>
      table, th, td {border: 2px solid;}
  </style>
<div align="center">
  <table>
     <form method="post">
      <input type="hidden" name="submit" value="segitiga">
      <tr>
          <td>Alas </td><td><input type="number" name="alas" value="<?php echo $alas ?>"><br></td>
      </tr>
      <tr>
          <td>Tinggi  </td><td><input type="number" name="tinggi" value="<?php echo $tinggi ?>"><br></td>
      </tr>
      <tr>
          <td>Luas  </td><td><input type="number" name="hasil" value="<?php echo $hasil ?>" readonly><br></td>
      </tr>
      <tr>
          <td><input type="reset" name="reset" value="Hapus"></td>   </td><td style="text-align:center;"><input type="submit" value="Hasil"><br></td>
      </tr>
     </form>
  </table>
</div>
<br>
<h2 style="text-align:center;">Hasil</h2>
<div align="center">
  <?php
    $myfile = fopen("Hasil Segitiga.txt", "r") or die("Unable to open file!");
    echo "<table class=table table-striped>";
    echo "<tr>";
    echo "<th>Tanggal Simpan</th>";
    echo "<th>Jam Simpan</th>";
      echo "<th>Alas</th>";
      echo "<th>Tinggi</th>";
      echo "<th>Luas</th>";
      echo "</tr>";
    while( !feof($myfile) ){
      $baris = fgets($myfile);
      echo $baris;
    }
    echo "</table>";

  ?>
</div>
  </div>

  <div class="column" style="background-color:#ccc; text-align:center;">
    <h2>Luas Lingkaran</h2>
    <?php
      if (isset($_POST["submit"])) {
        $operasi = $_POST["submit"];
        if($operasi=="lingkaran"){
          $rusuk = $_POST["rusuk"];
          $hasil = 3.14 * $rusuk * $rusuk;
          $myfile = fopen("Hasil Lingkaran.txt", "a") or die("Unable to open file!");
          $tanggalsekarang = date("Y/m/d");
          $jamsekarang = date("h:i:sa");
          $txt = "
  <tr>
  <td>$tanggalsekarang</td>
  <td>$jamsekarang</td>
  <td>$rusuk</td>
  <td>$hasil</td>
  </tr>
   \n";
          fwrite($myfile, $txt);
          fclose($myfile);
        }
        }

     ?>

  <style>
      table, th, td {border: 2px solid;}
  </style>
<div align="center">
  <table>
     <form method="post">
     <input type="hidden" name="submit" value="lingkaran">
      <tr>
          <td>Rusuk </td><td><input type="number" name="rusuk" value="<?php echo $rusuk ?>"><br></td>
      </tr>
      <tr>
          <td>Luas  </td><td><input type="number" name="hasil" value="<?php echo $hasil ?>" readonly><br></td>
      </tr>
      <tr>
          <td><input type="reset" name="reset" value="Hapus"></td>   </td><td style="text-align:center;"><input type="submit" value="Hasil"><br></td>
      </tr>
     </form>
  </table>
</div>
<br>
<h2 style="text-align:center;">Hasil</h2>
<div align="center">
  <?php
    $myfile = fopen("Hasil Lingkaran.txt", "r") or die("Unable to open file!");
    echo "<table class=table table-striped>";
    echo "<tr>";
    echo "<th>Tanggal Simpan</th>";
    echo "<th>Jam Simpan</th>";
      echo "<th>Rusuk</th>";
      echo "<th>Luas</th>";
      echo "</tr>";
    while( !feof($myfile) ){
      $baris = fgets($myfile);
      echo $baris;
    }
    echo "</table>";

  ?>
</div>
  </div>

</div>

</body>
</html>
