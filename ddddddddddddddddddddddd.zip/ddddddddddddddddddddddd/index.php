<?php 
    session_start();
  
?>
<!doctype html>
<html style="height:100%" lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=PT+Sans&display=swap" rel="stylesheet">
    <title>Hello, world!</title>
    <style>

    .disabled {
        pointer-events:none;
        opacity:0.5;
    }

    #navbartext{
        font-family: 'Bebas Neue';
       
    }

     #menupilihan:hover{
        background-color:#fee5e0;
    }

    #menupilihan {
        cursor:pointer;
        text-decoration:none;
        font-size:1.8em
    }

@media screen and (max-width: 1000px) {
   #gambar1 {
       display:none
   }
   #menupilihan {
       display:none
   }
}

   
    </style>
  </head>
  <body style="height:100%">
  <div style="height:100%">


 <div class="container-fluid" style="padding:20px;display:flex;flex-direction:row; justify-content:space-between;align-items:center;background-color: white;
    z-index: 99;
    position: fixed;
    box-shadow: #00000045 1px 1px 30px;">
        <div style="padding-left:20px;"><img style="width:3rem;height3rem" src="logo.png"></div>
        <div id="rightContainerNavbar" style="display:flex;flex-direction:row">

            <div id="navbartext" style="display:flex;flex-direction:row;align-items:center;margin-right:20px;">
                <div id="menupilihan" style="padding-right:50px;padding-left:50px;color:#1c1f4c">HOME</div>
                <div id="menupilihan" class="tombolcaridata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">CARI DATA</div>
                <div id="menupilihan" class="tomboleditdata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">EDIT DATA</div>
                <div id="menupilihan" class="tombolberisaran" style="padding-right:50px;padding-left:50px;color:#1c1f4c">BERI SARAN</div>
    
            </div>
            <img src="https://lippianfamilydentistry.net/wp-content/uploads/2015/11/user-default.png" id="avatar" style="cursor:pointer;background-color:#fee5e0;width:50px;height:50px;border-radius:50px"></img>
        </div>
        
       
    </div>

    <div style="height:100%">
         
    <div style="height:100%;align-items:center;justify-content:center;display:flex;padding-top:50px;">
        <div style="background-color:#fee5e0;width:100%;padding:40px;display:flex;flex-direction:row;justify-content:space-between">
            <div>
            <div style="font-size:4em;color:#1c1f4c;font-family: 'Bebas Neue', cursive;letter-spacing: 1px;">EFISIENSIKAN WAKTU <br> ANDA DENGAN <br>DANDAN</div>
            <div style="margin-top:5px;font-size:1.3em;color:#1c1f4c;font-family: 'PT Sans', sans-serif;">Cari, ubah dan tambah data Stakholder <br>Direktorat KND dalam waktu singkat!</div>
            
            
            </div>
            
      

            <div style="position:absolute;width:850px;height:700px;right:25px">
            <img id="gambar1" style=" display: block; max-width:850px;max-height:600px;width: auto;height: auto;margin-top:-128px" src="1.png">
            </div>
            
        </div>

     
    </div>

    </div>

 <div style="height:60%">
 <div style="height:100%;display:flex;align-items:center;padding:40px;">
       
       <div style="display:flex;justify-content:center;flex-direction:column">
                    <div style="font-size:3em;background-color:#b3dbda;font-family: 'Bebas Neue';padding-left:15px;padding-top:10px;">CARI DATA YANG ANDA BUTUHKAN</div>
                    <div  class="row" style="display:flex;flex-direction:row;margin-top:20px;">
                       <div><img style="width:350px;height:450px;" src="2.png"></div>
   
                       <div style="display:flex;flex-direction:column;margin-left:30px">
   
                           <div style="display:flex;flex-direction:row">
                           <input id="valuecaridata" type="text" style="width:400px;padding:5px;border: solid 2px #1c1f4c">
                           <div id="tombolcaridata" style="border: solid 2px #1c1f4c;border-left:solid 0px;padding-left:20px;padding-right:20px;align-items:center;justify-content:center;display:flex;background-color:#b3dbda;cursor:pointer">CARI</div>
                           </div>
   
                           <div style="margin-top:10px;">
                               <table id="tabelcaridata">
                                   <tr>
                                       <td style="width:200px;">Nama Stakholder</td>
                                       <td>:</td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Jenis</td>
                                       <td>:</td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Sektor</td>
                                       <td>:</td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Alamat Kantor</td>
                                       <td>:</td>
                                   </tr>
                        
                                   <tr>
                                       <td style="width:200px;">Nomor Telepon</td>
                                       <td>:</td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Nomor Faks</td>
                                       <td>:</td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Alamat Email</td>
                                       <td>:</td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Alamat Website</td>
                                       <td>:</td>
                                   </tr>
                               </table>
                           </div>
                       
                      </div>
   
                    </div>
                  
       </div>
    </div>

    

    <div style="height:130%;margin-bottom:500px;">
 <div style="height:100%;display:flex;align-items:center">
       
 <div style="display:flex;justify-content:center;flex-direction:column;width:100%">
                    <div style="font-size:3em;font-family: 'Bebas Neue';margin-left:20px;padding-top:10px;">LAPORKAN DATA YANG BELUM MUTAKHIR</div>
                    <div style="background-color:#fee5e0;width:100%;padding:20px;display:flex;flex-direction:column">
                        <div style="display:flex;flex-direction:row">
                        
                            <div style="display:flex;flex-direction:row;align-items:center"><input id="radiolapordata" type="radio" name="mode" value="rubah"><div style="margin-left:20px;">Perubahan Data</div></div>
                            <div style="display:flex;flex-direction:row;align-items:center;margin-left:25px;"><input id="radiolapordata" type="radio" name="mode" value="tambah"><div style="margin-left:20px;">Penambahan Data</div></div>
                         
                        </div>

                        <div>
                        <div style="display:flex;flex-direction:row;margin-top:20px;">
                           <input id="laporkandata" type="text" style="width:400px;padding:5px;border: solid 2px #1c1f4c">
                           <div id="klikcarilaporkandata" style="cursor:ponter;border: solid 2px #1c1f4c;border-left:solid 0px;padding-left:20px;padding-right:20px;align-items:center;justify-content:center;display:flex;background-color:white;cursor:pointer">CARI</div>
                           </div>
                        </div>

                    </div>
                   
                    <div style="display:flex;flex-direction:row;padding:20px;">
                        <div style="padding:20px;">
                        <table>
                                   <tr>
                                       <td style="width:200px;">Nama Stakholder</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Jenis</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Sektor</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Alamat Kantor</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                   </tr>
                                
                                   <tr>
                                       <td style="width:200px;">Nomor Telepon</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Nomor Faks</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Alamat Email</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                   </tr>
                                   <tr>
                                       <td style="width:200px;">Alamat Website</td>
                                       <td>: <input style="margin-left:15px;width:300px" type="text"></td>
                                       <td><div style="margin-left:10px;background-color:#ffbfc3;padding:5px;padding-left:10px;padding-right:10px;border:solid 2px #212529">KIRIM</div></td>
                                   </tr>
                               </table>
                        </div>
                        <div>
                            <img style="position:absolute;width:400px;height:500px;right:0px;margin-right: 80px;margin-top: -130px;" src="3.png">
                        </div>
                    </div>
</div>


                  
       </div>

<div style="height:90%;margin-bottom:50px;">
 <div style="height:100%;display:flex;align-items:center;padding:40px;">
       
       <div style="display:flex;justify-content:center;flex-direction:column">
            
                    <div  class="row" style="display:flex;flex-direction:row;margin-top:20px;">
                       <div><img style="width:350px;height:450px;" src="4.png"></div>
   
                       <div style="display:flex;flex-direction:column;margin-left:30px">
   
                           <div style="display:flex;flex-direction:row">
                           <div style="font-size:3em;background-color:#b3dbda;font-family: 'Bebas Neue';padding-left:15px;padding-top:10px;padding-right:15px">BERIKAN SARAN UNTUK DANDAN YANG LEBIH BAIK</div>
                           </div>
   
                           <div style="margin-top:25px;width:100%;height:100%;display:flex;flex-direction:column">
                                <textarea style="width:100%;height:100%"></textarea>
                                <div style="padding:10px;margin-top:10px;;background-color:#b3dbda;width:fit-content;border:solid 2px #212529">KIRIM</div>
                           </div>
                       
                      </div>
   
                    </div>
                  
       </div>
    </div>

    </div>

    
   <div style="background-color:white;box-shadow: #8e8e8e 2px 2px 10px;padding:10px;text-align:center"></div>
  
  </body>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script>
        document.querySelectorAll(".tombolcaridata")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 725,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tomboleditdata")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 1463,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tombolberisaran")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 2117,
            behavior: 'smooth',
            })
        })


        document.querySelectorAll("#klikcarilaporkandata")[0].addEventListener("click",(e)=>{
            <?php 
                     if(isset($_SESSION["user"])){
                        echo '
                        mode = "";
                        document.querySelectorAll("#radiolapordata").forEach((a)=>{(a.checked === true ) ? mode=a.value:""; });
                        alert(mode);
                        ';
                    }else{

                      }
            
            ?>
        })


        document.querySelectorAll("#tombolcaridata")[0].addEventListener('click',(e)=>{
            <?php 
                if(isset($_SESSION["user"])){
                    echo '
                        let query=document.querySelectorAll("#valuecaridata")[0].value;
                        if(query.length>0){
                            let xml=new XMLHttpRequest();
                            xml.open("POST","api.php",true);
                            xml.onload=function(ev){
                                e.target.classList.add("disabled");
                                if(ev.currentTarget.response==="null"){
                                    alert("Data tidak ditemukan!");
                                    e.target.classList.remove("disabled");
                                }else{
                                    let decode = JSON.parse(ev.currentTarget.response);
                                    console.log(decode);
                                    document.querySelectorAll("#tabelcaridata")[0].innerHTML=`
                                    <tr class="caristakholder" id="${decode.id_stakeholder}">
                                    <td style="width:200px;">Nama Stakholder</td>
                                    <td>: ${decode.nama_stakeholder}</td>
                                </tr>
                                <tr>
                                    <td style="width:200px;">Jenis</td>
                                    <td>: ${decode.jenis}</td>
                                </tr>
                                <tr>
                                    <td style="width:200px;">Sektor</td>
                                    <td>: ${decode.sektor}</td>
                                </tr>
                                <tr>
                                    <td style="width:200px;">Alamat Kantor</td>
                                    <td>: ${decode.alamat_kantor}</td>
                                </tr>
                     
                                <tr>
                                    <td style="width:200px;">Nomor Telepon</td>
                                    <td>: ${decode.nomor_telepon}</td>
                                </tr>
                                <tr>
                                    <td style="width:200px;">Nomor Faks</td>
                                    <td>: ${decode.nomor_faks}</td>
                                </tr>
                                <tr>
                                    <td style="width:200px;">Alamat Email</td>
                                    <td>: ${decode.alamat_email}</td>
                                </tr>
                                <tr>
                                    <td style="width:200px;">Alamat Website</td>
                                    <td>: ${decode.alamat_website}</td>
                                </tr>
                                    `;
                                    e.target.classList.remove("disabled");
                                }
                            };
                            xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                            xml.send(`aksi=caridata&nama=${query}`);
                        }else{
                            alert("Isi kueri pencarian!");
                        }
                    ';
                }else{
                    echo "alert('Silakan login terlebih dahulu!');";
                } 
            ?>
        })
    </script>
</html>