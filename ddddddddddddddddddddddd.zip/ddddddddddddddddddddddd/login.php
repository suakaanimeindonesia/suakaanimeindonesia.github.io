<?php
        session_start();


        if(isset($_SESSION["user"])){
            Header("Location: index.php");
        }

        include "koneksi.php";

        $error = array(
            "msg" => null,
            "err" => false
        );

        if(isset($_POST["login"])){
            if(strlen($_POST["email"])==0 || strlen($_POST["password"])==0){
                $error["msg"]="Masukkan email dan password!";
                $error["err"]=true;
            }else{  
                $email = $_POST["email"];
                $password = $_POST["password"];

                $hasil=$conn->query("SELECT * FROM user WHERE email='$email';");
                if($hasil->num_rows>0){
                     $h = $hasil->fetch_assoc();
                     if($email==$h["email"] && $password == $h["password"]){
                        $_SESSION["user"]=true;
                     }else{
                        $error["msg"]="Password yang dimasukkan salah!";
                        $error["err"]=true;
                     }
                }else{
                    $error["msg"]="Tidak ditemukan akun tersebut, silakan mendaftar!";
                    $error["err"]=true;
                }

            }
        }


    ?>


<!doctype html>
<html style="height:100%" lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=PT+Sans&display=swap" rel="stylesheet">
    <title>Hello, world!</title>
    <style>
    #navbartext{
        font-family: 'Bebas Neue';
       
    }

     #menupilihan:hover{
        background-color:#fee5e0;
    }

    #menupilihan {
        cursor:pointer;
        text-decoration:none;
        font-size:1.8em
    }

@media screen and (max-width: 1000px) {
   #gambar1 {
       display:none
   }
   #menupilihan {
       display:none
   }
}

   
    </style>
  </head>
  <body style="height:100%">
  <div style="height:100%">


 <div class="container-fluid" style="padding:20px;display:flex;flex-direction:row; justify-content:space-between;align-items:center;background-color: white;
    z-index: 99;
    position: fixed;
    box-shadow: #00000045 1px 1px 30px;">
        <div style="padding-left:20px;"><img style="width:3rem;height3rem" src="logo.png"></div>
        <div id="rightContainerNavbar" style="display:flex;flex-direction:row">

            <div id="navbartext" style="display:flex;flex-direction:row;align-items:center;margin-right:20px;">
                <div id="menupilihan" style="padding-right:50px;padding-left:50px;color:#1c1f4c">HOME</div>
                <div id="menupilihan" class="tombolcaridata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">CARI DATA</div>
                <div id="menupilihan" class="tomboleditdata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">EDIT DATA</div>
                <div id="menupilihan" class="tombolberisaran" style="padding-right:50px;padding-left:50px;color:#1c1f4c">BERI SARAN</div>
    
            </div>
            <img src="https://lippianfamilydentistry.net/wp-content/uploads/2015/11/user-default.png" id="avatar" style="cursor:pointer;background-color:#fee5e0;width:50px;height:50px;border-radius:50px"></img>
        </div>
        
       
    </div>

    <div style="height:100%;display:flex;flex-direction:column;justify-content:space-between">
    
    
    <form action="" method="POST" style="display:flex;height:100%;justify-content:center;align-items:center;flex-direction:column">
        <div style="display:flex;justify-content:center;align-items:center;flex-direction:column">
            <div style="margin-bottom:30px;font-size:2em;width:600px">Login untuk mendapatkan pemberitahuan</div>
            <?php if($error["err"]==true){echo '<div style="padding:15px;background-color:#fee5e0;margin-bottom:30px;width:100%;border:solid 2px #1c1f4c">'.$error["msg"].'</div>';} ?>
            <div style="width:100%;display:flex;flex-direction:row;justify-content:center;align-items:center;margin-bottom:30px;"><div style="padding-left:20px;padding-right:20px;padding:5px;background-color:#fee5e0;height:100%;align-items:center;justify-content:center;display:flex;width:150px;border:solid 2px #1c1f4c">EMAIL</div><input name="email" style="width:100%;padding:5px;;border:solid 2px #1c1f4c; border-left:none" type="text"></div>
            <div style="width:100%;display:flex;flex-direction:row;justify-content:center;align-items:center"><div style="padding-left:20px;padding-right:20px;display:flex;padding-right:20px;padding:5px;background-color:#fee5e0;height:100%;align-items:center;justify-content:center;width:150px;border:solid 2px #1c1f4c">PASSWORD</div><input name="password" style="width:100%;padding:5px;;border:solid 2px #1c1f4c; border-left:none" type="password"></div>
            <div style="margin-top:25px;width:100%;display:flex;justify-content:flex-end;align-items:center">
                <a href="daftar.php" style="margin-right:25px;color:#1c1f4c">Belum punya akun? Klik di sini.</a>
                <input type="submit" name="login" value="MASUK" style="background-color:#fee5e0;cursor:pointer;padding-left:15px;padding-right:15px;padding:10px;border:solid 2px #1c1f4c">
            </div>
        </div>
    </form>
    
    
    <div style="background-color:white;box-shadow: #8e8e8e 2px 2px 10px;padding:10px;text-align:center"></div>
     
    </div>
   
  </body>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script>
        document.querySelectorAll(".tombolcaridata")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 725,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tomboleditdata")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 1463,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tombolberisaran")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 2117,
            behavior: 'smooth',
            })
        })
    </script>
</html>