<?php
session_start();

if(isset($_POST["aksi"]) && isset($_SESSION["user"])){
         include "koneksi.php";
        if($_POST["aksi"]=="caridata"){
            $stake = $_POST["nama"];
            $q = $conn->query("SELECT * FROM stakeholder WHERE nama_stakeholder LIKE '%$stake%'");
            if($q->num_rows>0){
                $value = $q->fetch_assoc();
                echo json_encode($value);
            }else{
                echo "null";
            }
        }
    }

    ?>