import React from 'react';
import { Keyboard,KeyboardAvoidingView, Animated, StyleSheet, View, Text, Image, Dimensions, TouchableHighlight, TouchableOpacity,TextInput } from 'react-native';
import Gestures from 'react-native-easy-gestures';
import {DragResizeBlock,} from 'react-native-drag-resize';
import { Ionicons } from '@expo/vector-icons';
import { Entypo, MaterialIcons, FontAwesome } from '@expo/vector-icons'; 
import { MaterialCommunityIcons } from '@expo/vector-icons'; 
import Slider from '@react-native-community/slider';

import {
  PanGestureHandler,
  PinchGestureHandler,
  RotationGestureHandler,
  State,
} from 'react-native-gesture-handler';

import EStyleSheet from 'react-native-extended-stylesheet';


const entireScreenWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: entireScreenWidth / 380});


export default class Testing3 extends React.Component {

   

    constructor(props){
        super(props);
        this.state = {
            width: 0,
            height: 0,
            text: '',
            count : 0,
            widthSlider : this.props.positionStyle.sliderWidth
           
        }
        this.editMode = false

    }


    render(){
        text = this.props.text;
        this.editMode = this.props.editMode;
        customStyle = this.props.customStyle;
        positionStyle = this.props.positionStyle


        return (
                    <Gestures 
                    onLayout={(e)=>{
                        this.setState({
                            height: EStyleSheet.value(e.nativeEvent.layout.height+`rem`),
                            width: EStyleSheet.value(`${e.nativeEvent.layout.width}rem`),
                        })
                    }}
                    onEnd={(e,style)=>{
                            this.props.onEndDrag(e,style);
                        }} style={{justifyContent:'center',padding:5,transform:[{scale:positionStyle.transform[0].scale || 1},{rotate:`${(positionStyle.transform[0].rotate===undefined) ? '0deg':positionStyle.transform[0].rotate}`}],position:'absolute',left:positionStyle.left,top:positionStyle.top,zIndex:this.props.zIndex}} scalable={{min: 0.1, max: 7,}}>
                                
                                <View style={{justifyContent:'center',padding:20,zIndex:this.props.zIndex}}>
                            
                                <TextInput onChangeText={(text)=>{this.props.onChangeText(text)}} onFocus={this.props.onFocus} pointerEvents="none" placeholder="..." multiline={true} numberOfLines={1} onFocus={this.props.onFocus} 
                                
                                style={[customStyle,{width:this.state.widthSlider,padding:EStyleSheet.value('10rem'),zIndex:100,fontSize:EStyleSheet.value(this.props.fontsize || 30+`rem`)}]}>{text}</TextInput>
                       

                                        {
                                            (this.editMode===true) ? <View style={{width:'100%',height:'100%',position:'absolute',alignSelf:'center',borderRadius:1,borderStyle:'dashed',borderWidth:0.5}}></View> : null
                                        }

                                        {
                                            (this.editMode===true) ? 
                                            <View style={{width:'100%',position:'absolute',alignSelf:'center',bottom:0,zIndex:-1}}>
                                                         
                                                         <Slider
                                                             style={{
                                                                 paddingLeft:EStyleSheet.value('5rem'),
                                                                 paddingRight:EStyleSheet.value('5rem')
                                                             }}
                                                             minimumValue={100}
                                                             maximumValue={EStyleSheet.value(`${Dimensions.get('window').width}rem`)}
                                                             value={positionStyle.sliderWidth}
                                                             minimumTrackTintColor="#000000"
                                                             maximumTrackTintColor="#000000"
                                                             onSlidingComplete={(w)=>{
                                                                 this.setState({
                                                                     widthSlider:w
                                                                 });
                                                                 this.props.onSlidingComplete(w);
                                                             }}
                                                             />
                                             
                                             </View>:null
                                        }
                                        
                                        {
                                            (this.editMode===true) ?   <TouchableOpacity onPress={this.state._change} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',left:EStyleSheet.value('15rem'),bottom:EStyleSheet.value('15rem'),borderRadius:100}}>
                                            <FontAwesome name="exchange" size={10} color="black" />
                                            </TouchableOpacity> : null
                                        }

                                       
                                        {
                                             (this.editMode===true) ? <TouchableOpacity onPress={this.state._hideline} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),right:EStyleSheet.value(`15rem`),bottom:EStyleSheet.value('15rem'),position:'absolute',borderRadius:100}}>
                                             <MaterialCommunityIcons style={{zIndex:1}} name="file-hidden" size={10} color="black" />
                                             </TouchableOpacity>:null
                                        }
                                        {   
                                            (this.editMode===true) ? <TouchableOpacity onPress={this.props.onDelete} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',zIndex:1,right:EStyleSheet.value(`15rem`),top:EStyleSheet.value(`15rem`),borderRadius:100}}>
                                                <Entypo name="cross" size={10} color="black" />
                                            </TouchableOpacity>:null
                                        }
                                        {
                                            (this.editMode===true) ?  <TouchableOpacity onPress={()=>{this.props.onDuplicateText()}} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',zIndex:1,top:EStyleSheet.value(`15rem`),left:EStyleSheet.value(`15rem`),borderRadius:100}}>
                                            <MaterialCommunityIcons name="content-copy" size={10} color="black" />
                                            </TouchableOpacity>:null
                                        }            
                                    </View>       
                    </Gestures>
        )
    }
}