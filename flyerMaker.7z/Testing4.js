import React from 'react';
import { Animated, StyleSheet, View, Text, Image, Dimensions, TouchableHighlight, TouchableOpacity,TextInput } from 'react-native';
import Gestures from 'react-native-easy-gestures';
import {DragResizeBlock,} from 'react-native-drag-resize';
import { Ionicons } from '@expo/vector-icons';
import { Entypo, MaterialIcons, FontAwesome } from '@expo/vector-icons'; 
import { MaterialCommunityIcons } from '@expo/vector-icons'; 
import {cond,eq,lessThan,set} from 'react-native-reanimated'

import {
  PanGestureHandler,
  PinchGestureHandler,
  RotationGestureHandler,
  State,
} from 'react-native-gesture-handler';

import EStyleSheet from 'react-native-extended-stylesheet';


export default class Testing4 extends React.Component {

    initialWidth = new Animated.Value(50);
    jarakDitempuh = new Animated.Value(0);

    allwidth = Animated.add(this.initialWidth,this.jarakDitempuh);

    constructor(props){
        super(props);
        this.state={
            initialWidth : 0,
        }
        this.onGestureHandler = Animated.event(
            [{ nativeEvent: { translationX: this.jarakDitempuh } }],
            { useNativeDriver: false }
          );
    
    }

    onHandlerStateChange = (event)=>{
        if (event.nativeEvent.oldState === State.ACTIVE) {
            console.log("   ");
            console.log("Sebelum ditambahkan")
            console.log(this.state.initialWidth)
            console.log(this.jarakDitempuh);
            this.initialWidth.setValue(this.state.initialWidth-this.jarakDitempuh._value);
            console.log("Sesudah ditambahkan")
            console.log(this.allwidth);

    }
}
   

    render(){
       

        return (
            <View style={{flex:1,marginTop:200,justifyContent:'center',alignItems:'center'}}>
                <PanGestureHandler onGestureEvent={this.onGestureHandler} onHandlerStateChange={this.onHandlerStateChange}>
                    <Animated.View onLayout={(e)=>{this.setState({
                        initialWidth:e.nativeEvent.layout.width
                    })}} style={{position:'absolute',transform:[{translateX:10},{translateY:10}],padding:10,width:100,height:100,backgroundColor:'red',width:this.allwidth}}><Text>testing</Text></Animated.View>
                </PanGestureHandler>
            </View>
        )
    }
}