import React from 'react';
import { Keyboard,KeyboardAvoidingView, Animated, StyleSheet, View, Text, Image, Dimensions, TouchableHighlight, TouchableOpacity,TextInput } from 'react-native';
import Gestures from 'react-native-easy-gestures';
import {DragResizeBlock,} from 'react-native-drag-resize';
import { Ionicons } from '@expo/vector-icons';
import { Entypo, MaterialIcons, FontAwesome } from '@expo/vector-icons'; 
import { MaterialCommunityIcons } from '@expo/vector-icons'; 
import Slider from '@react-native-community/slider';

import {
  PanGestureHandler,
  PinchGestureHandler,
  RotationGestureHandler,
  State,
} from 'react-native-gesture-handler';

import EStyleSheet from 'react-native-extended-stylesheet';


const entireScreenWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: entireScreenWidth / 380});


export default class Testing6 extends React.Component {

   

    constructor(props){
        super(props);
        this.state = {
            width: 0,
            height: 0,
            text: '',
            count : 0,
            imageWidth: 0,
            imageHeight: 0,
            rotate : (this.props.positionStyle.transform[0].rotate===undefined) ? '0deg':this.props.positionStyle.transform[0].rotate
           
        }
        this.editMode = false;
        this.uri = "";
        Image.getSize(this.props.uri,(w,h)=>{
            let [a,b] = this._resizeAspectRatio(w,h);
            if(w>h){
                this.setState({
                    imageWidth:a,
                    imageHeight:b,
                    
                })
            }
            else if(w<h){
                this.setState({
                    imageWidth:b,
                    imageHeight:a,
                    
                })
            }
            
        })
        

    }

    _resizeAspectRatio = (w,h)=>{
        let maxWidth = EStyleSheet.value('300rem'); 
        let maxHeight = EStyleSheet.value('300rem');   
        let ratio = 0;  
        let width = w; 
        let height = h;
        if (width > maxWidth && width > height) {
	    
            ratio = width / height;
            return [maxWidth, maxWidth/ratio]
; 
    
        }else  if (height > maxHeight && height > width){
            
            ratio = height / width;
            return [maxWidth, maxHeight/ratio]
      
           
        }else {
    
            return [maxWidth,maxHeight]
        }
    }

 
    render(){
        this.uri = this.props.uri;
        this.editMode = this.props.editMode;
        customStyle = this.props.customStyle;
        positionStyle = this.props.positionStyle;
        elevation = this.props.zIndex;


        return (
                    <Gestures 
                    onLayout={(e)=>{
                        this.setState({
                            height: EStyleSheet.value(e.nativeEvent.layout.height+`rem`),
                            width: EStyleSheet.value(`${e.nativeEvent.layout.width}rem`),
                        })
                    }}
                    onChange={(e,style)=>{
                        this.props.onChange(e,style);
                    }}
                    onEnd={(e,style)=>{
                            this.props.onEndDrag(e,style);
                        }} style={{justifyContent:'center',elevation:elevation,zIndex:elevation,padding:0,transform:[{scale:positionStyle.transform[0].scale || 1},{rotate:this.state.rotate}],position:'absolute',left:positionStyle.left,top:positionStyle.top}} scalable={{min: 0.1, max: 7,}}>
                                 
                                 <TouchableHighlight activeOpacity={1} underlayColor="none" onPress={()=>{
                                    this.props.onPress();
                                }}>
                                <View style={{elevation:elevation,zIndex:elevation,justifyContent:'center',padding:20}}>
                               
                                    <Image style={{zIndex:elevation,width:this.state.imageWidth,height:this.state.imageHeight}} source={{uri:this.uri}}></Image>
                               
                                        {
                                            (this.editMode===true) ? <View style={{width:'100%',height:'100%',position:'absolute',alignSelf:'center',borderRadius:1,borderStyle:'dashed',borderWidth:0.5}}></View> : null
                                        }

                                        
                                        {
                                            (this.editMode===true) ?   <TouchableOpacity onPress={this.state._change} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',left:EStyleSheet.value('15rem'),bottom:EStyleSheet.value('15rem'),borderRadius:100}}>
                                            <FontAwesome name="exchange" size={10} color="black" />
                                            </TouchableOpacity> : null
                                        }

                                       
                                        {
                                             (this.editMode===true) ? <TouchableOpacity onPress={this.state._hideline} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),right:EStyleSheet.value(`15rem`),bottom:EStyleSheet.value('15rem'),position:'absolute',borderRadius:100}}>
                                             <MaterialCommunityIcons style={{zIndex:1}} name="file-hidden" size={10} color="black" />
                                             </TouchableOpacity>:null
                                        }
                                        {   
                                            (this.editMode===true) ? <TouchableOpacity onPress={()=>{this.props.onDelete()}} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',zIndex:1,right:EStyleSheet.value(`15rem`),top:EStyleSheet.value(`15rem`),borderRadius:100}}>
                                                <Entypo name="cross" size={10} color="black" />
                                            </TouchableOpacity>:null
                                        }
                                        {
                                            (this.editMode===true) ?  <TouchableOpacity onPress={()=>{this.props.onDuplicate()}} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',zIndex:1,top:EStyleSheet.value(`15rem`),left:EStyleSheet.value(`15rem`),borderRadius:100}}>
                                            <MaterialCommunityIcons name="content-copy" size={10} color="black" />
                                            </TouchableOpacity>:null
                                        }            
                                    </View> 
                                    </TouchableHighlight>      
                    </Gestures>
        )
    }
}