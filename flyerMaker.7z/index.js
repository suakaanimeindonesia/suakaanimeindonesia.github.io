import { registerRootComponent } from 'expo';

import App from './App';
import Testing from './Testing';
import Testing2 from './Testing2'
import Testing3 from './Testing3'
import Testing4 from './Testing4'
import Testing5 from './Testing5'
import MyDrawer from './Route'
import EStyleSheet from 'react-native-extended-stylesheet';



// registerRootComponent calls AppRegistry.registerComponent('main', () => App);
// It also ensures that whether you load the app in the Expo client or in a native build,
// the environment is set up appropriately
registerRootComponent(MyDrawer);
