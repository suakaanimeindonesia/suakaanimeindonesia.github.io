import React, {useState, useEffect, useRef} from 'react';
import { AsyncStorage,ImageBackground,Animated,LogBox,Pressable,TouchableOpacity,Permission,KeyboardAvoidingView,StyleSheet, Text, View, Dimensions, TouchableHighlight, Image, Button, Platform, Slider } from 'react-native';
import Testing5 from './Testing5'
import { ScrollView } from 'react-native-gesture-handler'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator,CardStyleInterpolators } from '@react-navigation/stack';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Surface } from 'gl-react-expo';
import ImageFilters from 'react-native-gl-image-filters';
import { TouchableNativeFeedback } from 'react-native-gesture-handler';
import { Entypo, MaterialIcons, FontAwesome, Foundation, SimpleLineIcons } from '@expo/vector-icons'; 
import * as FileSystem from 'expo-file-system';
import { GLView } from 'expo-gl';
import Swiper from 'react-native-swiper';
import { createDrawerNavigator } from '@react-navigation/drawer';


LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
]);

const Stack = createStackNavigator();

const entireScreenWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: entireScreenWidth / 380});


function CanvasFilter(props){

    useEffect(()=>{
        let image = props.route.params.uri;
        Image.getSize(image,(width,height)=>{
            let [w,h] = _setCanvasSize(width,height);
            setWidth([w,h]);
        })
    },[])

    let [width,setWidth] = useState([0,0])


    let [selectedPreset, setSelectedPreset] = useState("Normal");


    let refGLImage = useRef();


    let [filter,setFilter] = useState({
        hue: 0,
        blur: 0,
        sepia: 0,
        sharpen: 0,
        negative: 0,
        contrast: 1,
        saturation: 1,
        brightness: 1,
        temperature: 6500,
        exposure: 0,
    })


    let [listFilter,setListFilter] = useState([
        {
            name:"Normal",
            preset : {
                hue: 0,
                blur: 0,
                sepia: 0,
                sharpen: 0,
                negative: 0,
                contrast: 1,
                saturation: 1,
                brightness: 1,
                temperature: 6500,
                exposure: 0,
            }
        },
        {
            name:"Preset 1",
            preset : {
                hue: 2,
                blur: 0,
                sepia: 0,
                sharpen: 0,
                negative: 0,
                contrast: 1,
                saturation: 1,
                brightness: 1,
                temperature: 6500,
                exposure: 0,
            }
        },
        {
            name:"Preset 2",
            preset : {
                hue: 15,
                blur: 0,
                sepia: 2,
                sharpen: 0,
                negative: 1,
                contrast: 1,
                saturation: 1,
                brightness: 1,
                temperature: 6500,
                exposure: 0,
            }
        },
        {
            name:"Preset 3",
            preset : {
                hue: 4,
                blur: 0,
                sepia: 0,
                sharpen: 0,
                negative: 0,
                contrast: 1,
                saturation: 1,
                brightness: 5,
                temperature: 6500,
                exposure: 1,
            }
        },
        {
            name:"Preset 4",
            preset : {
                hue: 0,
                blur: 1,
                sepia: 1,
                sharpen: 0,
                negative: 0,
                contrast: 1,
                saturation: 1,
                brightness: 1,
                temperature: 6500,
                exposure: 0,
            }
        }
    ])

    let changeFilter = (index) => {
        setFilter((filter)=>{
            let selectedFilter = listFilter[index];
            console.log(selectedFilter);
            return {
                ...selectedFilter.preset
            }
        })
    }


    let _setCanvasSize = (w,h)=>{
        if(w>h){
            let different = w-h;
            if(different>200){
                return [500,300];
            }else{
                return [300,300];
            }
        }
        else if(w===h){
            return [300,300];
        }
        else{
            let different = h-w;
            if(different>200){
                return [300,400]
            }else{
                return [300,300]
            }
        }
    }


    let _resizeAspectRatio = (w,h)=>{
        let maxWidth = 300; 
        let maxHeight = 400;    
        let ratio = 0;  
        let width = w; 
        let height = h;
        if (width > maxWidth && width > height) {
	    
            ratio = width / height;
            return [maxWidth, maxWidth/ratio]
; 
    
        }else  if (height > maxHeight && height > width){
            
            ratio = height / width;
            return [maxWidth, maxHeight/ratio]
      
           
        }else {
    
            return [maxWidth,maxHeight]
        }
    }

    return (
        <View style={{flex:1}}>

            <Image blurRadius={3} style={{position:'absolute',width:'100%',height:'100%'}} source={{uri:props.route.params.uri}}></Image>
            <View style={{backgroundColor:'white',flexDirection:'row',justifyContent:'space-between',paddingHorizontal:EStyleSheet.value('10rem'),paddingTop:EStyleSheet.value('40rem'),height:EStyleSheet.value('80rem')}}>
                    <Pressable onPress={()=>{alert("123")}}><View style={{padding:EStyleSheet.value('5rem')}}><Entypo name="crop" size={24} color="black" /></View></Pressable>
                    <Pressable onPress={()=>{
                        refGLImage.glView.capture({quality:1}).then((result)=>{
                            if(selectedPreset==='Normal'){
                                props.route.params.onFinishFilter({uri:props.route.params.uri});
                                props.navigation.goBack();
                            }else{
                                props.route.params.onFinishFilter(result);
                                props.navigation.goBack();
                            }
                            
                        })
                      
                    }}><View style={{padding:EStyleSheet.value('5rem')}}><Entypo name="check" size={24} color="black" /></View></Pressable>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',height:EStyleSheet.value('500rem')}}>
                <Surface ref={(ref)=>refGLImage=ref} style={{ width:width[0],height:width[1]}}>
                        <ImageFilters {...filter} width={width[0]} height={width[1]}>
                                {{ uri: props.route.params.uri }}
                         </ImageFilters>
                </Surface>
            </View>
            <View style={{backgroundColor:'white',height:'100%',flex:1,
        shadowColor: "#000",
        borderRadius:2,
        shadowOffset: {
            width: 3,
            height: 3,
        },
        shadowOpacity: 5,
        shadowRadius: 4.22,
        elevation: 5,
        justifyContent:'center',
        }}>
                <ScrollView style={{marginLeft:10,marginRight:10}} horizontal={true}>
                   {
                       listFilter.map((value, index)=>{
                           return (
                            
                            <View key={value.name} style={{justifyContent:'center',alignItems:'center'}}>
                                <Pressable onPress={()=>{
                                        setSelectedPreset(value.name);
                                        changeFilter(index);
                                    }}>
                                <Surface style={{ margin:5,width:EStyleSheet.value('120rem'), height: EStyleSheet.value('120rem') }}>
                                        <ImageFilters {...value.preset} width={EStyleSheet.value('120rem')} height={EStyleSheet.value('120rem')}>
                                        {{ uri: props.route.params.uri }}
                                        </ImageFilters>
                                </Surface>
                                </Pressable>
                                <Text>{value.name}</Text>
                            </View>
                           )
                       })
                   }
                </ScrollView>
            </View>
        </View>
    )
}


function Dashboard(props){

    let [previousIndexMenu, setPreviousIndexMenu] = useState(0);
    let [selectedIndexMenu, setSelectedIndexMenu] = useState(0);

    let currentIndexMenu=0;
    let setDisplayMenuDashboard = (index) => {
        (index===0) ?  dashboardSwiper.scrollBy(0,true):
        (index===1) ?  dashboardSwiper.scrollBy(-1,true):
        (index===2) ?  dashboardSwiper.scrollBy(-2,true):null;
       
    }

    let dashboardSwiper = useRef();

    let menu1Expand = useRef(new Animated.Value(1)).current;
    let menu2Expand = useRef(new Animated.Value(0.8)).current;
    let menu3Expand = useRef(new Animated.Value(0.8)).current;

    let opacity1 = useRef(new Animated.Value(1)).current;
    let opacity2 = useRef(new Animated.Value(0.3)).current;
    let opacity3 = useRef(new Animated.Value(0.3)).current;


    let [templates,setTemplates] = useState([
        {
            templatesName: "Favourite",
            item: [
                {
                    name:"Favourite 1",
                    canvas:"portrait",
                    background:"https://raw.githubusercontent.com/suakaanimeindonesia/suakaanimeindonesia.github.io/master/t1.png",
                    preview:"file:///data/user/0/host.exp.exponent/cache/ExperienceData/%2540terrificsubs%252Fexpo-template-bare/ReactNative-snapshot-image2079002827637073953.jpg",
                    data :  [
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(190, 188, 188)",
                             "fontFamily": "Oswald",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 55.08725547790527,
                             "position": "absolute",
                             "sliderWidth": 195.58775554588954,
                             "top": 128.61997985839844,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 1.6765275957826284,
                               },
                             ],
                           },
                           "text": "Padang & Zachra",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(190, 188, 188)",
                             "fontFamily": "Turret",
                             "fontStyle": "normal",
                             "letterSpacing": 8,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 22.423696517944336,
                             "position": "absolute",
                             "sliderWidth": 267.27857220530666,
                             "top": 182.06643676757812,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.8617504707035469,
                               },
                             ],
                           },
                           "text": "Pernikahan",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(97, 96, 96)",
                             "fontFamily": "Roboto",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "underline",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 2,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": -76.46210670471191,
                             "position": "absolute",
                             "sliderWidth": 250,
                             "top": 275.72254943847656,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.7570140629449971,
                               },
                             ],
                           },
                           "text": "Our story",
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(163, 154, 154)",
                             "fontFamily": "Roboto",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "justify",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 3,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": -102.68211364746094,
                             "position": "absolute",
                             "sliderWidth": 348.5281644193128,
                             "top": 238.31829833984375,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.39377303981829404,
                               },
                             ],
                           },
                           "text": "Lorem ipsum dolor sit amet kejedotbdolor sit amet kejedot lorem ipsum dolor sit ametkejedot sksndndndndndndndndndmdkdkdkdmdmdkdk",
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(167, 164, 163)",
                             "fontFamily": "Oswald",
                             "fontStyle": "normal",
                             "letterSpacing": 2,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 136.08270835876465,
                             "position": "absolute",
                             "sliderWidth": 267.27857220530666,
                             "top": -23.71245574951172,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.47598877038839227,
                               },
                             ],
                           },
                           "text": "Save The Date",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(167, 164, 163)",
                             "fontFamily": "Oswald",
                             "fontStyle": "normal",
                             "letterSpacing": 2,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": -99.41884422302246,
                             "position": "absolute",
                             "sliderWidth": 401.10142996955204,
                             "top": 482.1746520996094,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.5108594199660481,
                               },
                             ],
                           },
                           "text": "dari jam 7.00 sampai jam 9.00",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(190, 188, 188)",
                             "fontFamily": "Oswald",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 55.08725547790527,
                             "position": "absolute",
                             "sliderWidth": 195.58775554588954,
                             "top": 128.61997985839844,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 1.6765275957826284,
                               },
                             ],
                           },
                           "text": "Padang & Zachra",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(190, 188, 188)",
                             "fontFamily": "Turret",
                             "fontStyle": "normal",
                             "letterSpacing": 8,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 22.423696517944336,
                             "position": "absolute",
                             "sliderWidth": 267.27857220530666,
                             "top": 182.06643676757812,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.8617504707035469,
                               },
                             ],
                           },
                           "text": "Pernikahan",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(97, 96, 96)",
                             "fontFamily": "Roboto",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "underline",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 2,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": -76.46210670471191,
                             "position": "absolute",
                             "sliderWidth": 250,
                             "top": 275.72254943847656,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.7570140629449971,
                               },
                             ],
                           },
                           "text": "Our story",
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(163, 154, 154)",
                             "fontFamily": "Roboto",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "justify",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 3,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": -102.68211364746094,
                             "position": "absolute",
                             "sliderWidth": 348.5281644193128,
                             "top": 238.31829833984375,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.39377303981829404,
                               },
                             ],
                           },
                           "text": "Lorem ipsum dolor sit amet kejedotbdolor sit amet kejedot lorem ipsum dolor sit ametkejedot sksndndndndndndndndndmdkdkdkdmdmdkdk",
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(167, 164, 163)",
                             "fontFamily": "Oswald",
                             "fontStyle": "normal",
                             "letterSpacing": 2,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 136.08270835876465,
                             "position": "absolute",
                             "sliderWidth": 267.27857220530666,
                             "top": -23.71245574951172,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.47598877038839227,
                               },
                             ],
                           },
                           "text": "Save The Date",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(167, 164, 163)",
                             "fontFamily": "Oswald",
                             "fontStyle": "normal",
                             "letterSpacing": 2,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 0,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": -99.41884422302246,
                             "position": "absolute",
                             "sliderWidth": 401.10142996955204,
                             "top": 482.1746520996094,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.5108594199660481,
                               },
                             ],
                           },
                           "text": "dari jam 7.00 sampai jam 9.00",
                           "top": NaN,
                         },
                         "type": "text",
                       },
                        {
                         "props":  {
                           "customStyle":  {
                             "color": "rgb(180, 179, 179)",
                             "fontFamily": "Oswald",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 6,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 138.43738174438477,
                             "position": "absolute",
                             "sliderWidth": 250,
                             "top": 0.5686187744140625,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 0.7940695877689924,
                               },
                             ],
                           },
                           "text": "16.08.2021",
                         },
                         "type": "text",
                       },
                     ]
                     
                },
                {
                    name:"Favourite 2",
                    background:"",
                    canvas:"portrait",
                    preview:"file:///data/user/0/host.exp.exponent/cache/ExperienceData/%2540terrificsubs%252Fexpo-template-bare/ReactNative-snapshot-image8906429556731978661.jpg",
                    data :  [
                        {
                         "canvas":  {
                           "h": 586.5454711914062,
                           "w": 361.4545593261719,
                         },
                         "props":  {
                           "customStyle":  {
                             "fontFamily": "Roboto",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 1,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 1.7500553131103516,
                             "position": "absolute",
                             "sliderWidth": 322.2415316441932,
                             "top": 196.05374145507812,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 1.0379056824124198,
                               },
                             ],
                           },
                           "text": "Testing Template 22222",
                         },
                         "type": "text",
                       },
                     ]
                },
                {
                    name:"Favourite 3",
                    background:"",
                    canvas:"portrait",
                    preview:"file:///data/user/0/host.exp.exponent/cache/ExperienceData/%2540terrificsubs%252Fexpo-template-bare/ReactNative-snapshot-image8906429556731978661.jpg",
                    data : [{}]
                },
                {
                    name:"Favourite 4",
                    background:"",
                    canvas:"portrait",
                    preview:"file:///data/user/0/host.exp.exponent/cache/ExperienceData/%2540terrificsubs%252Fexpo-template-bare/ReactNative-snapshot-image8906429556731978661.jpg",
                    data : [{}]
                }
            ]
        },
        {
            templatesName: "Most Rated",
            item: [
                {
                    name:"Most Rated 1",
                    canvas:"portrait",
                    background:"",
                    preview:"file:///data/user/0/host.exp.exponent/cache/ExperienceData/%2540terrificsubs%252Fexpo-template-bare/ReactNative-snapshot-image8906429556731978661.jpg",
                    data :  [
                        {
                         "props":  {
                           "customStyle":  {
                             "fontFamily": "Roboto",
                             "fontStyle": "normal",
                             "letterSpacing": 0,
                             "lineHeight": 50,
                             "textAlign": "center",
                             "textDecorationLine": "none",
                             "textShadowColor": "rgba(0, 0, 0, 0.75)",
                             "textShadowOffset":  {
                               "height": 0,
                               "width": 0,
                             },
                             "textShadowRadius": 0,
                             "zIndex": 1,
                           },
                           "modeEdit": false,
                           "positionStyle":  {
                             "left": 25.55529022216797,
                             "position": "absolute",
                             "sliderWidth": 250,
                             "top": 478.20538330078125,
                             "transform":  [
                                {
                                 "rotate": "0deg",
                                 "scale": 1.7028038175348486,
                               },
                             ],
                           },
                           "text": "Odading nanv",
                         },
                         "type": "text",
                         "canvas":{
                             "h":586.5454711914062,
                             "w":361.4545593261719
                         }
                       },
                     ]
                },
                {
                    name:"Most Rated 2",
                    canvas:"portrait",
                    background:"",
                    preview:"file:///data/user/0/host.exp.exponent/cache/ExperienceData/%2540terrificsubs%252Fexpo-template-bare/ReactNative-snapshot-image8906429556731978661.jpg",
                    data : [{}]
                }
            ]
        }
    ])

    let [myStory, setMyStory] = useState({item:[]});
    
    let updateMyStory = () => {
        AsyncStorage.getItem("mystory",(err,result)=>{
            if(result){
                let parsed = JSON.parse(result);
                setMyStory(parsed);
            }
        })
    }

    let initialUpdateStory = useEffect(()=>{
        AsyncStorage.getItem("mystory",(err,result)=>{
            if(result){
                let parsed = JSON.parse(result);
                setMyStory(parsed);
            }
        })
    },[])
    
    let button1pressed = ()=>{
        Animated.timing(menu1Expand, {
            toValue: 1,
            duration: 100,
            useNativeDriver:true
          }).start();
          Animated.timing(menu2Expand, {
            toValue: 0.8,
            duration: 100,
            useNativeDriver:true
          }).start();
          Animated.timing(menu3Expand, {
            toValue: 0.8,
            duration: 100,
            useNativeDriver:true
          }).start();
          opacity1.setValue(1)
          opacity2.setValue(0.3)
          opacity3.setValue(0.3)
            
         
    }


    let button2pressed = ()=>{
        Animated.timing(menu1Expand, {
            toValue: 0.8,
            duration: 100,
            useNativeDriver:true
          }).start();
          Animated.timing(menu2Expand, {
            toValue: 1,
            duration: 100,
            useNativeDriver:true
          }).start();
          Animated.timing(menu3Expand, {
            toValue: 0.8,
            duration: 100,
            useNativeDriver:true
          }).start();
          opacity1.setValue(0.3)
          opacity2.setValue(1)
          opacity3.setValue(0.3)
   
    }

    
    let button3pressed = ()=>{
        Animated.timing(menu1Expand, {
            toValue: 0.8,
            duration: 100,
            useNativeDriver:true
          }).start();
          Animated.timing(menu2Expand, {
            toValue: 0.8,
            duration: 100,
            useNativeDriver:true
          }).start();
          Animated.timing(menu3Expand, {
            toValue: 1,
            duration: 100,
            useNativeDriver:true
          }).start();
          opacity1.setValue(0.3)
          opacity2.setValue(0.3)
          opacity3.setValue(1)

    }

    let main = EStyleSheet.create({
        headerContainer : {
            backgroundColor:'white',
            height:'85rem',
            width:'100%',
            paddingTop:'28rem',
        },
        mainContainer :{
            flex:1,
            backgroundColor:'white',
            marginBottom:'70rem'
        },
        bottomContainer: {
            backgroundColor:'white',
            height:'60rem',
            bottom:0,
            width:'100%',
            flexDirection:'row',
            position:'absolute',
            shadowColor: "#000",
            shadowOffset: {
                width: 0,
                height: 10,
            },
            shadowOpacity: 5.5,
            shadowRadius: 10.97,

            elevation: 21
        },
        containerMenu3 : {
            paddingHorizontal:'20rem',
            paddingVertical:'15rem',
            flexDirection: 'row',
            flexWrap:'wrap'
        },
        itemContainerMenu3 : {
            backgroundColor:'white',
            width: EStyleSheet.value(`90rem`),
            marginHorizontal:'10rem',
            marginVertical:'10rem',
            height:'150rem'
            
        }
    })

    return (
        <View style={{flex:1}}>
            <View style={main.headerContainer}>
                 <View style={{flex:1,flexDirection:'row'}}>
                     <Pressable style={{flex:1,justifyContent:'center',alignItems:'flex-start',paddingHorizontal:EStyleSheet.value('25rem')}} onPress={()=>{
                         props.navigation.openDrawer();
                     }}><View ><Entypo name="menu" size={26} color="black" /></View></Pressable>
                     <View style={{flex:1,justifyContent:'center',alignItems:'center',paddingHorizontal:EStyleSheet.value('25rem')}}><Text>Dashboard</Text></View>
                     <View style={{flex:1,justifyContent:'center',alignItems:'flex-end',paddingHorizontal:EStyleSheet.value('25rem')}}><SimpleLineIcons name="bag" size={23} color="black" /></View>
                </View>
            </View>
            <Swiper ref={(ref)=>{dashboardSwiper=ref}} style={{backgroundColor:'white'}} onIndexChanged={(index)=>{
                currentIndexMenu=index;
                switch (index) {
                    case 0:
                        button1pressed();
                        //setSelectedIndexMenu(0);
                        break;
                    case 1:
                        button2pressed();
                        //setSelectedIndexMenu(1);
                        break;
                    case 2:
                         button3pressed();
                        //setSelectedIndexMenu(2);
                        break;
                    default:
                        break;
                }
            }} 
                loop={false} index={0} showsPagination={false}>
                <ScrollView showsVerticalScrollIndicator={false}>
                <View style={main.mainContainer}>
                {
                    templates.map((element,i)=>{
                        return (
                        <View key={`templates`+i} style={{paddingHorizontal:EStyleSheet.value('25rem'),paddingVertical:EStyleSheet.value('10rem')}}>
                            <Text>{element.templatesName}</Text>
                            <ScrollView showsHorizontalScrollIndicator={false} horizontal={true}>
                                <View style={{flexDirection:'row',paddingLeft:1,marginVertical:EStyleSheet.value('10rem')}}>
                                   {
                                       element.item.map((item,i)=>{
                                           return (
                                            <Pressable key={`${item.name}${i}`} onPress={()=>{
                                                props.navigation.navigate("Canvas",{background:item.background,template:item,indexDashboard:currentIndexMenu,function:{updateMyStory:updateMyStory,setDisplayMenuDashboard:setDisplayMenuDashboard}});
                                            }}>
                                                <ImageBackground source={{uri:item.preview}} resizeMode="contain" style={{marginRight:EStyleSheet.value('15rem'),width:EStyleSheet.value('100rem'),height:EStyleSheet.value('180rem'),backgroundColor:'white',shadowColor: "#000",
shadowOffset: {
	width: 0,
	height: 1,
},
shadowOpacity: 0.20,
shadowRadius: 1.41,

elevation: 2,}}>
                                                    <Text></Text>
                                                </ImageBackground>
                                            </Pressable>
                                           )
                                       })
                                   }
                                </View>
                            </ScrollView>
                        </View>
                        )
                    })
                }
                </View>
                </ScrollView>
                <View style={main.mainContainer}>
                    <Text>555</Text>
                </View>
                <View style={main.mainContainer}>
                    <ScrollView>
                    <View style={main.containerMenu3}>
                        {
                            myStory.item.map((item, i)=>{
                                return (
                                    <View key={`MyStory-${i}`} style={{justifyContent:'center',alignItems:'center'}}>
                                        <Pressable onPress={()=>{
                                            props.navigation.navigate("Canvas",{template:item,indexDashboard:currentIndexMenu,function:{updateMyStory:updateMyStory,setDisplayMenuDashboard:setDisplayMenuDashboard}});
                                        }}><ImageBackground source={{uri:item.preview}} style={[{shadowColor: "#000",
                                        shadowOffset: {
                                            width: 2,
                                            height: 2,
                                        },
                                        shadowOpacity: 2.20,
                                        shadowRadius: 5.41,
                                        
                                        elevation: 5},main.itemContainerMenu3]}>
                                        </ImageBackground>
                                        </Pressable>
                                        <Text>{item.name}</Text>
                                    </View>
                                )
                            })
                        }
                    </View>
                    </ScrollView>
                </View>
            </Swiper>
            <View style={main.bottomContainer}>

                    <Animated.View style={{flex:1}}>
                        <TouchableNativeFeedback onPress={()=>{
                            button1pressed();
                            dashboardSwiper.scrollBy(0-currentIndexMenu,true);
                        }}>
                        <Animated.View style={{opacity:opacity1,height:'100%',justifyContent:'center',alignItems:'center',transform:[{scale:menu1Expand}]}}>
                            <Image style={{width:25,height:25}} source={require("./assets/template.png")}></Image>
                            <Text>Templates</Text>
                        </Animated.View>
                        </TouchableNativeFeedback>
                    </Animated.View>

            
                    <Animated.View style={{flex:1}}>
                        <TouchableNativeFeedback onPress={()=>{
                            button2pressed();
                            dashboardSwiper.scrollBy(1-currentIndexMenu,true);
                        }}>
                        <Animated.View style={{opacity:opacity2,height:'100%',justifyContent:'center',alignItems:'center',transform:[{scale:menu2Expand}]}}>
                            <Image style={{width:25,height:25}} source={require("./assets/collection.png")}></Image>
                            <Text>Collection</Text>
                        </Animated.View>
                        </TouchableNativeFeedback>
                    </Animated.View>
         
                <Animated.View style={{flex:1}}>
                    <TouchableNativeFeedback onPress={()=>{
                        button3pressed();                  
                        dashboardSwiper.scrollBy(2-currentIndexMenu,true); 
                    }}>
                    <Animated.View style={{opacity:opacity3,height:'100%',justifyContent:'center',alignItems:'center',transform:[{scale:menu3Expand}]}}>
                        <Image style={{width:27,height:27}} source={require("./assets/notebook.png")}></Image>
                        <Text>My Story</Text>
                    </Animated.View>
                    </TouchableNativeFeedback>
                </Animated.View>
            </View>
        </View>
    )
}




function Router(){
    return (
            <Stack.Navigator>
                <Stack.Screen 
                options={{
                    headerShown:false,
                    cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                }}
                name="Home" component={Dashboard} />
                <Stack.Screen 
                options={{
                    headerShown:false,
                    cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                }}
                name="Canvas" component={Testing5} />
                <Stack.Screen 
                options={{
                    headerShown:false,
                    cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                }}
                name="Filter" component={CanvasFilter} />
            </Stack.Navigator>
      
    );
}


const Drawer = createDrawerNavigator();


function CustomDrawerContent({ navigation }) {
    let style = EStyleSheet.create({
        containerLogo:{
            height:'150rem',
            justifyContent:'center',
            alignItems:'center',
            paddingTop:'35rem',
        },
        menuDrawer: {
            width:'100%',
            backgroundColor:'#f6f6f6',
            height:'50rem',
            justifyContent:'center',
            alignItems:'center',
            borderBottomWidth:'2rem',
            borderColor:'white',
            marginBottom:'10rem'
        },
        wrapperMenuDrawer: {
            width:'100%',
            height:'100%',
            justifyContent:'center',
            alignItems:'center',
        }
    })

    return (
      <View style={{flex:1}}>
                <View style={style.containerLogo}>
                    <Image style={{width:EStyleSheet.value('200rem'),height:EStyleSheet.value('30rem')}} source={require('./assets/mediatech.png')}></Image>
                    <Text style={{color:"grey",marginVertical:EStyleSheet.value('5rem')}}>App Version : v0.01</Text>
                </View>
                <View style={style.menuDrawer}>
                            <TouchableNativeFeedback style={{width:Dimensions.get('screen').width}}>
                                <View style={style.wrapperMenuDrawer}>
                                    <Text>Tombol 1</Text>
                                </View>
                            </TouchableNativeFeedback>
                </View>
                <View style={style.menuDrawer}>
                            <TouchableNativeFeedback style={{width:Dimensions.get('screen').width}}>
                                <View style={style.wrapperMenuDrawer}>
                                    <Text>Tombol 2</Text>
                                </View>
                            </TouchableNativeFeedback>
                </View>
                <View style={{flex:1, justifyContent:'flex-end',alignItems:'center',paddingBottom:EStyleSheet.value('20rem')}}>
                    <Text>Mediatechindo -  Mobile App Developer</Text>
                </View>
      </View>
    );
  }


export default function MyDrawer() {
    return (
        <NavigationContainer>
            <Drawer.Navigator
            drawerContent={(props) => <CustomDrawerContent {...props} />}
            drawerStyle={{
                width:'100%'
            }}
            >
                <Drawer.Screen 
                options={{
                    gestureEnabled:false
                }}
                name="Router" component={Router} />
            </Drawer.Navigator>
      </NavigationContainer>
    );
  }