import { StatusBar } from 'expo-status-bar';
import React, {useState, useEffect, useRef} from 'react';
import { TouchableOpacity,Permission,KeyboardAvoidingView,StyleSheet, Text, View, Dimensions, TouchableHighlight, Image, Button, Platform, Slider } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import {DragTextEditor} from 'react-native-drag-text-editor';
import { set } from 'react-native-reanimated';
import {DragResizeBlock,} from 'react-native-drag-resize';
import { captureRef } from "react-native-view-shot";
const WINDOW = Dimensions.get('window');
import * as FileSystem from 'expo-file-system';
import CameraRoll from "@react-native-community/cameraroll";
import * as MediaLibrary from 'expo-media-library';


const entireScreenWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: entireScreenWidth / 380});

const styles = EStyleSheet.create({
  headerContainer : {
    height:'80rem',
    paddingTop:'45rem',
    display:'flex',
    alignItems:'center'
  },
  canvasContainer : {
    backgroundColor:'white',
    flex:1
  },
  toolsContainer : {
    height:'60rem',
    display:'flex',
    flexDirection:'row',
    backgroundColor:'white'
  },
  childToolsContainer : {
    flex:1,
    justifyContent:'center',
    alignItems:'center'
  },
  imageCanvas : {
    flex:1,
    position:'absolute',
    height:'100%',
    width:'100%'
  }
});


export default function App() {

  const [image, setImage] = useState('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSKvTkr0jy2bwG8ksVNmSWOyyWtiH3NcYWEJg&usqp=CAU');
  const [element, setElement] = useState([]);
  const [iTextSelected, setiTextSelected] = useState(null);
  const [editMode, setEditMode] = useState(null);

  const [stickerSelected, setStickerSelected] = useState(null);

  const refCanvas = useRef(null);

  const [showDeleteGambar, setShowDeleteGambar] = useState(null);


  useEffect(() => {
    (async () => {
      if (Platform.OS !== 'web') {
        const { status } = await ImagePicker.requestCameraRollPermissionsAsync();
        if (status !== 'granted') {
          alert('Sorry, we need camera roll permissions to make this work!');
        }
      }
    })();
  }, []);



  const simpanCanvas = async () =>{
    captureRef(refCanvas, {
      format: "jpg",
      quality: 1,
    }).then(
      uri => {
        console.log(uri);
        MediaLibrary.createAssetAsync(uri).then((asset)=>{
          MediaLibrary.createAlbumAsync('download',asset,false).then(()=>{
            alert("Gambar telah tersimpan dalam galeri...");
          })
        })
      
      },
      error => console.error("Oops, snapshot failed", error)
    );
  }

  const tambahSticker = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      quality: 1,
    });

    if (!result.cancelled) {
      setElement((prev)=>{
        return [...prev, {type:"sticker",properties:{isDisabled:true,uri:result.uri}}]
      })
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      quality: 1,
    });

    console.log(result);

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  const handleResize = async (bool,i) =>{
    setStickerSelected(i);
    setElement((re)=>{
      let r = [...re];
      r[i].properties.isDisabled=bool;
      return r;
    })
  }


  const tambahTeks = async ()=>{
    setElement((el)=>{
      return [
        ...el,
        {type:"text",properties:{textSize:30,lineHeight:25}}
      ]
    })
  }

  const tambahStiker = async () => {
    alert("stiker");
  }

  const deleteText = async (id) =>{
      setElement((re)=>{
        let e = [...re].filter((val,i)=>{
          return i !== id;
        })
        return e;
      })
  }

  const deleteGambar = async () =>{
    if(stickerSelected){
      setElement((re)=>{
        let e = [...re].filter((val,i)=>{
          return i !== stickerSelected;
        })
        return e;
      })
      setShowDeleteGambar(false);
    }
  }

  return (
    <KeyboardAvoidingView
    behavior={Platform.OS == "ios" ? "padding" : "height"}
    keyboardVerticalOffset={Platform.OS == "ios" ? 0 : 20}
    enabled={Platform.OS === "ios" ? true : false} style={{flex:1}}>
      
          <View style={styles.headerContainer}>
            <Text>Tes Aplikasi</Text>
            {
              (showDeleteGambar === true) ? <TouchableOpacity onPress={()=>{deleteGambar();}} style={{right:0,marginRight:30,position:"absolute",marginTop:EStyleSheet.value("46rem")}}><Text>Hapus</Text></TouchableOpacity>:<View></View>
            }
          </View>
         
          <View ref={refCanvas} style={styles.canvasContainer}>
          <Image style={styles.imageCanvas} source={{uri: image}}/>
            {
              (editMode==="text") ? (   <View style={{position:"absolute",width:'100%'}}>
              <Slider onValueChange={(val)=>{
                  setElement((prev)=>{
                    let arr = [...prev];
                    if(arr[iTextSelected]){
                      arr[iTextSelected].properties.textSize=val;
                    }
                    //console.log(val);
                    return arr;
                  })
              }} minimumValue={25} maximumValue={100} style={{zIndex:100,backgroundColor:'white',width:'100%'}}></Slider>
              <Slider  onValueChange={(val)=>{
                  setElement((prev)=>{
                    let arr = [...prev];
                    if(arr[iTextSelected]){
                      arr[iTextSelected].properties.lineHeight=val;
                    }
                    //console.log(val);
                    return arr;
                  })
              }} value={25} minimumValue={25} maximumValue={100} style={{zIndex:100,backgroundColor:'white',width:'100%'}}></Slider>
            </View>) : (<View></View>)
            }
          
            
              {
                
                element.map((el,i)=>{
                  if(el.type==="text"){
                    return (
                      <DragTextEditor
                      key={i+"el"}
                      text={"Lorem ipsum..."}
                      minWidth={100}
                      minHeight={100}
                      w={200}
                      h={200}
                      x={50}
                      y={10}
                      zindex={i}
                      FontColor={"red"}
                      LineHeight={el.properties.lineHeight}
                      TextAlign={"left"}
                      LetterSpacing={0}
                      FontSize={el.properties.textSize}
                      isDraggable={true}
                      isResizable={true}
                      TopLeftAction={()=>{setiTextSelected(i); setEditMode(null); }}
                      TopRightAction={()=>{deleteText(i); setEditMode(null);}}
                      centerPress={()=>{setiTextSelected(i); setEditMode("text")}}
                      onDragStart={()=>{setiTextSelected(i); setEditMode("text");}}
                      onDragEnd={()=>{setiTextSelected(i); setEditMode(null);}}
                      onDrag={()=>{setiTextSelected(i); setEditMode("text")}}
                      onResizeStart={()=>{setiTextSelected(i); setEditMode("text")}}
                      onResize={()=>{setiTextSelected(i); setEditMode("text")}}
                      onResizeEnd={()=>{setiTextSelected(i); setEditMode("text")}}
                    /> 
                    )
                  } 
                  if(el.type==="sticker"){

                     return (
                      <DragResizeBlock
                          x={0}
                          y={0}
                          key={i+"el"}
                          isDisabled={el.properties.isDisabled}
                          onPress={()=>{handleResize(false,i); setShowDeleteGambar(true);}}
                          onDragEnd={()=>{handleResize(true,i); setShowDeleteGambar(false);}}
                          onResizeEnd={()=>{handleResize(true,i); setShowDeleteGambar(false);}}
                    
                        >
                      <Image style={{width:'100%',height:'100%',zIndex:i}} source={{uri:el.properties.uri}}/>
                        </DragResizeBlock>)
                  }
                  else{
                    return <Text>Memek</Text>;
                  }
                })
              }
            
            </View>
          <View style={styles.toolsContainer}>
              <TouchableHighlight style={styles.childToolsContainer} onPress={()=>{pickImage()}}><Text>Ganti Background</Text></TouchableHighlight>
              <TouchableHighlight onPress={()=>{tambahTeks();}} style={styles.childToolsContainer}><Text>Tambah Teks</Text></TouchableHighlight>
              <TouchableHighlight onPress={()=>{tambahSticker();}} style={styles.childToolsContainer}><Text>Tambah Stiker</Text></TouchableHighlight>
              <TouchableHighlight style={styles.childToolsContainer}><Text>Tambah Shape</Text></TouchableHighlight>
              <TouchableHighlight onPress={()=>{simpanCanvas();}}style={styles.childToolsContainer}><Text>Simpan Gambar</Text></TouchableHighlight>
          </View>
      </KeyboardAvoidingView>
  );
}

