import React, {useEffect, useRef, useState, useCallback} from 'react';
import {  ActivityIndicator,Alert,ImageBackground,Pressable,FlatList,AsyncStorage,CheckBox,BackHandler,Keyboard,useWindowDimensions,KeyboardAvoidingView,ScrollView,TouchableNativeFeedback,Animated, StyleSheet, View, Text, Image, Dimensions, TouchableHighlight, TouchableOpacity,TextInput } from 'react-native';
import Gestures from 'react-native-easy-gestures';
import {DragResizeBlock,} from 'react-native-drag-resize';
import { Ionicons } from '@expo/vector-icons';
import { Entypo, MaterialIcons, FontAwesome, Foundation } from '@expo/vector-icons'; 
import { MaterialCommunityIcons } from '@expo/vector-icons'; 
import {cond,eq,lessThan,set} from 'react-native-reanimated'
import { AntDesign, Feather,Octicons, Fontisto } from '@expo/vector-icons'; 
import RBSheet from "react-native-raw-bottom-sheet";
import Testing3 from './Testing3';
import Testing6 from './Testing6';
import Swiper from 'react-native-swiper';
import {useFonts} from 'expo-font';
import * as FileSystem from 'expo-file-system';
import { scale, verticalScale, moderateScale, screenSize } from "./Scaler"
import { captureRef } from "react-native-view-shot";
import {
    SliderHuePicker,
    SliderSaturationPicker,
    SliderValuePicker,
} from 'react-native-slider-color-picker';
import tinycolor from 'tinycolor2';

import {
  PanGestureHandler,
  PinchGestureHandler,
  RotationGestureHandler,
  State,
} from 'react-native-gesture-handler';
import * as Permissions from 'expo-permissions';
import EStyleSheet from 'react-native-extended-stylesheet';
import HsvColorPicker from 'react-native-hsv-color-picker';
import * as MediaLibrary from 'expo-media-library';


const entireScreenWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: entireScreenWidth / 380});


let shadowControl = EStyleSheet.create({
    containerShadowControl : {
        flex:1,
        paddingLeft:'20rem',
        paddingRight:'20rem'
    },
    containerChild : {
        flex:1,
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center'
    }
})


let toolboxAtas = EStyleSheet.create({
    paddingAtas : {
        height:'28rem',
        backgroundColor:'white'
    },
    container : {
        backgroundColor:'white',
        height:'55rem',
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:'center',
        paddingHorizontal:'15rem'
    },
    itemContainer : {
        flex:1,
    }
})

let style = EStyleSheet.create({
    thumb: {
        width: '15rem',
        height: '15rem',
        borderColor: 'white',
        borderWidth: 1,
        borderRadius: 10,
        shadowColor: 'black',
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowRadius: 2,
        shadowOpacity: 0.35,
    },
    topBar : {
        height:'28rem',
    },
    navigationBar : {
        height:'50rem',
    },
    menuEditTeks:{
        marginLeft:'20rem',
        marginRight:'20rem',
        marginBottom:'0rem',
        backgroundColor:'#f4f4f2',
        height:'40rem',
        borderRadius:'4rem',
        flexDirection:'row'
    },  
    containerPilihFont:{
        padding:'20rem',
        paddingTop:'5rem',
        paddingBottom:'5rem',
        flex:1
    },
    containerJenisFont:{
        height:'35rem',
        flexDirection:'row',
    },
    jenisFont :{
        margin:'5rem',
        padding:'5rem',
        borderRadius:'5rem',
        backgroundColor:'#f4f4f2',

    },  
    containerPilihFont2 :{
        flexDirection:'row',
        flexWrap:'wrap',
        height:'90rem',
    },
    containerFont : {
        width:'83rem',
        height:'30rem',
        justifyContent:'center',
        alignItems:'center',
    },
    itemMenuEditTeks : {
        flex:1,
        height:'40rem',
        justifyContent:'center',
        alignItems:'center'
    },  
    containerEditTeks : {
        position:'absolute',
        width:'100%',
        bottom:0,
        zIndex:1000,
        height:'220rem',
        backgroundColor:'white',
        shadowColor: "#000",
        borderRadius:2,
        shadowOffset: {
            width: 3,
            height: 3,
        },
        shadowOpacity: 5,
        shadowRadius: 4.22,

        elevation: 50,
    },  
    bottomBar : {
        position:'absolute',
        bottom:0,
        width:'100%',
        backgroundColor:'white',
        flex:1,
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center'
    },
    tombolNavigasiCanvas: {
        padding:'25rem',
        flex:1,
    },
    containerCanvasAtas:{
        height:'110rem',
        backgroundColor:'#f4f4f2',
        zIndex:1,
        elevation:1
    },
    containerCanvasTengah:{
        flex:1,
        flexDirection:'row',
        backgroundColor: '#f4f4f2'
        
    },
    containerCanvasBawah:{
        height:'100rem',
        backgroundColor: '#f4f4f2'
    },
    containerCanvasOffsetKiri:{
        width:'15rem',
        backgroundColor: '#f4f4f2',
        zIndex:3,
        elevation:3
    },
    containerCanvasOffsetKanan:{
        width:'15rem',
        backgroundColor: '#f4f4f2',
        zIndex:3,
        elevation:3
    },
    containerCanvas:{
        flex:1,
        zIndex:0,
        elevation:0,
        backgroundColor:'white',
        shadowColor: "#000",
        borderRadius:2,
        shadowOffset: {
            width: 0,
            height: 0,
        },
        shadowOpacity: 5,
        shadowRadius: 2.22,
        elevation: 2,
    },
    containerTopBar:{
        marginLeft:"20rem",
        marginRight:'20rem',
        height:'40rem',
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'space-between'
    },
    itemTopBar : {
        padding:'10rem'
    }

  
})


let modalTambahStiker = EStyleSheet.create({
    containerCategorySticker :{
        marginHorizontal:'10rem',
        marginTop:'5rem'
    },
    containerBallonCategorySticker:{
        paddingVertical:'5rem',
        flexDirection:'row'
    },
    containerSearchBar : {
        paddingHorizontal:'12rem',
        marginHorizontal:'10rem',
        height:'40rem',
        backgroundColor:'#f4f4f2',
        borderRadius:'5rem'
    }, 
    ballonCategory_active : {
        padding:'10rem',
        backgroundColor:'#dbdbdb',
        alignSelf:'flex-start',
        paddingHorizontal:'17rem',
        paddingVertical:'5rem',
        borderRadius:'15rem',
        marginHorizontal:'3rem'
    }, 
    ballonCategory_disabled : {
        padding:'10rem',
        alignSelf:'flex-start',
        paddingHorizontal:'17rem',
        paddingVertical:'5rem',
        borderRadius:'15rem',
        marginHorizontal:'3rem'
    }, 
    childContainerSearchBar :{
        flex:1,
        flexDirection:'row',
        alignItems:'center'
    },  
    containerStiker : {
        padding:'0rem',
        paddingLeft:'25rem',
        paddingRight:'15rem',
        flex:1,
    
    },
    containerKotakIsiStiker :{
        height:'100%',
        width:'100%',
        marginTop:'5rem',
        marginBottom:'15rem',          
    },
    kotakItemStiker : {
        padding:'10rem',
        backgroundColor:'#f4f4f2',
        width:'92rem',
        height:'80rem',
        margin:'10rem',
        borderRadius:'10rem',
        justifyContent:'center',
        alignItems:'center'
    }
})




function CanvasChooseBackgroundColor(props){
    const refRBSheetChooseBackground = useRef();

    let [photo,setPhoto] = useState({assets:[]});
    let [widthElement, setWidthElement] = useState(0);
    let [heightElement, setHeightElement] = useState(0);

    let [isDataLoaded, setIsDataLoaded] = useState(false);

    useEffect(()=>{ 
        refRBSheetChooseBackground.current.open();
        MediaLibrary.getAssetsAsync({
            first:23
        }).then((asset)=>{
            setPhoto({
                ...asset
            })
        })
    },[])


    let testing = ()=>{alert("123")}


    let fetchPhotosFromLocal = () =>{
        MediaLibrary.getAssetsAsync({
            first:23,
            after:photo.endCursor
        }).then((asset)=>{
            setPhoto((val)=>{
                let p = val;
                p = {
                    ...asset,
                    assets : [
                        ...val.assets,
                        ...asset.assets
                    ]
                }
                setIsDataLoaded(false);
                return p;
            })
            
        })
    }

    let onFinishFilter = (result)=>{
        props.onFinishFilter(result);
    }

    return <RBSheet
    ref={refRBSheetChooseBackground}
    onClose={()=>{
        props.onClose();
    }}
    closeOnDragDown={true}
    closeOnPressMask={false}
    dragFromTopOnly={true}
    customStyles={{
    wrapper: {
        backgroundColor: "transparent"
    },
    draggableIcon: {
        backgroundColor: "#f4f4f2"
    },
    container: {
        borderTopRightRadius:15,
        borderTopLeftRadius:15,
        backgroundColor:'white',
        shadowColor: "#000",
        borderRadius:2,
        shadowOffset: {
            width: 5,
            height: 12,
        },
        shadowOpacity: 5,
        shadowRadius: 2.22,

        elevation: 20,
        }
    }}
    >
    <View onLayout={
        (e)=>{
            setWidthElement(EStyleSheet.value(`${e.nativeEvent.layout.width/4}rem`));
            setHeightElement(EStyleSheet.value(`${e.nativeEvent.layout.height/2}rem`))
        }
    } style={{flex:1}}>
        <FlatList
          onEndReached={()=>{
            if(photo.hasNextPage===true && isDataLoaded===false){
                setIsDataLoaded(true);
                fetchPhotosFromLocal();
            }
          }}
          numColumns={4}
          data={photo.assets}
          renderItem={({ item }) => (
            <TouchableHighlight onPress={()=>{
                refRBSheetChooseBackground.current.close();
                setTimeout(() => {
                    props.navigation.navigate('Filter',{uri:item.uri,onFinishFilter:onFinishFilter});
                }, 50);
               
            }}>
                <View style={{width:widthElement-3.3,height:heightElement}}>
                    <Image style={{width:'100%',height:'100%'}} source={{uri:item.uri}}></Image>
                </View>
            </TouchableHighlight>
          )}
        />
    </View>
    </RBSheet>
}


function CanvasTextEdit(props){
    let [styleFontSelectedIndex, setStyleFontSelectedIndex] = useState(0);
    let [openedTab, setOpenedTab] = useState(0);    


    
    let [hwrShadowText,setHWRShadowText] = useState({
        h: (props.selectedIndex>-1) ? props.element[props.selectedIndex].props.customStyle.textShadowOffset.height:0,
        w:(props.selectedIndex>-1) ? props.element[props.selectedIndex].props.customStyle.textShadowOffset.width:0,
        r:(props.selectedIndex>-1) ? props.element[props.selectedIndex].props.customStyle.textShadowRadius:0
    })
    


    useEffect(()=>{
        props.onChangeHWRShadowValue(hwrShadowText);
    },[hwrShadowText])

    let inputHWRHandler = (val, prefix) =>{
        let value = parseInt(val.toString());
        if(!isNaN(value)){
            switch (prefix) {
                case 'h':
                    setHWRShadowText({
                        ...hwrShadowText,
                        h:val
                    })
                    break;
                case 'w':
                    setHWRShadowText({
                        ...hwrShadowText,
                        w:val
                    })
                    break;
                case 'r':
                    setHWRShadowText({
                        ...hwrShadowText,
                        r:val
                    })
                    break;
                default:
                    break;
            }
           
        }else{
            switch (prefix) {
                case 'h':
                    setHWRShadowText({
                        ...hwrShadowText,
                        h:''
                    })
                    break;
                case 'w':
                    setHWRShadowText({
                        ...hwrShadowText,
                        w:''
                    })
                    break;
                case 'r':
                    setHWRShadowText({
                        ...hwrShadowText,
                        r:''
                    })
                    break;
                default:
                    break;
            }
        }
        
    }
    


    const updateIndex = useCallback((res) => { setTimeout(() => { setStyleFontSelectedIndex(res); }, 50); }, []);


    let refCategoryFont = useRef();
    const handlePressCategoryFont = (i)=>{
        refCategoryFont.current.scrollBy(i);
        
    }

    let [oldColor,setOldColor] = useState((props.selectedIndex>-1) ? tinycolor(props.element[props.selectedIndex].props.customStyle.textShadowColor).toHexString():'#03a9f4');

    let [oldBackgroundColor, setOldBackgroundColor] = useState((props.element[props.selectedIndex]?.props?.customStyle?.backgroundColor===undefined) ? "#03a9f4":props.element[props.selectedIndex].props.customStyle.backgroundColor);
    let [checkboxTextBackground,setCheckboxTextBackground] = useState((props.element[props.selectedIndex]?.props?.customStyle?.backgroundColor===undefined) ? false:true);

    let changeBackgroundColor = (colorHsvOrRgb, resType) => {
        if (resType === 'end') {
            setOldBackgroundColor(tinycolor(colorHsvOrRgb).toHexString());
            let rgb=tinycolor(colorHsvOrRgb).toRgbString();
            props.onChangedTextBackgroundColor(rgb,checkboxTextBackground);
        }
    }

    let clickCheckboxBackgroundText = (val) => {
        setCheckboxTextBackground(val);
        if(val===true){ 
            props.onClickedChecboxTextBackground(oldBackgroundColor,true);
        }else{
            props.onClickedChecboxTextBackground(oldBackgroundColor,false);
        }
       
    }


    let changeColor = (colorHsvOrRgb, resType) => {
        if (resType === 'end') {
            setOldColor(tinycolor(colorHsvOrRgb).toHexString());
            let rgb=tinycolor(colorHsvOrRgb).toRgbString();
            props.onChangedShadow(rgb);
        }
    }

    let styleControlAlignmentText = EStyleSheet.create({
        container:{

            flex:1
        },
        containerButton:{
            flex:1,
            marginBottom:'10rem',
            flexDirection:'row',
            marginLeft:'20rem',
            marginRight:'20rem'
          
        },
        item : {
            flex:1,
            flexDirection:'column',
            justifyContent:'center',
            alignItems:'center',
            
         
        },
       
    })

    let [lineHeight,setLineHeight] = useState(props.element[props.selectedIndex].props?.customStyle?.lineHeight || 0);
    useEffect(()=>{
        props.onLineHeightChange(lineHeight);
    },[lineHeight])

    let [letterSpacing,setLetterSpacing] = useState(props.element[props.selectedIndex].props?.customStyle?.letterSpacing || 0);
    useEffect(()=>{
        props.onLetterSpacingChange(letterSpacing);
    },[letterSpacing])

    return (
        <View style={style.containerEditTeks}>
        <View style={style.containerTopBar}>
            
                <View style={style.itemTopBar}>
                    <Text></Text>
                </View>
        
            <TouchableNativeFeedback onPress={()=>{
                props.backPressed();
            }}>
                <View style={style.itemTopBar}>
                    <AntDesign name="back" size={24} color="black" />
                </View>
            </TouchableNativeFeedback>
        </View>
        <View style={style.menuEditTeks}>
                <TouchableNativeFeedback onPress={()=>setOpenedTab(0)}>
                    <View style={style.itemMenuEditTeks}>
                        <Fontisto name="font" size={EStyleSheet.value('16rem')} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>setOpenedTab(1)}>
                    <View style={style.itemMenuEditTeks}>
                        <MaterialCommunityIcons name="text-shadow" size={EStyleSheet.value('24rem')} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>setOpenedTab(2)}>
                    <View style={style.itemMenuEditTeks}>
                        <Entypo name="text" size={EStyleSheet.value('23rem')} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>setOpenedTab(3)}>
                    <View style={style.itemMenuEditTeks}>
                     <Ionicons name="md-color-fill" size={24} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>setOpenedTab(4)}>
                    <View style={style.itemMenuEditTeks}>
                    <MaterialCommunityIcons name="screwdriver" size={24} color="black" />
                    </View>
                </TouchableNativeFeedback>
            </View>
            {
                (openedTab===0) ? 
                <View style={style.containerPilihFont}>
                <Swiper ref={refCategoryFont} loop={false} index={styleFontSelectedIndex} onIndexChanged={updateIndex} showsPagination={false}>
                    <View style={style.containerPilihFont2}>
                        <TouchableHighlight onPress={()=>{props.onPressFont("Turret")}}>
                            <View style={style.containerFont}>
                                <Text style={{fontFamily:'Turret'}}>Loreas</Text>
                            </View>
                        </TouchableHighlight>
                        <TouchableHighlight onPress={()=>{props.onPressFont("Oswald")}}>
                            <View style={style.containerFont}>
                                <Text style={{fontFamily:'Oswald'}}>Lorem Ipsum</Text>
                            </View>
                        </TouchableHighlight>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                    </View>
                    <View style={style.containerPilihFont2}>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                        <View style={style.containerFont}>
                            <Text>Lorem Ipsum</Text>
                        </View>
                    </View>
                </Swiper>
                <View style={style.containerJenisFont}>
                    <TouchableNativeFeedback onPress={()=>{handlePressCategoryFont(0)}}> 
                        <View style={[style.jenisFont,{backgroundColor: (styleFontSelectedIndex===0) ? 'grey':'#f4f4f2'}]}>
                            <Text style={{color:(styleFontSelectedIndex===0) ? 'white':'black'}}>Sans Serif</Text>
                        </View>
                    </TouchableNativeFeedback>
                    <TouchableNativeFeedback onPress={()=>{handlePressCategoryFont(1)}}> 
                        <View style={[style.jenisFont,{backgroundColor: (styleFontSelectedIndex===1) ? 'grey':'#f4f4f2'}]}>
                            <Text style={{color:(styleFontSelectedIndex===1) ? 'white':'black'}}>Comic Sans</Text>
                        </View>
                    </TouchableNativeFeedback>
                    
                </View>
            </View>:null
            }
            {
                (openedTab===1) ? 
                <View style={shadowControl.containerShadowControl}>
                    <View style={shadowControl.containerChild}>
                        <MaterialCommunityIcons  style={{paddingRight:EStyleSheet.value('15rem')}} name="text-shadow" size={24} color="black" />
                        <View style={{width:EStyleSheet.value('30rem'),flex:1,flexDirection:'row',justifyContent:'center'}}>
                                <View>
                                    <Text>H</Text>
                                    <TextInput value={`${hwrShadowText.h}`} onChangeText={(value)=>{inputHWRHandler(value,'h')}} placeholder={"h"}></TextInput>
                                </View>
                                <View>
                                    <Text>W</Text>
                                    <TextInput value={`${hwrShadowText.w}`} onChangeText={(value)=>{inputHWRHandler(value,'w')}} placeholder={"w"}></TextInput>
                                </View>
                                <View>
                                    <Text>R</Text>
                                    <TextInput value={`${hwrShadowText.r}`} onChangeText={(value)=>{inputHWRHandler(value,'r')}} placeholder={"r"}></TextInput>
                                </View>
                        </View>
                        <View style={{flex:3,height:'100%'}}>
                             <SliderHuePicker oldColor={oldColor} onColorChange={changeColor} trackStyle={[{height: 1}]} thumbStyle={style.thumb}/>
                             <SliderSaturationPicker style={{height: 1, borderRadius: 6, backgroundColor: tinycolor({h: tinycolor(oldColor).toHsv().h, s: 1, v: 1}).toHexString()}} oldColor={oldColor} onColorChange={changeColor} trackStyle={[{height: 1}]} thumbStyle={style.thumb}/>
                             <SliderValuePicker  oldColor={oldColor} minimumValue={0.02} step={0.05} style={{height: 1, borderRadius: 6, backgroundColor: 'black'}} trackImage={require('react-native-slider-color-picker/brightness_mask.png')} onColorChange={changeColor} trackStyle={[{height: 1}]} thumbStyle={style.thumb}/>
                        </View>
                    </View>
                    <View style={shadowControl.containerChild}>
                        <View style={{width:EStyleSheet.value('30rem'),height:'100%',justifyContent:'center',alignItems:'center'}}>
                            <Foundation name="background-color" size={24} color="black" />
                        </View>
                        <View style={{flex:1,height:'100%',justifyContent:'center',alignItems:'center'}}>
                            <CheckBox onValueChange={(value)=>{clickCheckboxBackgroundText(value)}} value={checkboxTextBackground}></CheckBox>
                        </View>
                        <View style={{flex:3,height:'100%'}}>
                             <SliderHuePicker oldColor={oldBackgroundColor} onColorChange={changeBackgroundColor} trackStyle={[{height: 1}]} thumbStyle={style.thumb}/>
                             <SliderSaturationPicker style={{height: 1, borderRadius: 6, backgroundColor: tinycolor({h: tinycolor(oldColor).toHsv().h, s: 1, v: 1}).toHexString()}} oldColor={oldBackgroundColor} onColorChange={changeBackgroundColor} trackStyle={[{height: 1}]} thumbStyle={style.thumb}/>
                             <SliderValuePicker  oldColor={oldBackgroundColor} minimumValue={0.02} step={0.05} style={{height: 1, borderRadius: 6, backgroundColor: 'black'}} trackImage={require('react-native-slider-color-picker/brightness_mask.png')} onColorChange={changeBackgroundColor} trackStyle={[{height: 1}]} thumbStyle={style.thumb}/>
                        </View>
                    </View>
                </View>
                
                :null
            }
            {
                (openedTab===2) ? 
                <View style={styleControlAlignmentText.container}>
                    <View style={styleControlAlignmentText.containerButton}>
                        <TouchableNativeFeedback 
                            onPress={()=>{props.onPress("left")}}>
                            <View style={styleControlAlignmentText.item}>
                                <Feather name="align-left" size={EStyleSheet.value("40rem")} color="black" />
                                <Text>Left</Text>
                            </View>
                        </TouchableNativeFeedback>
                        <TouchableNativeFeedback
                        onPress={()=>{props.onPress("center")}}>
                            <View style={styleControlAlignmentText.item}>
                                <Feather name="align-center" size={EStyleSheet.value("40rem")}  color="black" />
                                <Text>Center</Text>
                            </View>
                        </TouchableNativeFeedback>
                        <TouchableNativeFeedback
                        onPress={()=>{props.onPress("right")}}>
                            <View style={styleControlAlignmentText.item}>
                                <Feather name="align-right"size={EStyleSheet.value("40rem")}  color="black" />
                                <Text>Right</Text>
                            </View>
                        </TouchableNativeFeedback>
                        <TouchableNativeFeedback
                        onPress={()=>{props.onPress("justify")}}>
                            <View style={styleControlAlignmentText.item}>
                                <Feather name="align-justify" size={EStyleSheet.value("40rem")}  color="black" />
                                <Text>Justify</Text>
                            </View>
                        </TouchableNativeFeedback>
                    </View>
                </View>
                :null
            }
            {
                (openedTab===3) ? 
                    <TextColorPicker
                    onColorChange={(color)=>{
                        props.onTextColorChange(color);
                    }}
                    />
                :null
            }
            {
                (openedTab===4) ? 
                    <View style={{flex:1,paddingLeft:EStyleSheet.value('20rem'),paddingRight:EStyleSheet.value('20rem'),paddingTop:EStyleSheet.value('10rem')}}>
                        <View style={{flex:1,flexDirection:'row'}}>
                            <View style={{flex:1,borderRightWidth:1}}>
                                <Text style={{paddingLeft:EStyleSheet.value('2rem')}}>Font Style</Text>
                                <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
                                    <Pressable onPress={()=>{
                                        props.onChangeFontStyle("normal");
                                    }} style={{flex:1}}><View style={{justifyContent:'center',alignItems:'center'}}><MaterialCommunityIcons name="format-text-variant" size={24} color="black" /></View></Pressable>
                                    <Pressable onPress={()=>{
                                        props.onChangeFontStyle("italic");
                                    }} style={{flex:1}}><View style={{justifyContent:'center',alignItems:'center'}}><MaterialIcons name="format-italic" size={24} color="black" /></View></Pressable>                
                                </View>
                            </View>
                            <View style={{flex:1}}>
                            <Text style={{paddingLeft:EStyleSheet.value('15rem')}}>Text Decoration</Text>
                                <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
                                    <Pressable onPress={()=>{
                                        props.onChangeTextDecoration("line-through")
                                    }} style={{flex:1}}><View style={{flex:1,justifyContent:'center',alignItems:'center'}}><MaterialIcons name="strikethrough-s" size={28} color="black" /></View></Pressable>
                                    <Pressable onPress={()=>{
                                        props.onChangeTextDecoration("underline")
                                    }} style={{flex:1}}><View style={{justifyContent:'center',alignItems:'center'}}><MaterialIcons name="format-underlined" size={24} color="black" /></View></Pressable>
                                </View>
                            </View>
                        </View>
                        <View style={{flex:1,flexDirection:'row'}}>
                            <View style={{flex:1,borderRightWidth:1}}>
                                    <Text style={{paddingLeft:EStyleSheet.value('2rem')}}>Text Spacing</Text>
                                    <View style={{flex:1,flexDirection:'row',justifyContent:'center',paddingLeft:EStyleSheet.value('18rem'),alignItems:'center'}}>
                                        <View style={{justifyContent:'center',alignItems:'center'}}><FontAwesome name="text-width" size={24} color="black" /></View>
                                        <View style={{flex:1,flexDirection:'row',marginLeft:EStyleSheet.value('25rem')}}>
                                            <TouchableNativeFeedback onPress={()=>{
                                                (letterSpacing===0) ? setLetterSpacing(0):setLetterSpacing(letterSpacing-1);
                                            }}><View style={{justifyContent:'center',alignItems:'center',backgroundColor:'grey',borderRadius:3,width:EStyleSheet.value('30rem'),height:EStyleSheet.value('30rem')}}><AntDesign name="left" size={24} color="white" /></View></TouchableNativeFeedback>
                                            <TextInput editable={false} style={{textAlign:'center'}} value={`${letterSpacing}`}></TextInput>
                                            <TouchableNativeFeedback onPress={()=>{
                                                setLetterSpacing(letterSpacing+1);
                                            }}><View style={{justifyContent:'center',alignItems:'center',backgroundColor:'grey',borderRadius:3,width:EStyleSheet.value('30rem'),height:EStyleSheet.value('30rem')}}><AntDesign name="right" size={24} color="white" /></View></TouchableNativeFeedback>
                                        </View>
                                    </View>
                                </View>
                        <View style={{flex:1}}>
                                <Text style={{paddingLeft:EStyleSheet.value('15rem')}}>Line Height</Text>
                                    <View style={{paddingLeft:EStyleSheet.value('25rem'),flex:1,flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
                                        <View style={{justifyContent:'center',alignItems:'center'}}><FontAwesome name="text-height" size={24} color="black" /></View>
                                        <View style={{flex:1,flexDirection:'row',marginLeft:EStyleSheet.value('25rem')}}>
                                        <TouchableNativeFeedback onPress={()=>{
                                            (lineHeight===0) ? setLineHeight(0):setLineHeight(lineHeight-1);
                                        }}><View style={{justifyContent:'center',alignItems:'center',backgroundColor:'grey',borderRadius:3,width:EStyleSheet.value('30rem'),height:EStyleSheet.value('30rem')}}><AntDesign name="left" size={24} color="white" /></View></TouchableNativeFeedback>
                                            <TextInput editable={false} style={{textAlign:'center'}} value={`${lineHeight}`}></TextInput>
                                            <TouchableNativeFeedback onPress={()=>{
                                            setLineHeight(lineHeight+1);
                                        }}><View style={{justifyContent:'center',alignItems:'center',backgroundColor:'grey',borderRadius:3,width:EStyleSheet.value('30rem'),height:EStyleSheet.value('30rem')}}><AntDesign name="right" size={24} color="white" /></View></TouchableNativeFeedback>
                                        </View>
                                    </View>
                        </View>
                        
                        </View>
                    </View>:null
            }
          
</View>
    )
}


class TextColorPicker extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        hue: 1,
        sat: 1,
        val: 1,
      };
      this.onSatValPickerChange = this.onSatValPickerChange.bind(this);
      this.onHuePickerChange = this.onHuePickerChange.bind(this);
    }
  
    onSatValPickerChange({ saturation, value }) {
      this.setState({
        sat: saturation,
        val: value,
      });
      this.props.onColorChange(tinycolor({h:this.state.hue,s:this.state.sat,v:this.state.val}).toRgbString());
    }
  
    onHuePickerChange({ hue }) {
      this.setState({
        hue,
      });
      console.log(tinycolor({h:this.state.hue,s:this.state.sat,v:this.state.val}).toRgbString());
    }
  
    render() {
      const { hue, sat, val } = this.state;
      return (
        <View>
          <HsvColorPicker
            satValPickerSize={EStyleSheet.value('100rem')}
            satValPickerSliderSize={EStyleSheet.value('10rem')}
            huePickerBarHeight={EStyleSheet.value('100rem')}
            huePickerSliderSize={EStyleSheet.value('20rem')}
            width={EStyleSheet.value('310rem')}
            huePickerHue={hue}
            onHuePickerDragMove={this.onHuePickerChange}
            onHuePickerPress={this.onHuePickerChange}
            satValPickerHue={hue}
            satValPickerSaturation={sat}
            satValPickerValue={val}
            onSatValPickerDragMove={this.onSatValPickerChange}
            onSatValPickerPress={this.onSatValPickerChange}
          />
        </View>
      );
    }
  }

  

export default function Canvas(props){
    const windowHeight = useWindowDimensions().height;
    const refRBSheetTambahStiker = useRef();
    let currentEvent = ""

    let _canvasView = useRef();
    
    useEffect(()=>{
        if(props.route.params.template){
            setElement(props.route.params.template.data);
        }
    },[])



    let [currentJob, setCurrentJob] = useState('');

    let [uniqueRenderKey, setUniqueRenderKey] = useState(666);


    let [element,setElement] = useState([]);


    useEffect(() => {
        const backAction = () => {
          if(currentJob==="chooseBackground"){
              props.route.params.function.updateMyStory();
              return false;
          }else{
            Alert.alert("Sebentar!", "Ingin menyimpan hasil editan ini?", [
                {
                    text: "Batal",
                    onPress: () => false,
                    style: "cancel"
                  },
                {
                  text: "Tidak",
                  onPress: () => {
                      props.route.params.function.updateMyStory();
                      props.route.params.function.setDisplayMenuDashboard(props.route.params.indexDashboard);
                      props.navigation.goBack();
                },
                  style: "cancel"
                },
                { text: "Iya", onPress: () => {
                    AsyncStorage.getItem("mystory",(err,result)=>{
                        if(result===null){
                            captureRef(_canvasView, {
                                format: "jpg",
                                quality: 0.8
                              }).then(
                                uri => {
                                    let payload = {
                                        name:`My Story - ${1}`,
                                        canvas:"portrait",
                                        background:"",
                                        preview:uri,
                                        data: element
                                    };
        
                                    let template = {
                                        templatesName:"My Story",
                                        item: [
                                            payload
                                        ]
                                    }
                                    AsyncStorage.setItem("mystory", JSON.stringify(template));
                                    props.route.params.function.updateMyStory();
                                    props.route.params.function.setCurrentIndexMenu(props.route.params.indexDashboard);
                                    props.navigation.goBack();
                                },
                                error => console.error("Oops, snapshot failed", error)
                              );

                        }else{  
                            let parsed = JSON.parse(result);
                            captureRef(_canvasView, {
                                format: "jpg",
                                quality: 0.8
                              }).then(
                                uri => {
                                    let payload = {
                                        name:`My Story - ${parsed.item.length+1}`,
                                        canvas:"portrait",
                                        background:"",
                                        preview:uri,
                                        data: element
                                    };
                                    
                                    let template = {
                                        ...parsed,
                                        item: [
                                            ...parsed.item,
                                            payload
                                        ]
                                    }

                                    AsyncStorage.setItem("mystory", JSON.stringify(template));
                                    props.route.params.function.updateMyStory();
                                    props.route.params.function.setCurrentIndexMenu(props.route.params.indexDashboard);
                                    props.navigation.goBack();

                                },
                                error => console.error("Oops, snapshot failed", error)
                              );

                        
                        
                        }
                    })
                    //console.log(element);
                } }
              ]);
              return true;
          }
        };
    
        const backHandler = BackHandler.addEventListener(
          "hardwareBackPress",
          backAction
        );
    
        return () => backHandler.remove();
      }, [element]);
    

    let [currentSelectedIndex, setCurrentSelectedIndex] = useState(-1);
    
    useEffect(()=>{
        
    },[element])
  
    let resetBoundingTextBox = (key) =>{
       setElement((data)=>{
            return data.map((item,index)=> {
                if(index===key){
                    return {...item,props:{...item.props,modeEdit:true}}
                } else{
                    return {...item,props:{...item.props,modeEdit:false}}
                }
               
            })  
       })
       setCurrentSelectedIndex(key);
    }

    let tambahGambar = (payload)=>{
        let {type,uri} = payload;
        if(type==='localFile'){
            FileSystem.getInfoAsync(FileSystem.documentDirectory+uri).then((res)=>{
                AsyncStorage.getItem('testing',(a,b)=>{
                        console.log(b);
                })
            })
        }
        else if(type==='remoteFile'){
            setElement((ele)=>{
                return [...ele,{
                    type:'image',
                    uri:uri,
                    props: {
                        modeEdit:false,
                        customStyle : {
                            zIndex:(element.length===0) ? 0:element.length,
                            elevation:(element.length===0) ? 0:element.length
                        },
                        positionStyle : {
                            sliderWidth:250,
                            "left": 0,
                            "position": "absolute",
                            "top": 0,
                            "transform": [{
                                "scale": 1,
                                "rotate":"0deg"
                              }],
                        }
                    }           
                }]
            })
        }
    }

    let tambahTeks = ()=>{
        setElement((el)=>{
            return [...el,{
                type:'text',
                props: {
                    modeEdit:false,
                    text:"",
                    customStyle : {
                        textAlign:'center',
                        fontFamily:'Roboto',
                        zIndex:(element.length===0) ? 0:element.length,   
                        textShadowColor: 'rgba(0, 0, 0, 0.75)',
                        textShadowOffset: {width: 0, height: 0},
                        textShadowRadius: 0,
                        fontStyle:'normal',
                        textDecorationLine:'none',
                        letterSpacing:0,
                        lineHeight:50
                    },
                    positionStyle : {
                        sliderWidth:250,
                        "left": 0,
                        "position": "absolute",
                        "top": 0,
                        "transform": [{
                            "scale": 1,
                          }],
                    }
                }           
            }]
        })
    }

    let handlingDeleteImage = (i)=>{
        setElement((ele)=>{
            return ele.filter((el,index)=>{
                return i!==index;
            })
        })
        setCurrentJob("");
        
    }

    let handlingDuplicateImage = (i)=>{
        setElement((ele)=>{
            let duplicate = {...ele[i]};
            duplicate.props.positionStyle.top=duplicate.props.positionStyle.top-50;
            return [...ele,duplicate];
        })
    }

    let handlingTextChange = (text,i)=>{
        setElement((ele)=>{
            return ele.map((el,index)=>{
                if(i===index){
                    return {
                        ...el,
                        props :{
                            ...el.props,
                            text:text
                        }
                    }
                }
                return el;
            })
        })
    }


    
    let handlingTextDelete = (text,i)=>{
        setElement((ele)=>{
            return ele.filter((el,index)=>{
                return i!==index;
            })
        })
        dummyTextInput.focus();
        dummyTextInput.blur();
        setCurrentJob("");
    }

    let handlingOnDragEnd = (style,index) =>{
        setElement((ele)=>{
            let a =  ele.map((val,i)=>{
                if(i===index){
                    return {
                        ...val,
                        props : {
                            ...val.props,
                            positionStyle :{
                                ...val.props.positionStyle,
                                left:style.left,
                                top:style.top,
                                transform: [{
                                    scale:style.transform[0].scale || 1,
                                    rotate:(style.transform[1].rotate===undefined) ? "0deg":style.transform[1].rotate
                                }]
                            }
                            
                        
                        }
                    }
                }
                return val;
            });
            return a;
        })
        //console.log(element);
    }

    let handlingDuplicateText = (text,i)=>{
        setElement((ele)=>{
            let duplicate = {...ele[i]};
            return [...ele,duplicate];
        })
    }

    let handlingOnSliding = (w,index) =>{
        setElement((el)=>{
            return el.map((l,i)=>{
                if(i===index){
                    return {
                        ...l,
                        props:{
                            ...l.props,
                            positionStyle : {
                                ...l.props.positionStyle,
                                sliderWidth:w
                            }
                        }
                    }
                }
                return l;
            })
        })
        //console.log(element);
    }


    let dummyTextInput = useRef();

    setStyleFontToComponent = (font,index) =>{
        setElement((ele)=>{
            let a =  ele.map((val,i)=>{
                if(i===index){
                    return {
                        ...val,
                        props : {
                            ...val.props,
                            customStyle : {
                                ...val.props.customStyle,
                                fontFamily:font,
                    
                            }
                        
                        }
                    }
                }
                return val;
            });
            return a;
        })
    }

    let [querySticker, setQuerySticker] = useState("");    

    let [layerPosition,setLayerPosition] = useState(element[currentSelectedIndex]?.props.customStyle.zIndex || 0)
    let [isStickerLoading, setIsStickerLoading] = useState(false);
    let [stickerCategory, setStickerCategory] = useState([
        {name:"All",active:true},
        {name:"Covid-19",active:false},
        {name:"Brush",active:false},
        {name:"Line",active:false},
        {name:"Background",active:false},
    ]);
    let [sticker,setSticker] = useState({
        item:[],
        hasNextPage:false,
        currentPage:-1
    })


    // let scalePosition = (position)=>{
    //     let offsetHeight = sizeCanvas.h-46;
    //     if(position>offsetHeight){
    //         let portion = sizeCanvas.h-position;
    //         return position-Math.abs(portion);
    //     }
    //     return position;
    // }

    // let scalePositionFromSource = (sourceCanvas,position)=>{
    //     if(sourceCanvas>sizeCanvas.h){
    //         let portion = sizeCanvas.h-position;
    //         return (position-verticalScale(portion))-46;
    //     }
    //     return position;
    // }


    let searchStickerFromQuery = (query)=>{
        setIsStickerLoading(true);
        fetch(`http://192.168.43.68:3000/sticker?page=1&category=${query}`,
        {method:"GET",})
        .then((response)=>response.json())
        .then(({success,data})=>{
            setSticker(data);
            setIsStickerLoading(false);
        }).catch((err)=>{
            alert(err.message);
        })
    }
    let setCategoryStickerSelected = (index)=>{
        setStickerCategory((prev)=>{
            return prev.map((el,i)=>{
                if(i===index){
                    return {
                        ...el,
                        active:true
                    }
                }else{
                    return {
                        ...el,
                        active:false
                    }
                }
            })
        })
        let category = stickerCategory[index].name;
        setIsStickerLoading(true);
        setQuerySticker(category);
        if(category!=="All"){
            fetch(`http://192.168.43.68:3000/sticker?page=1&category=${category}`,
            {method:"GET",})
            .then((response)=>response.json())
            .then(({success,data})=>{
                setSticker(data);
                setIsStickerLoading(false);
            }).catch((err)=>{
                alert(err.message);
            })
        } else{
            fetch(`http://192.168.43.68:3000/sticker?page=1`,
            {method:"GET",})
            .then((response)=>response.json())
            .then(({success,data})=>{
                setSticker(data);
                setIsStickerLoading(false);
            }).catch((err)=>{
                alert(err.message);
            })
        }
       
    }

    let [sizeCanvas,setSizeCanvas] = useState({w:0,h:0})

    // useEffect(()=>{
    //     setUniqueRenderKey(Math.random());
    // },[sizeCanvas])
 
    const [loaded] = useFonts({
        Roboto: require('./assets/Roboto-Regular.ttf'),
        Turret:require('./assets/TurretRoad-Regular.ttf'),
        Oswald:require('./assets/Oswald-VariableFont_wght.ttf')
    });
    

  if (!loaded) {
    return null;
  }




    return (
    <View style={{flex:1,minHeight: Math.round(windowHeight)}}>
        <View style={{flex:1}}>
            <View style={style.containerCanvasAtas}>
                <View style={toolboxAtas.paddingAtas}></View>
        
                {
                    (currentJob==="editingimage" || currentJob==="editingtext") ?  <View style={toolboxAtas.container}>
                    {
                     (currentJob==="editingimage") ? <View style={toolboxAtas.itemContainer}><MaterialCommunityIcons name="file-replace-outline" size={24} color="black" /></View>
                     :null
                    }
                    <View style={[{alignItems:'flex-end',flexDirection:'row',justifyContent:'flex-end'},toolboxAtas.itemContainer]}>
                       
                        <TouchableNativeFeedback
                        onPress={()=>{
                            if(layerPosition!=0){
                                setLayerPosition(layerPosition-1);
                                let currentIndex = currentSelectedIndex;
                                setElement((ele)=>{
                                    return ele.map((el,index)=>{
                                        if(index===currentIndex){
                                            return {
                                                ...el,
                                                props :{
                                                    ...el.props,
                                                    customStyle : {
                                                        ...el.props.customStyle,
                                                        zIndex:layerPosition-1
                                                    }
                                                }
                                            }
                                        }
                                        return el;
                                    })
                                })
                                setUniqueRenderKey(Math.random());
                            }
                        }}
                        ><View style={{marginRight:EStyleSheet.value('10rem')}}><MaterialCommunityIcons name="layers-minus" size={24} color="black" /></View></TouchableNativeFeedback>
                        <Text style={{fontSize:EStyleSheet.value('20rem')}}>{layerPosition}</Text>
                        <TouchableNativeFeedback
                        onPress={()=>{
                            setLayerPosition(layerPosition+1);
                                let currentIndex = currentSelectedIndex;
                                setElement((ele)=>{
                                    return ele.map((el,index)=>{
                                        if(index===currentIndex){
                                            return {
                                                ...el,
                                                props :{
                                                    ...el.props,
                                                    customStyle : {
                                                        ...el.props.customStyle,
                                                        zIndex:layerPosition+1
                                                    }
                                                }
                                            }
                                        }
                                        return el;
                                    })
                                })
                                setUniqueRenderKey(Math.random());
                        }}
                        ><View style={{marginLeft:EStyleSheet.value('10rem')}}><MaterialCommunityIcons name="layers-plus" size={24} color="black" /></View></TouchableNativeFeedback>
                    </View>
                </View>:
                <View style={toolboxAtas.container}>
                        <AntDesign name="pluscircleo" size={24} color="black" />
                    </View>
                }
               
            </View>
            <View style={style.containerCanvasTengah}>
                <View style={style.containerCanvasOffsetKiri}></View>
                <ImageBackground 
                resizeMode='stretch'
                source={{uri:(props.route.params.background.length>0) ? props.route.params.background:null}}
                onLayout={(e)=>{
                    setSizeCanvas({
                        w:e.nativeEvent.layout.width,
                        h:e.nativeEvent.layout.height
                    })
                }} ref={(ref)=>{_canvasView=ref}} style={style.containerCanvas}>

                    <TextInput ref={(ref)=>{dummyTextInput=ref}} style={{display:'none'}}>
                        dummyTextInput
                    </TextInput>
                    {
                        element.map((el,i)=>{
                            if(el.type==="text"){
                                return (
                                    <Testing3
                                    onSlidingComplete={
                                        (w)=>{
                                            handlingOnSliding(w,i);
                                        }
                                    }
                                    positionStyle={{
                                        ...el.props.positionStyle,
                    
                                    }}
                                    onEndDrag={
                                        (e,style)=>{
                                            handlingOnDragEnd(style,i);
                                        }
                                    }
                                    onDuplicateText={()=>{
                                        handlingDuplicateText(text,i);
                                    }}
                                    onDelete={()=>{
                                        handlingTextDelete(text,i);
                                    }}
                                    onChangeText={(text)=>{
                                        handlingTextChange(text,i);
                                    }}
                                    key={i+`textedit-${uniqueRenderKey}`}
                                    customStyle={{...el.props.customStyle}}
                                    zIndex={el.props.customStyle.zIndex}
                                     onFocus={()=>{
                                         setCurrentSelectedIndex(i);
                                         resetBoundingTextBox(i);
                                         setLayerPosition(element[i]?.props.customStyle.zIndex)
                                        setCurrentJob("editingtext"); 
                                        console.log(element);
                                        
                                         }} 
                                    pointer={el.props.pointer} 
                                    text={el.props.text} 
                                    top={el.props.top} 
                                    left={el.props.left} 
                                    editMode={el.props.modeEdit}/>
                                )
                            }
                            else if(el.type==="image"){
                                return (
                                    <Testing6
                                        key={i+`image-${uniqueRenderKey}`}
                                        uri={el.uri}
                                        positionStyle={{
                                            ...el.props.positionStyle,
                                        }}
                                        editMode={el.props.modeEdit}
                                        customStyle={el.props.customStyle}
                                        zIndex={el.props.customStyle.zIndex}
                                        onEndDrag={
                                            (e,style)=>{
                                                handlingOnDragEnd(style,i);
                                             
                                            }
                                        }
                                        onDuplicate={()=>{
                                            handlingDuplicateImage(i);
                                        }}
                                        onDelete={()=>{
                                                handlingDeleteImage(i);
                                        }}
                                        onPress={()=>{
                                            
                                            if(currentJob==='editingimage' && currentSelectedIndex===i){
                                                resetBoundingTextBox(-1);
                                                setCurrentJob(""); 
                                                dummyTextInput.focus();
                                                dummyTextInput.blur();
                                            }else{
                                                setCurrentSelectedIndex(i);
                                                resetBoundingTextBox(i);
                                                setLayerPosition(element[i]?.props.customStyle.zIndex);
                                                setCurrentJob("editingimage"); 
                                                dummyTextInput.focus();
                                                dummyTextInput.blur();
                                            }
                                            //alert(currentJob);
                                        }}
                                        onChange={(e,style)=>{
                                            //console.log('changed');
                                
                                        }}
                                    />
                                )
                            }
                        })
                    }
                </ImageBackground>
                <View style={style.containerCanvasOffsetKanan}></View>
            </View>
            <View style={style.containerCanvasBawah}></View>
            <View style={style.bottomBar}>
                <TouchableNativeFeedback onPress={()=>{
                        setUniqueRenderKey(Math.random());
                        alert("ulalala");
                }}>
                    <View style={style.tombolNavigasiCanvas}>
                        <AntDesign name="left" size={EStyleSheet.value('20rem')} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>{tambahTeks();}}>
                    <View style={style.tombolNavigasiCanvas}>
                        <FontAwesome name="font" size={EStyleSheet.value('20rem')} color="black" />
                        <Octicons style={{position:'absolute',alignSelf:'center',top:EStyleSheet.value(`15rem`),right:EStyleSheet.value('25rem')}} name="plus-small" size={24} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>{
                        refRBSheetTambahStiker.current.open();
                        if(sticker.item.length===0){
                            setIsStickerLoading(true);
                            fetch("http://192.168.43.68:3000/sticker?page=1",{
                                method:"GET",
                            }).then((response)=>response.json())
                            .then(({success,data})=>{
                                setSticker(data);
                                setIsStickerLoading(false);
                            }).catch((err)=>{
                                alert(err.message);
                            })
                        }
                      
                    
                    }}>
                    <View style={style.tombolNavigasiCanvas}>
                        <MaterialCommunityIcons name="sticker" size={EStyleSheet.value('20rem')} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>{
                    Permissions.getAsync(Permissions.CAMERA_ROLL).then(({status})=>{
                        if(status==="denied"){
                            Permissions.askAsync(Permissions.CAMERA_ROLL).then(({status,permissions})=>{
                                if(status!=='denied'){
                                    setCurrentJob("chooseBackground");
                                }
                            })
                        }
                        else if(status==="granted"){
                            setCurrentJob("chooseBackground");
                        }
                    })
                }}>
                    <View style={style.tombolNavigasiCanvas}>
                        <Ionicons name="md-color-fill" size={EStyleSheet.value('20rem')} color="black" />
                    </View>
                </TouchableNativeFeedback>
                <TouchableNativeFeedback onPress={()=>{
                    console.log(element);
                }}>
                    <View style={style.tombolNavigasiCanvas}>
                        <Feather name="download" size={EStyleSheet.value('20rem')} color="black" />
                    </View>
                </TouchableNativeFeedback>
            </View>
           
           
            {
                (currentJob==="chooseBackground") ? 
                <CanvasChooseBackgroundColor 
                onFinishFilter={(result)=>{
                    //alert(result.uri)
                    tambahGambar({
                        type:"remoteFile",
                        uri:result.uri
                    });
                }}
                onClose={()=>{setCurrentJob("");}}
                navigation={props.navigation}/>:null
            }
            {
                (currentJob==='editingtext') ? 
                <CanvasTextEdit 
                onLineHeightChange={(value)=>{
                    let currentIndex = currentSelectedIndex;
                    setElement((ele)=>{
                        return ele.map((el,i)=>{
                            if(i===currentIndex){
                                return {
                                    ...el,
                                    props:{
                                        ...el.props,
                                        customStyle:{
                                            ...el.props.customStyle,
                                            lineHeight:value
                                        }
                                    }
                                }
                            }
                            return el;
                        })
                    })
                }}
                onLetterSpacingChange={(value)=>{
                    let currentIndex = currentSelectedIndex;
                    setElement((ele)=>{
                        return ele.map((el,i)=>{
                            if(i===currentIndex){
                                return {
                                    ...el,
                                    props:{
                                        ...el.props,
                                        customStyle:{
                                            ...el.props.customStyle,
                                            letterSpacing:value
                                        }
                                    }
                                }
                            }
                            return el;
                        })
                    })
                }}
                onChangeTextDecoration={(style)=>{
                    let currentIndex = currentSelectedIndex;
                    if(element[currentIndex].props.customStyle?.textDecorationLine===undefined){
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                textDecorationLine:style
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }
                    else if(element[currentIndex].props.customStyle?.textDecorationLine===style){
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                textDecorationLine:'none'
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }else{
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                textDecorationLine:style
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }
                   
                }}
                onChangeFontStyle={(style)=>{
                    let currentIndex = currentSelectedIndex;
                    if(element[currentIndex].props.customStyle?.fontStyle===undefined){
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                fontStyle:style
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }
                    else if(element[currentIndex].props.customStyle?.fontStyle===style){
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                fontStyle:'normal'
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }else{
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                fontStyle:style
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }
                   
                }}
                onTextColorChange={(rgb)=>{
                    let currentIndex = currentSelectedIndex;
                    setElement((ele)=>{
                        return ele.map((el,i)=>{
                            if(i===currentIndex){
                                return {
                                    ...el,
                                    props:{
                                        ...el.props,
                                        customStyle:{
                                            ...el.props.customStyle,
                                            color:rgb
                                        }
                                    }
                                }
                            }
                            return el;
                        })
                    })
                }}
                onClickedChecboxTextBackground={(value, checked)=>{
                    let currentIndex = currentSelectedIndex;
                    if(checked===true){
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                backgroundColor:value
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }else{
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                backgroundColor:undefined
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }
                    
                }}
                onChangedTextBackgroundColor={(value, truthy)=>{
                    if(truthy===true){
                        setElement((ele)=>{
                            return ele.map((el,i)=>{
                                if(i===currentSelectedIndex){
                                    return {
                                        ...el,
                                        props:{
                                            ...el.props,
                                            customStyle:{
                                                ...el.props.customStyle,
                                                backgroundColor:value
                                            }
                                        }
                                    }
                                }
                                return el;
                            })
                        })
                    }
                }}
                onChangeHWRShadowValue={(value)=>{
                    let {h,w,r} = value;
                    h = (parseInt(h).toString()==='NaN') ? 0:parseInt(h);
                    w = (parseInt(w).toString()==='NaN') ? 0:parseInt(w);
                    r = (parseInt(r).toString()==='NaN') ? 0:parseInt(r);
                    setElement((ele)=>{
                        return ele.map((el,i)=>{
                            if(i===currentSelectedIndex){
                                return {
                                    ...el,
                                    props : {
                                        ...el.props,
                                        customStyle:{
                                            ...el.props.customStyle,
                                            textShadowOffset: {width: w, height: h},
                                            textShadowRadius: r
                                        }
                                    }
                                }
                            }
                            return el;
                        })
                    })

                }}
                onChangedShadow={(rgb)=>{
                    setElement((ele)=>{
                        return ele.map((el,i)=>{
                            if(i===currentSelectedIndex){
                                return {
                                    ...el,
                                    props : {
                                        ...el.props,
                                        customStyle:{
                                            ...el.props.customStyle,
                                            textShadowColor: rgb,
                                        }
                                    }
                                }
                            }
                            return el;
                        })
                    })
                }}
                onPressFont={(font,index)=>{
                    setStyleFontToComponent(font,currentSelectedIndex);
                }}
                backPressed={()=>{
                    setCurrentSelectedIndex(-1);
                    resetBoundingTextBox(-1);
                    setCurrentJob(""); 
                    dummyTextInput.focus();
                    dummyTextInput.blur();
                }}
                onPress={(element)=>{
                    let index = currentSelectedIndex;
                    setElement((ele)=>{
                        return ele.map((val,i)=>{
                            if(i===index){
                                return {
                                    ...val,
                                    props : {
                                        ...val.props,
                                        customStyle : {
                                            ...val.props.customStyle,
                                            textAlign:element
                                        },
                                        positionStyle :{
                                            ...val.props.positionStyle
                                        }
                                    
                                    }
                                }
                            }
                            return val;
                        })
                    })

                }}
                element={element}
                selectedIndex={currentSelectedIndex}
                />
                : null
            }
            
            <RBSheet
                ref={refRBSheetTambahStiker}
                closeOnDragDown={true}
                closeOnPressMask={false}
                dragFromTopOnly={true}
                height={EStyleSheet.value('330rem')}
                customStyles={{
                wrapper: {
                    backgroundColor: "transparent"
                },
                draggableIcon: {
                    backgroundColor: "#f4f4f2"
                },
                container: {
                    borderTopRightRadius:15,
                    borderTopLeftRadius:15,
                    backgroundColor:'white',
                    shadowColor: "#000",
                    borderRadius:2,
                    shadowOffset: {
                        width: 5,
                        height: 12,
                    },
                    shadowOpacity: 5,
                    shadowRadius: 2.22,

                    elevation: 20,
                    }
                }}
            >
            <View style={modalTambahStiker.containerStiker}>
                <View style={modalTambahStiker.containerSearchBar}>
                    <View style={modalTambahStiker.childContainerSearchBar}>
                        <View style={{justifyContent:'center',alignItems:'center',height:'100%',width:EStyleSheet.value("20rem")}}>
                            <AntDesign name="search1" size={EStyleSheet.value('18rem')} color="black" />
                        </View>
                        <View style={{justifyContent:'center',flex:1,height:'100%'}}>
                            <TextInput onSubmitEditing={()=>{
                                searchStickerFromQuery(querySticker);
                            }} onChangeText={(text)=>{setQuerySticker(text)}} style={{paddingLeft:EStyleSheet.value('10rem'),fontSize:EStyleSheet.value('15rem')}} value={querySticker} placeholder="Masukkan kata kunci stiker..."></TextInput>
                        </View>
                    </View>
                </View>
                <View style={modalTambahStiker.containerCategorySticker}>
                     <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} nestedScrollEnabled={true} style={modalTambahStiker.containerBallonCategorySticker}>
                            <FlatList
                            nestedScrollEnabled={true} 
                            keyExtractor={({item})=>`StickerCategory - ${item}`}
                            data={stickerCategory}
                            style={{flexDirection:'row'}}
                            numColumns={100}
                            renderItem={({item,index})=>{
                                if(item.active){
                                    return (
                                        <View keys={`StickerCategory - ${item.name}`} style={modalTambahStiker.ballonCategory_active}>
                                            <Text>{item.name}</Text>
                                        </View>
                                    )
                                }else{
                                    return (
                                        <Pressable onPress={()=>{setCategoryStickerSelected(index)}}>
                                            <View keys={`StickerCategory - ${item.name}`}  style={modalTambahStiker.ballonCategory_disabled}>
                                                <Text>{item.name}</Text>
                                            </View>
                                        </Pressable>
                                    )
                                }
                              
                            }}
                            />
                     </ScrollView>
                </View>
                <View style={modalTambahStiker.containerKotakIsiStiker}>
                        {
                            (isStickerLoading===false) ?
                            (
                                <View style={{marginBottom:EStyleSheet.value('100rem')}}>

                                <FlatList
                                    numColumns={3}
                                    data={sticker.item}
                                    keyExtractor={(item)=>`Sticker - ${item.id_stiker}`}
                                    onEndReached={()=>{
                                        if(sticker.hasNextPage){
                                            //alert(`http://192.168.43.68:3000/sticker?page=${parseInt(sticker.currentPage)+1}`);
                                            fetch(`http://192.168.43.68:3000/sticker?page=${parseInt(sticker.currentPage)+1}`,{
                                                method:"GET",
                                            }).then((response)=>response.json())
                                            .then(({success,data})=>{
                                                console.log(data);
                                                setSticker((prev)=>{
                                                    return {
                                                        ...data,
                                                        item:[
                                                            ...prev.item,
                                                            ...data.item
                                                        ]
                                                    }
                                                });
                                            }).catch((err)=>{
                                                alert(err.message);
                                            })
                                        }else{
                                            //alert("tidak ada");
                                        }
                                    }}
                                    renderItem={({item,index})=>{
                                        return (
                                            <TouchableHighlight activeOpacity={0} underlayColor='white' onPress={()=>{
                                                tambahGambar({
                                                    type:item.filetype,
                                                    uri:item.uri
                                                });
                                            }}>
                                                <View style={modalTambahStiker.kotakItemStiker}>
                                                    <Image resizeMode='contain' style={{width:EStyleSheet.value('50rem'),height:EStyleSheet.value('50rem')}} source={{uri:item.uri}}></Image>
                                                </View>
                                            </TouchableHighlight>
                                        )
                                    }}
                                />
                                    

                               
                                </View>
                            ):
                            <View style={{justifyContent:'center',alignItems:'center',height:EStyleSheet.value('200rem')}}>
                                <ActivityIndicator size="large" color="grey" />
                            </View>
                        }
                </View>
            </View>
      </RBSheet>

        </View>
    </View>
    )
}