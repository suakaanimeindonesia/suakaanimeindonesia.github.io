import React from 'react';
import { Animated, StyleSheet, View, Text, Image, Dimensions, TouchableHighlight, TouchableOpacity } from 'react-native';
import Gestures from 'react-native-easy-gestures';
import {DragResizeBlock,} from 'react-native-drag-resize';
import { Ionicons } from '@expo/vector-icons';
import { Entypo, MaterialIcons, FontAwesome } from '@expo/vector-icons'; 
import { MaterialCommunityIcons } from '@expo/vector-icons'; 

import {
  PanGestureHandler,
  PinchGestureHandler,
  RotationGestureHandler,
  State,
} from 'react-native-gesture-handler';

import EStyleSheet from 'react-native-extended-stylesheet';


const entireScreenWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: entireScreenWidth / 380});


export default class Testing2 extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            editMode : this.props.editMode || false,
            image : this.props.image || 'https://cdn-brilio-net.akamaized.net/news/2020/05/06/183987/8-cara-mudah-gambar-hewan-cuma-pakai-jari-hasilnya-keren-2005062.jpg',
            width: this.props.width|| 1280,
            height: this.props.height || 720,
            _delete: this.props.delete || null,
            _duplicate: this.props.duplicate || null,
            _change: this.props.change || null,
            _hideline: this.props.hideline || null,
        }
    }

    connectorT = React.createRef();

    style = EStyleSheet.create({

    })

    render(){
        return (
            <View style={{flex:1}}>
                    <Gestures style={{width:EStyleSheet.value(`${(this.state.width/5)+30}rem`),height:EStyleSheet.value(`${(this.state.height/5)+30}rem`),paddingLeft:EStyleSheet.value("16rem"),paddingTop:EStyleSheet.value("16rem")}} scalable={{min: 0.1, max: 7,}}>
                        <View style={{width:EStyleSheet.value(`${this.state.width/5}rem`),height:EStyleSheet.value(`${this.state.height/5}rem`)}}>
                            <TouchableHighlight onPressIn={()=>{this.setState({
                                editMode : true
                            })}}>
                                <Image style={{width:'100%',height:'100%'}} source={{uri:this.state.image}}></Image>
                            </TouchableHighlight>
                            {
                                (this.state.editMode==true) ?  <View style={{width:EStyleSheet.value(`${(this.state.width/5)+20}rem`),height:EStyleSheet.value(`${(this.state.height/5)+20}rem`),borderRadius:1,position:'absolute',left:EStyleSheet.value(`-10rem`),top:EStyleSheet.value(`-10rem`),borderStyle:'dashed',borderWidth:0.5}}></View>:null
                            }
                            {
                                //Kiri Bawah
                                (this.state.editMode==true) ? <TouchableOpacity onPress={this.state._change} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',left:EStyleSheet.value(`-18rem`),bottom:EStyleSheet.value(`-15rem`),borderRadius:100}}>
                                   <FontAwesome name="exchange" size={10} color="black" />
                                </TouchableOpacity>:null
                            }
                            {
                                //Kanan Bawah
                                (this.state.editMode==true) ? <TouchableOpacity onPress={this.state._hideline} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',right:EStyleSheet.value(`-15rem`),bottom:EStyleSheet.value(`-15rem`),borderRadius:100}}>
                                     <MaterialCommunityIcons style={{zIndex:1}} name="file-hidden" size={10} color="black" />
                                </TouchableOpacity>:null
                            }
                            {  
                                //Kiri Atas
                                (this.state.editMode==true) ? <TouchableOpacity onPress={this.state._duplicate} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',zIndex:100,top:EStyleSheet.value(`-15rem`),left:EStyleSheet.value(`-15rem`),borderRadius:100}}>
                                     <MaterialCommunityIcons name="content-copy" size={10} color="black" />
                                </TouchableOpacity>:null
                            }
                            {
                                //Kanan Atas
                                (this.state.editMode==true) ? <TouchableOpacity onPress={this.state._delete} style={{justifyContent:'center',alignItems:'center',shadowColor: "#000",shadowOffset: {width: 0,height: 1,},shadowOpacity: 0.22,shadowRadius: 2.22,elevation: 3,backgroundColor:'white',height:EStyleSheet.value(`15rem`),width:EStyleSheet.value(`15rem`),position:'absolute',zIndex:100,right:EStyleSheet.value(`-15rem`),top:EStyleSheet.value(`-15rem`),borderRadius:100}}>
                                     <Entypo name="cross" size={10} color="black" />
                                </TouchableOpacity>:null
                            }
                            
                        </View>
                    </Gestures>
           </View>
        )
    }
}