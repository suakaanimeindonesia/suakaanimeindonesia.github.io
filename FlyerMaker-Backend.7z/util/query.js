const getConnection = require('./database')

async function query(statement){
    try {
        let connection = await getConnection();
        return new Promise((resolve,reject)=>{
            connection.query(statement,(err,response)=>{
                if(err) reject(err);
                connection.release();
                resolve(response);
            });
        })
    } catch (error) {
        console.log(error);
    }
}

module.exports={
    query
}