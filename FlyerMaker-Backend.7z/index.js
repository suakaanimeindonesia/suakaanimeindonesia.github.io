const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const {query} = require('./util/query');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.get('/meme',async (req,res)=>{
    console.log(req.query)
    res.send("123");
})

app.get('/sticker', async (req,res)=>{
    try {
        let currentPage = req.query.page || 1
        let category = req.query.category || null;

        let limit = 10;
        let offset = 0 + ((currentPage-1 || 0) * limit);

        console.log(offset);
        
        if(category !== null){
            hasil = await query(`SELECT * FROM sticker WHERE sticker.category LIKE '%${category}%' LIMIT ${limit} OFFSET ${offset}`);
            hasNextPage = await query(`SELECT * FROM sticker WHERE sticker.category LIKE '%${category}%' LIMIT ${limit} OFFSET ${offset+limit}`)
        }else{
            hasil = await query(`SELECT * FROM sticker LIMIT ${limit} OFFSET ${offset}`);
            hasNextPage = await query(`SELECT * FROM sticker LIMIT ${limit} OFFSET ${offset+limit}`)
        }
        
        res.json({
            success:true,
            data:{
                item:[...hasil],
                hasNextPage: (hasNextPage.length) === 0 ? false:true,
                currentPage: currentPage
            }
        });
    } catch (error) {
        res.json({
            success:false,
            message:error.message
        })
    }
})


const server = app.listen(process.env.PORT || 3000,()=>{
    console.log(`Listen on port ${process.env.NODE || 3000}`)
})