#include <stdio.h>
#include <iostream>
#include <conio.h>
#define MAX 5
using namespace std;

struct queue{
    int data[MAX];
    int awal,akhir;
};

struct queue antrean;

void init(){
    antrean.awal=-1;
    antrean.akhir=-1;
}

bool full(){
    if(antrean.akhir==MAX){
        return true;
    }
    else{
        return false;
    }
}

bool empty(){
    if(antrean.akhir==-1){
        return true;
    }
    else{
        return false;
    }
}

void tampilData(){
    int i;
    if(!empty()){
        for(i=antrean.awal;i<antrean.akhir;i++){
            cout<<antrean.data[i]<<" | ";
        }
    }
    cout<<"\n";
}

void inQueue(){
    tampilData();
    int elemen;

    if(!full()){
        cout<<"Data yang akan dimasukkan :";
        cin>>elemen;
        cout<<endl;
        cout<<"Data berhasil ditambahkan\n";
        antrean.data[antrean.akhir]=elemen;
        antrean.akhir++;
    }
    else{
        cout<<"Queue penuh\n";
    }
    getchar();
}

void deQueue(){
    int i;
    tampilData();
    if(!empty()){
        cout<<"\nMengambil data \" "<<antrean.data[antrean.awal]<<" \" ..."<<endl;
        for(i=antrean.awal;i<antrean.akhir;i++){
            antrean.data[i]=antrean.data[i+1];
        }
        antrean.akhir--;
    }
    else{
        cout<<"Antrean kosong";
    }
    getchar();

}

void clear(){
    antrean.awal=-1;
    antrean.akhir=-1;
}


//// FUNGSI TAMBAHAN /////
void mencariElemen(){
    if(!empty()){
        int inputKueri;
        cout<<"\nMasukkan angka yang ingin dicari :";cin>>inputKueri;
        for(int i=antrean.awal;i<antrean.akhir;i++){
            if(antrean.data[i]==inputKueri){
                cout<<"\nAngka "<<antrean.data[i]<<" berada dalam antrian nomor "<<i+2;
                cout<<endl;
            }
        }
    }   
    else{
        cout<<"Antrean kosong";
    }
   
}

void mencariNilaiTotal(){
    if(!empty()){
        int total=0;
         for(int i=antrean.awal;i<antrean.akhir;i++){
             total+=antrean.data[i];
        }
        cout<<"\nNilai total semua data dalam antrean adalah : "<<total;
        cout<<endl;
    }
    else{
        cout<<"Antrean kosong";
    }

}


void mencariNilaiRataRata(){
    if(!empty()){
        float ratarata;
        float total=0;
        float a;
        for(int i=antrean.awal;i<antrean.akhir;i++){
             total+=antrean.data[i];
        }
        a=antrean.akhir+1;
        ratarata=total/a;
        cout<<"\nNilai rata-rata semua data dalam antrean adalah : "<<ratarata;
        cout<<endl;
    }
    else{
        cout<<"Antrean kosong";
    }
}

void mencariNilaiTerbesar(){
    if(!empty()){
        int max=0;
        for(int i=antrean.awal;i<antrean.akhir;i++){
             if(antrean.data[i]>max){
                 max=antrean.data[i];
             }
        }
        cout<<"\nNilai terbesar dalam antrean adalah : "<<max;
        cout<<endl;
    }
    else{
        cout<<"Antrean kosong";
    }

}

void mencariNilaiTerkecil(){
     if(!empty()){
        int min=antrean.data[0];
        for(int i=antrean.awal;i<antrean.akhir;i++){
             if(antrean.data[i]<min){
                 min=antrean.data[i];
             }
        }
        cout<<"\nNilai terkecil dalam antrean adalah : "<<min;
        cout<<endl;
    }
    else{
        cout<<"Antrean kosong";
    }
}

int main(){
    int pilihan,elemen;
    init();
    do{
            tampilData();
            cout<<"\nMenu Utama\n";
            cout<<"=========================\n";
            cout<<"[1] Init \n[2] InQueue \n[3] DeQueue \n[4] Clear \n[5] Mencari Elemen \n[6] Mencari Nilai Total\n[7] Mencari Nilai Rata-Rata\n[8] Mencari Nilai Terbesar\n[9] Mencari Nilai Terkecil \n[0] Keluar \n";
            cout<<"=========================\n";
            cout<<"\nMasukkan pilihan : ";cin>>pilihan;
            switch(pilihan){
                case 1: init(); break;
                case 2: inQueue(); break;
                case 3: deQueue(); break;
                case 4: clear(); break;
                case 5: mencariElemen(); break;
                case 6: mencariNilaiTotal(); break;
                case 7: mencariNilaiRataRata(); break;
                case 8: mencariNilaiTerbesar(); break;
                case 9: mencariNilaiTerkecil(); break;
            }
    }
    while(pilihan!=0);
    return 0;
}