﻿Module ModObjekdanFungsi
    Public KontrolKaryawan As New ClsCtlKaryawan
    Public KontrolCustomer As New ClsCtlCustomer
    Public KontrolKamar As New ClsCtlKamar
    Public KontrolService As New ClsCtlService
    Public KontrolTransaksiKamar As New ClsCtlTransaksiKamar
    Public KontrolTransaksiService As New ClsCtlTransaksiService
    Public EntitasKaryawan As New ClsEntKaryawan
    Public EntitasCustomer As New ClsEntCustomer
    Public EntitasKamar As New ClsEntKamar
    Public EntitasService As New ClsEntService
    Public EntitasTransaksiKamar As New ClsEntTransaksiKamar
    Public EntitasTransaksiService As New ClsEntTransaksiService
End Module
