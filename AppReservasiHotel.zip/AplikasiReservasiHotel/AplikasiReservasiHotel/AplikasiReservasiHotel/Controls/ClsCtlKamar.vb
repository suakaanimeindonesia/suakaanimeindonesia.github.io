﻿Imports System.Data.OleDb
Imports AplikasiReservasiHotel

Public Class ClsCtlKamar : Implements InfProses

    Function kodeBaru()
        Dim baru As String
        Dim kodeAkhir As Integer
        Try
            DTA = New OleDbDataAdapter("Select max(right(no_kamar,4)) from KAMAR", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "max_kode")
            kodeAkhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            baru = "K" & Strings.Right("000" & kodeAkhir + 1, 4)
            Return baru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function
    Public Function cariData(kunci As String) As DataView Implements InfProses.cariData
        Try
            DTA = New OleDbDataAdapter("Select * from KAMAR where tipe_kamar" & " like '%" & kunci & "%'", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Cari_Kamar")
            Dim grid As New DataView(DTS.Tables("Cari_Kamar"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function deleteData(kunci As String) As OleDbCommand Implements InfProses.deleteData
        CMD = New OleDbCommand("delete from KAMAR" & " where no_kamar = '" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntKamar
        data = Ob
        CMD = New OleDbCommand("insert into KAMAR values('" & data.kodeKamar & "','" & data.tipeKamar & "',
                               " & data.tarifKamar & ")", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function tampilData() As DataView Implements InfProses.tampilData
        Try
            DTA = New OleDbDataAdapter("Select * from KAMAR", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_Kamar")
            Dim grid As New DataView(DTS.Tables("Tabel_Kamar"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function updateData(OB As Object) As OleDbCommand Implements InfProses.updateData
        Dim data As New ClsEntKamar
        data = OB
        CMD = New OleDbCommand("update KAMAR set tipe_kamar='" & data.tipeKamar & "',tarif=" & data.tarifKamar &
                               "where no_kamar='" & data.kodeKamar & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function
    Function cekKamarDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("select count(no_kamar) from transaksi_reservasi" & " where no_kamar='" & kunci & "'", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 0 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return cek
    End Function

    Public Function InsertDataTransaksiKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataTransaksiService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiService
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemService
        Throw New NotImplementedException()
    End Function
End Class
