﻿Imports System.Data.OleDb
Imports AplikasiReservasiHotel

Public Class ClsCtlCustomer : Implements InfProses

    Function kodeBaru()
        Dim baru As String
        Dim kodeAkhir As Integer
        Try
            DTA = New OleDbDataAdapter("Select max(right(id_customer,4)) from CUSTOMER", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "max_kode")
            kodeAkhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            baru = "C" & Strings.Right("000" & kodeAkhir + 1, 4)
            Return baru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function
    Public Function cariData(kunci As String) As DataView Implements InfProses.cariData
        Try
            DTA = New OleDbDataAdapter("Select * from CUSTOMER where nama" & " like '%" & kunci & "%'", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Cari_Customer")
            Dim grid As New DataView(DTS.Tables("Cari_Customer"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function deleteData(kunci As String) As OleDbCommand Implements InfProses.deleteData
        CMD = New OleDbCommand("delete from CUSTOMER" & " where id_customer = '" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntCustomer
        data = Ob
        CMD = New OleDbCommand("insert into CUSTOMER values('" & data.idCustomer & "','" & data.namaCustomer & "','" & data.jenkelCustomer & "','" & data.alamatCustomer & "','" & data.notelpCustomer & "')", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function tampilData() As DataView Implements InfProses.tampilData
        Try
            DTA = New OleDbDataAdapter("Select * from CUSTOMER", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_Customer")
            Dim grid As New DataView(DTS.Tables("Tabel_Customer"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function updateData(OB As Object) As OleDbCommand Implements InfProses.updateData
        Dim data As New ClsEntCustomer
        data = OB
        CMD = New OleDbCommand("update CUSTOMER set nama='" & data.namaCustomer & "',jenkel='" & data.jenkelCustomer & "',alamat='" & data.alamatCustomer & "',no_telp='" & data.notelpCustomer & "' where id_customer='" & data.idCustomer & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function
    Function cekCustomerDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("select count(id_customer) from transaksi_reservasi" & " where id_customer='" & kunci & "'", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 0 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return cek
    End Function

    Public Function InsertDataTransaksiKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataTransaksiService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiService
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemService
        Throw New NotImplementedException()
    End Function
End Class
