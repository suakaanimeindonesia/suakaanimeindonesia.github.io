﻿Imports System.Data.OleDb
Imports AplikasiReservasiHotel

Public Class ClsCtlTransaksiKamar : Implements InfProses
    Function kodeBaru()
        Dim baru As String
        Dim kodeAkhir As Integer
        Try
            DTA = New OleDbDataAdapter("Select max(right(id_transaksi,4)) from transaksi_reservasi", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "max_kode")
            kodeAkhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            baru = "T" & Strings.Right("000" & kodeAkhir + 1, 4)
            Return baru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function
    Public Function cariData(kunci As String) As DataView Implements InfProses.cariData
        Throw New NotImplementedException()
    End Function

    Public Function deleteData(kunci As String) As OleDbCommand Implements InfProses.deleteData
        Throw New NotImplementedException()
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemKamar
        'Dim data As New ClsEntTransaksiKamar
        'data = Ob
        'CMD = New OleDbCommand("", BUKAKONEKSI)
        'CMD.CommandType = CommandType.Text
        'CMD.ExecuteNonQuery()
        'CMD = New OleDbCommand("", TUTUPKONEKSI)
        'Return CMD
    End Function

    Public Function InsertDataItemService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemService
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataTransaksiKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiKamar
        Dim data As New ClsEntTransaksiKamar
        data = Ob
        CMD = New OleDbCommand(String.Format("INSERT INTO transaksi_reservasi VALUES ('{0}','{1}',{2},'{3}','{4}');", data._idtransaksi, data._idcustomer, data._totalbayar, data._tanggaltransaksi, data._idkaryawan), BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertDataTransaksiService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiService
        Throw New NotImplementedException()
    End Function

    Public Function tampilData() As DataView Implements InfProses.tampilData
        Throw New NotImplementedException()
    End Function

    Public Function updateData(OB As Object) As OleDbCommand Implements InfProses.updateData
        Throw New NotImplementedException()
    End Function
End Class
