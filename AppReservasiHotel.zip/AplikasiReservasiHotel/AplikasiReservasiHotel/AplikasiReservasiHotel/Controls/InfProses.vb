﻿Imports System.Data.OleDb
Public Interface InfProses
    Function InsertData(Ob As Object) As OleDbCommand
    Function InsertDataTransaksiKamar(Ob As Object) As OleDbCommand
    Function InsertDataTransaksiService(Ob As Object) As OleDbCommand
    Function InsertDataItemKamar(Ob As Object) As OleDbCommand
    Function InsertDataItemService(Ob As Object) As OleDbCommand
    Function updateData(OB As Object) As OleDbCommand
    Function deleteData(kunci As String) As OleDbCommand
    Function tampilData() As DataView
    Function cariData(kunci As String) As DataView
End Interface
