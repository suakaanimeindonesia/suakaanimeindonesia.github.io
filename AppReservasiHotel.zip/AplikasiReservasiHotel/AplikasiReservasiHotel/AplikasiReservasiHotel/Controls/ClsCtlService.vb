﻿Imports System.Data.OleDb
Imports AplikasiReservasiHotel

Public Class ClsCtlService : Implements InfProses

    Function kodeBaru()
        Dim baru As String
        Dim kodeAkhir As Integer
        Try
            DTA = New OleDbDataAdapter("Select max(right(id_service,4))from ROOM_SERVICE", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "max_kode")
            kodeAkhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            baru = "S" & Strings.Right("000" & kodeAkhir + 1, 4)
            Return baru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function


    Public Function cariData(kunci As String) As DataView Implements InfProses.cariData
        Try
            DTA = New OleDbDataAdapter("Select * from ROOM_SERVICE where nama_service" & " like '%" & kunci & "%'", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Cari_Service")
            Dim grid As New DataView(DTS.Tables("Cari_Service"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function deleteData(kunci As String) As OleDbCommand Implements InfProses.deleteData
        CMD = New OleDbCommand("delete from ROOM_SERVICE" & " where id_service = '" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntService
        data = Ob
        CMD = New OleDbCommand(String.Format("INSERT INTO room_service VALUES ('{0}','{1}',{2},{3});", data.kodeService, data.namaService, data.hargaService, data.jumlahService), BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function tampilData() As DataView Implements InfProses.tampilData
        Try
            DTA = New OleDbDataAdapter("Select * from ROOM_SERVICE", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_Service")
            Dim grid As New DataView(DTS.Tables("Tabel_Service"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function updateData(OB As Object) As OleDbCommand Implements InfProses.updateData
        Dim data As New ClsEntService
        data = OB
        CMD = New OleDbCommand("update ROOM_SERVICE set nama_service='" & data.namaService & "',harga=" & data.hargaService & "where id_service='" & data.kodeService & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Function cekServiceDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("select count(id_service) from transaksi_reservasi" & " where id_service='" & kunci & "'", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 0 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return cek
    End Function

    Public Function InsertDataTransaksiKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataTransaksiService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiService
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemService
        Throw New NotImplementedException()
    End Function
End Class
