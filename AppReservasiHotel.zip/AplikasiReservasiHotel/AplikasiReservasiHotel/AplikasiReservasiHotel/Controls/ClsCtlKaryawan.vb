﻿Imports System.Data.OleDb
Imports AplikasiReservasiHotel

Public Class ClsCtlKaryawan : Implements InfProses

    Function kodeBaru()
        Dim baru As String
        Dim kodeAkhir As Integer
        Try
            DTA = New OleDbDataAdapter("Select max(right(id_karyawan,4)) from KARYAWAN", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "max_kode")
            kodeAkhir = Val(DTS.Tables("max_kode").Rows(0).Item(0))
            baru = "P" & Strings.Right("000" & kodeAkhir + 1, 4)
            Return baru
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function
    Public Function cariData(kunci As String) As DataView Implements InfProses.cariData
        Try
            DTA = New OleDbDataAdapter("Select * from KARYAWAN where nama" & " like '%" & kunci & "%'", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Cari_Karyawan")
            Dim grid As New DataView(DTS.Tables("Cari_Karyawan"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function deleteData(kunci As String) As OleDbCommand Implements InfProses.deleteData
        CMD = New OleDbCommand("delete from KARYAWAN" & " where id_karyawan = '" & kunci & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function InsertData(Ob As Object) As OleDbCommand Implements InfProses.InsertData
        Dim data As New ClsEntKaryawan
        data = Ob
        CMD = New OleDbCommand("insert into KARYAWAN values('" & data.idKaryawan & "','" & data.namaKaryawan & "','" & data.jenkelKaryawan & "','" & data.alamatKaryawan & "','" & data.notelpKaryawan & "')", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function

    Public Function tampilData() As DataView Implements InfProses.tampilData
        Try
            TUTUPKONEKSI()
            DTA = New OleDbDataAdapter("Select * from KARYAWAN", BUKAKONEKSI)
            DTS = New DataSet()
            DTA.Fill(DTS, "Tabel_Karyawan")
            Dim grid As New DataView(DTS.Tables("Tabel_Karyawan"))
            Return grid
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function updateData(OB As Object) As OleDbCommand Implements InfProses.updateData
        Dim data As New ClsEntKaryawan
        data = OB
        CMD = New OleDbCommand("update KARYAWAN set nama='" & data.namaKaryawan & "',jenkel='" & data.jenkelKaryawan & "',alamat='" & data.alamatKaryawan & "',no_telp='" & data.notelpKaryawan & "' where id_karyawan='" & data.idKaryawan & "'", BUKAKONEKSI)
        CMD.CommandType = CommandType.Text
        CMD.ExecuteNonQuery()
        CMD = New OleDbCommand("", TUTUPKONEKSI)
        Return CMD
    End Function
    Function cekKaryawanDireferensi(kunci As String) As Boolean
        Dim cek As Boolean
        cek = False
        Try
            DTA = New OleDbDataAdapter("select count(id_karyawan) from transaksi_reservasi" & " where id_karyawan='" & kunci & "'", BUKAKONEKSI)
            DTS = New DataSet
            DTA.Fill(DTS, "cek")
            If DTS.Tables("cek").Rows(0)(0).ToString > 0 Then cek = True
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return cek
    End Function

    Public Function InsertDataTransaksiKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataTransaksiService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataTransaksiService
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemKamar(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemKamar
        Throw New NotImplementedException()
    End Function

    Public Function InsertDataItemService(Ob As Object) As OleDbCommand Implements InfProses.InsertDataItemService
        Throw New NotImplementedException()
    End Function
End Class
