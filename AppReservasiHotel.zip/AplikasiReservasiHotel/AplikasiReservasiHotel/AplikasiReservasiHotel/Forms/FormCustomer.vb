﻿Public Class FormCustomer
    Dim modeProses As Integer
    Dim baris As Integer

    Private Sub AturButton(st As Boolean)
        btnAdd.Enabled = st
        btnEdit.Enabled = st
        btnDelete.Enabled = st
        btnSave.Enabled = Not st
        btnCancel.Enabled = Not st
        GroupBox1.Enabled = Not st
        GroupBox2.Enabled = st
        GroupBox3.Enabled = st
    End Sub

    Private Sub IsiBox(br As Integer)
        If br < DTGRID.Rows.Count Then
            With dgCustomer.Rows(br)
                txtIdcustomer.Text = .Cells(0).Value.ToString
                txtNama.Text = .Cells(1).Value.ToString
                If rbLaki.Checked = True Then
                    rbLaki.Text = .Cells(2).Value.ToString
                ElseIf rbPerempuan.Checked = True Then
                    rbPerempuan.Text = .Cells(2).Value.ToString
                End If
                txtAlamat.Text = .Cells(3).Value.ToString
                txtNotelp.Text = .Cells(4).Value.ToString
            End With
            lblBaris.Text = "Data ke-" & br + 1 & " dari " & dgCustomer.RowCount - 1 & " data"
        End If
    End Sub

    Private Sub RefreshGrid()
        DTGRID = KontrolCustomer.tampilData.ToTable
        dgCustomer.DataSource = DTGRID
        If DTGRID.Rows.Count > 0 Then
            baris = DTGRID.Rows.Count - 1
            dgCustomer.Rows(DTGRID.Rows.Count - 1).Selected = True
            dgCustomer.CurrentCell = dgCustomer.Item(1, baris)
            AturButton(True)
            IsiBox(baris)
        End If
    End Sub

    Private Sub TampilCari(kunci As String)
        DTGRID = KontrolCustomer.cariData(kunci).ToTable
        If DTGRID.Rows.Count > 0 Then
            baris = DTGRID.Rows.Count - 1
            dgCustomer.DataSource = DTGRID
            dgCustomer.Rows(DTGRID.Rows.Count - 1).Selected = True
            dgCustomer.CurrentCell = dgCustomer.Item(1, baris)
            IsiBox(baris)
        Else
            MsgBox("Data tidak ditemukan")
            RefreshGrid()
        End If
    End Sub


    Private Sub FormCustomer_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call RefreshGrid()
        txtIdcustomer.Enabled = False
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        AturButton(False)
        modeProses = 1

        'kosongkan textbox 
        txtNama.Text = ""
        rbLaki.Checked = False
        rbPerempuan.Checked = False
        txtAlamat.Text = ""
        txtNotelp.Text = ""

        'isi textbox kode dengan memanggil fungsi kodebaru 
        txtIdcustomer.Text = KontrolCustomer.kodeBaru

        'posisikan cursor di textbox nama
        txtNama.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        FormMenuUtama.Show()
        Me.Hide()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        AturButton(False)
        txtNama.Focus()
        modeProses = 2
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        RefreshGrid()
        AturButton(True)
        modeProses = 0
    End Sub

    Private Sub dgCustomer_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgCustomer.CellClick
        If modeProses = 0 Then
            baris = e.RowIndex
            dgCustomer.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub

    Private Sub btnAwal_Click(sender As Object, e As EventArgs) Handles btnAwal.Click
        dgCustomer.ClearSelection()
        baris = 0
        dgCustomer.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnNaik_Click(sender As Object, e As EventArgs) Handles btnNaik.Click
        dgCustomer.ClearSelection()
        If baris > 0 Then baris = baris - 1
        dgCustomer.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnTurun_Click(sender As Object, e As EventArgs) Handles btnTurun.Click
        dgCustomer.ClearSelection()
        If baris < DTGRID.Rows.Count - 1 Then baris = baris + 1
        dgCustomer.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnAkhir_Click(sender As Object, e As EventArgs) Handles btnAkhir.Click
        dgCustomer.ClearSelection()
        baris = DTGRID.Rows.Count - 1
        dgCustomer.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click
        If txtCari.Text = "" Then
            Call RefreshGrid()
        Else
            Call TampilCari(txtCari.Text)
            txtCari.Focus()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        With EntitasCustomer
            .idCustomer = txtIdcustomer.Text
            .namaCustomer = txtNama.Text
            If rbLaki.Checked = True Then
                .jenkelCustomer = rbLaki.Text
            ElseIf rbPerempuan.Checked = True Then
                .jenkelCustomer = rbPerempuan.Text
            End If
            .alamatCustomer = txtAlamat.Text
            .notelpCustomer = txtNotelp.Text
        End With
        If modeProses = 1 Then
            KontrolCustomer.InsertData(EntitasCustomer)
        ElseIf modeProses = 2 Then
            KontrolCustomer.updateData(EntitasCustomer)
        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "info")
        RefreshGrid()
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolCustomer.cekCustomerDireferensi(txtIdcustomer.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "Peringatan")
            Exit Sub
        End If
        If MsgBox("Apakah anda yakin akan menghapus " & txtIdcustomer.Text & "-" & txtNama.Text & " ?", MsgBoxStyle.Question +
                  MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
            KontrolCustomer.deleteData(txtIdcustomer.Text)
        End If
        RefreshGrid()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class