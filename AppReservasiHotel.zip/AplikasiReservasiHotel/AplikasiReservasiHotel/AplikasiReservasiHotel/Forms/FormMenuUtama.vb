﻿Public Class FormMenuUtama
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim fmCustomer As New FormCustomer()
        fmCustomer.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        FormKaryawan.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        FormPilihKategori.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        FormPilihTransaksi.Show()
        Me.Hide()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub LaporanCustomerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LaporanCustomerToolStripMenuItem.Click
        Dim k As New FormLapCustomer
        k.Show()
    End Sub

    Private Sub LaporanKaryawanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LaporanKaryawanToolStripMenuItem.Click
        Dim k As New FormLapKaryawan
        k.Show()
    End Sub

    Private Sub LaporanTransaksiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LaporanTransaksiToolStripMenuItem.Click
        Dim k As New FormLapTransaksiKamar
        k.Show()
    End Sub

    Private Sub LaporanTRansaksiRoomServiceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LaporanTRansaksiRoomServiceToolStripMenuItem.Click
        Dim k As New FormLapTransaksiService
        k.Show()
    End Sub

    Private Sub FormMenuUtama_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class