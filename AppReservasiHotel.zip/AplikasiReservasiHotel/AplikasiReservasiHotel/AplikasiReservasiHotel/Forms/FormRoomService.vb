﻿Public Class FormRoomService
    Dim modeProses As Integer
    Dim baris As Integer

    Private Sub AturButton(st As Boolean)
        btnAdd.Enabled = st
        btnEdit.Enabled = st
        btnDelete.Enabled = st
        btnSave.Enabled = Not st
        btnCancel.Enabled = Not st
        GroupBox1.Enabled = Not st
        GroupBox2.Enabled = st
        GroupBox3.Enabled = st
    End Sub

    Private Sub IsiBox(br As Integer)
        If br < DTGRID.Rows.Count Then
            With dgService.Rows(br)
                txtIdservice.Text = .Cells(0).Value.ToString
                txtNama.Text = .Cells(1).Value.ToString
                txtHarga.Text = .Cells(2).Value.ToString
            End With
            lblBaris.Text = "Data ke-" & br + 1 & " dari " & dgService.RowCount - 1 & " data"
        End If
    End Sub

    Private Sub RefreshGrid()
        DTGRID = KontrolService.tampilData.ToTable
        dgService.DataSource = DTGRID
        If DTGRID.Rows.Count > 0 Then
            baris = DTGRID.Rows.Count - 1
            dgService.Rows(DTGRID.Rows.Count - 1).Selected = True
            dgService.CurrentCell = dgService.Item(1, baris)
            AturButton(True)
            IsiBox(baris)
        End If
    End Sub

    Private Sub TampilCari(kunci As String)
        DTGRID = KontrolService.cariData(kunci).ToTable
        If DTGRID.Rows.Count > 0 Then
            baris = DTGRID.Rows.Count - 1
            dgService.DataSource = DTGRID
            dgService.Rows(DTGRID.Rows.Count - 1).Selected = True
            dgService.CurrentCell = dgService.Item(1, baris)
            IsiBox(baris)
        Else
            MsgBox("Data tidak ditemukan")
            RefreshGrid()
        End If
    End Sub
    Private Sub FormRoomService_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call RefreshGrid()
        txtIdservice.Enabled = False
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        AturButton(False)
        modeProses = 1

        'kosongkan textbox 
        txtNama.Text = ""
        txtHarga.Text = ""


        'isi textbox kode dengan memanggil fungsi kodebaru 
        txtIdservice.Text = KontrolService.kodeBaru

        'posisikan cursor di textbox nama
        txtNama.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        FormPilihKategori.Show()
        Me.Hide()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        AturButton(False)
        txtNama.Focus()
        modeProses = 2
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        RefreshGrid()
        AturButton(True)
        modeProses = 0
    End Sub

    Private Sub dgService_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgService.CellClick
        If modeProses = 0 Then
            baris = e.RowIndex
            dgService.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub

    Private Sub btnAwal_Click(sender As Object, e As EventArgs) Handles btnAwal.Click
        dgService.ClearSelection()
        baris = 0
        dgService.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnNaik_Click(sender As Object, e As EventArgs) Handles btnNaik.Click
        dgService.ClearSelection()
        If baris > 0 Then baris = baris - 1
        dgService.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnTurun_Click(sender As Object, e As EventArgs) Handles btnTurun.Click
        dgService.ClearSelection()
        If baris < DTGRID.Rows.Count - 1 Then baris = baris + 1
        dgService.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnAkhir_Click(sender As Object, e As EventArgs) Handles btnAkhir.Click
        dgService.ClearSelection()
        baris = DTGRID.Rows.Count - 1
        dgService.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click
        If txtCari.Text = "" Then
            Call RefreshGrid()
        Else
            Call TampilCari(txtCari.Text)
            txtCari.Focus()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        With EntitasService
            .kodeService = txtIdservice.Text
            .namaService = txtNama.Text
            .hargaService = txtHarga.Text
            .jumlahService = txtJumlah.Text
        End With
        If modeProses = 1 Then
            KontrolService.InsertData(EntitasService)
        ElseIf modeProses = 2 Then
            KontrolService.updateData(EntitasService)
        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "info")
        RefreshGrid()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolService.cekServiceDireferensi(txtIdservice.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "Peringatan")
            Exit Sub
        End If
        If MsgBox("Apakah anda yakin akan menghapus " & txtIdservice.Text & "-" & txtNama.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
            KontrolService.deleteData(txtIdservice.Text)
        End If
        RefreshGrid()
    End Sub
End Class