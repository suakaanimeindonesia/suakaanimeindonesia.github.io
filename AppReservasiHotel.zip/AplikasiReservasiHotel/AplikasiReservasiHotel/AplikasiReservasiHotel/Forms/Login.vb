﻿Public Class Login

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtUsername.Focus()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text & txtPassword.Text = "" Then
            MsgBox("Sillahkan Di Isi!")

        End If
        If txtUsername.Text & txtPassword.Text = "admin" & "admin" Then
            FormMenuUtama.Show()
            Me.Hide()

            Visible = False
            txtUsername.Clear()
            txtPassword.Clear()
        Else
            MsgBox("Login Gagal")

        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtUsername.Text = ""
        txtPassword.Text = ""
        txtUsername.Focus()
    End Sub
End Class