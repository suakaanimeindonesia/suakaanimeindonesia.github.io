﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormTransaksiService
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtKembali = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtBayar = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.btnProses = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtAlamat = New System.Windows.Forms.TextBox()
        Me.txtNotelp = New System.Windows.Forms.TextBox()
        Me.txtJenkel = New System.Windows.Forms.TextBox()
        Me.txtNama = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtTanggal = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtIdtransaksi = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.LVTransaksiService = New System.Windows.Forms.ListView()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtJumlah = New System.Windows.Forms.TextBox()
        Me.txtHarga = New System.Windows.Forms.TextBox()
        Me.txtNamaService = New System.Windows.Forms.TextBox()
        Me.txtIdservice = New System.Windows.Forms.TextBox()
        Me.btnCariService = New System.Windows.Forms.Button()
        Me.txtIdcustomer = New System.Windows.Forms.TextBox()
        Me.txtIdkaryawan = New System.Windows.Forms.TextBox()
        Me.btnCariCustomer = New System.Windows.Forms.Button()
        Me.btnCariKaryawan = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(197, 9)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(353, 24)
        Me.Label29.TabIndex = 14
        Me.Label29.Text = "FORM TRANSAKSI ROOM SERVICE"
        '
        'txtKembali
        '
        Me.txtKembali.Location = New System.Drawing.Point(617, 567)
        Me.txtKembali.Name = "txtKembali"
        Me.txtKembali.Size = New System.Drawing.Size(125, 20)
        Me.txtKembali.TabIndex = 30
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(555, 570)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(44, 13)
        Me.Label28.TabIndex = 29
        Me.Label28.Text = "Kembali"
        '
        'txtBayar
        '
        Me.txtBayar.Location = New System.Drawing.Point(617, 532)
        Me.txtBayar.Name = "txtBayar"
        Me.txtBayar.Size = New System.Drawing.Size(125, 20)
        Me.txtBayar.TabIndex = 28
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(565, 535)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(34, 13)
        Me.Label27.TabIndex = 27
        Me.Label27.Text = "Bayar"
        '
        'txtTotal
        '
        Me.txtTotal.Location = New System.Drawing.Point(616, 493)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(126, 20)
        Me.txtTotal.TabIndex = 26
        '
        'btnProses
        '
        Me.btnProses.Location = New System.Drawing.Point(524, 491)
        Me.btnProses.Name = "btnProses"
        Me.btnProses.Size = New System.Drawing.Size(75, 23)
        Me.btnProses.TabIndex = 25
        Me.btnProses.Text = "Hitung Total"
        Me.btnProses.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnCariKaryawan)
        Me.GroupBox1.Controls.Add(Me.txtIdkaryawan)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtAlamat)
        Me.GroupBox1.Controls.Add(Me.btnCariCustomer)
        Me.GroupBox1.Controls.Add(Me.txtNotelp)
        Me.GroupBox1.Controls.Add(Me.txtJenkel)
        Me.GroupBox1.Controls.Add(Me.txtNama)
        Me.GroupBox1.Controls.Add(Me.txtIdcustomer)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(17, 82)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(379, 225)
        Me.GroupBox1.TabIndex = 24
        Me.GroupBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(71, 13)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "ID Karyawan "
        '
        'txtAlamat
        '
        Me.txtAlamat.Location = New System.Drawing.Point(107, 160)
        Me.txtAlamat.Name = "txtAlamat"
        Me.txtAlamat.Size = New System.Drawing.Size(100, 20)
        Me.txtAlamat.TabIndex = 11
        '
        'txtNotelp
        '
        Me.txtNotelp.Location = New System.Drawing.Point(107, 193)
        Me.txtNotelp.Name = "txtNotelp"
        Me.txtNotelp.Size = New System.Drawing.Size(100, 20)
        Me.txtNotelp.TabIndex = 8
        '
        'txtJenkel
        '
        Me.txtJenkel.Location = New System.Drawing.Point(107, 120)
        Me.txtJenkel.Name = "txtJenkel"
        Me.txtJenkel.Size = New System.Drawing.Size(100, 20)
        Me.txtJenkel.TabIndex = 7
        '
        'txtNama
        '
        Me.txtNama.Location = New System.Drawing.Point(107, 82)
        Me.txtNama.Name = "txtNama"
        Me.txtNama.Size = New System.Drawing.Size(100, 20)
        Me.txtNama.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "ID Customer"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(20, 193)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "No. Telp"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(20, 163)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Alamat"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 127)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Jenis Kelamin "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(20, 85)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Nama"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(107, 605)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 32
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(13, 605)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 33
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(662, 605)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 31
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtTanggal
        '
        Me.txtTanggal.Location = New System.Drawing.Point(594, 60)
        Me.txtTanggal.Name = "txtTanggal"
        Me.txtTanggal.Size = New System.Drawing.Size(149, 20)
        Me.txtTanggal.TabIndex = 37
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(477, 63)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(95, 13)
        Me.Label25.TabIndex = 36
        Me.Label25.Text = "Tanggal Transaksi"
        '
        'txtIdtransaksi
        '
        Me.txtIdtransaksi.Location = New System.Drawing.Point(124, 60)
        Me.txtIdtransaksi.Name = "txtIdtransaksi"
        Me.txtIdtransaksi.Size = New System.Drawing.Size(100, 20)
        Me.txtIdtransaksi.TabIndex = 35
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label30.Location = New System.Drawing.Point(41, 63)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(67, 13)
        Me.Label30.TabIndex = 34
        Me.Label30.Text = "ID Transaksi"
        '
        'LVTransaksiService
        '
        Me.LVTransaksiService.HideSelection = False
        Me.LVTransaksiService.Location = New System.Drawing.Point(17, 314)
        Me.LVTransaksiService.Name = "LVTransaksiService"
        Me.LVTransaksiService.Size = New System.Drawing.Size(726, 154)
        Me.LVTransaksiService.TabIndex = 41
        Me.LVTransaksiService.UseCompatibleStateImageBehavior = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(20, 52)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(74, 13)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Nama Service"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(20, 89)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(36, 13)
        Me.Label22.TabIndex = 1
        Me.Label22.Text = "Harga"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(20, 127)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(43, 13)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Jumlah "
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnCariService)
        Me.GroupBox3.Controls.Add(Me.txtJumlah)
        Me.GroupBox3.Controls.Add(Me.txtHarga)
        Me.GroupBox3.Controls.Add(Me.txtNamaService)
        Me.GroupBox3.Controls.Add(Me.txtIdservice)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Location = New System.Drawing.Point(414, 82)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(329, 225)
        Me.GroupBox3.TabIndex = 13
        Me.GroupBox3.TabStop = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(20, 17)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(57, 13)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "ID Service"
        '
        'txtJumlah
        '
        Me.txtJumlah.Location = New System.Drawing.Point(111, 120)
        Me.txtJumlah.Name = "txtJumlah"
        Me.txtJumlah.Size = New System.Drawing.Size(174, 20)
        Me.txtJumlah.TabIndex = 2
        '
        'txtHarga
        '
        Me.txtHarga.Location = New System.Drawing.Point(111, 86)
        Me.txtHarga.Name = "txtHarga"
        Me.txtHarga.Size = New System.Drawing.Size(174, 20)
        Me.txtHarga.TabIndex = 2
        '
        'txtNamaService
        '
        Me.txtNamaService.Location = New System.Drawing.Point(111, 49)
        Me.txtNamaService.Name = "txtNamaService"
        Me.txtNamaService.Size = New System.Drawing.Size(174, 20)
        Me.txtNamaService.TabIndex = 2
        '
        'txtIdservice
        '
        Me.txtIdservice.Location = New System.Drawing.Point(111, 13)
        Me.txtIdservice.Name = "txtIdservice"
        Me.txtIdservice.Size = New System.Drawing.Size(91, 20)
        Me.txtIdservice.TabIndex = 2
        '
        'btnCariService
        '
        Me.btnCariService.Location = New System.Drawing.Point(229, 11)
        Me.btnCariService.Name = "btnCariService"
        Me.btnCariService.Size = New System.Drawing.Size(75, 23)
        Me.btnCariService.TabIndex = 10
        Me.btnCariService.Text = "Search"
        Me.btnCariService.UseVisualStyleBackColor = True
        '
        'txtIdcustomer
        '
        Me.txtIdcustomer.Location = New System.Drawing.Point(107, 49)
        Me.txtIdcustomer.Name = "txtIdcustomer"
        Me.txtIdcustomer.Size = New System.Drawing.Size(100, 20)
        Me.txtIdcustomer.TabIndex = 5
        '
        'txtIdkaryawan
        '
        Me.txtIdkaryawan.Location = New System.Drawing.Point(107, 14)
        Me.txtIdkaryawan.Name = "txtIdkaryawan"
        Me.txtIdkaryawan.Size = New System.Drawing.Size(100, 20)
        Me.txtIdkaryawan.TabIndex = 32
        '
        'btnCariCustomer
        '
        Me.btnCariCustomer.Location = New System.Drawing.Point(231, 46)
        Me.btnCariCustomer.Name = "btnCariCustomer"
        Me.btnCariCustomer.Size = New System.Drawing.Size(75, 23)
        Me.btnCariCustomer.TabIndex = 10
        Me.btnCariCustomer.Text = "Search"
        Me.btnCariCustomer.UseVisualStyleBackColor = True
        '
        'btnCariKaryawan
        '
        Me.btnCariKaryawan.Location = New System.Drawing.Point(231, 14)
        Me.btnCariKaryawan.Name = "btnCariKaryawan"
        Me.btnCariKaryawan.Size = New System.Drawing.Size(75, 23)
        Me.btnCariKaryawan.TabIndex = 33
        Me.btnCariKaryawan.Text = "Search"
        Me.btnCariKaryawan.UseVisualStyleBackColor = True
        '
        'FormTransaksiService
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(759, 641)
        Me.Controls.Add(Me.LVTransaksiService)
        Me.Controls.Add(Me.txtTanggal)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.txtIdtransaksi)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.txtKembali)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.txtBayar)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.btnProses)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "FormTransaksiService"
        Me.Text = "FormTransaksiService"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label29 As Label
    Friend WithEvents txtKembali As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents txtBayar As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents btnProses As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtNotelp As TextBox
    Friend WithEvents txtJenkel As TextBox
    Friend WithEvents txtNama As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSave As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtTanggal As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents txtIdtransaksi As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txtAlamat As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents LVTransaksiService As ListView
    Friend WithEvents btnCariKaryawan As Button
    Friend WithEvents txtIdkaryawan As TextBox
    Friend WithEvents btnCariCustomer As Button
    Friend WithEvents txtIdcustomer As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnCariService As Button
    Friend WithEvents txtJumlah As TextBox
    Friend WithEvents txtHarga As TextBox
    Friend WithEvents txtNamaService As TextBox
    Friend WithEvents txtIdservice As TextBox
    Friend WithEvents Label24 As Label
End Class
