﻿Public Class FormLapKaryawan

End Class