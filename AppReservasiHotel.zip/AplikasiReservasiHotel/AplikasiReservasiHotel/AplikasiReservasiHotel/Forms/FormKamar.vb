﻿Public Class FormKamar
    Dim modeProses As Integer
    Dim baris As Integer
    Private Sub AturButton(st As Boolean)
        btnAdd.Enabled = st
        btnEdit.Enabled = st
        btnDelete.Enabled = st
        btnSave.Enabled = Not st
        btnCancel.Enabled = Not st
        GroupBox1.Enabled = Not st
        GroupBox2.Enabled = st
        GroupBox3.Enabled = st
    End Sub

    Private Sub IsiBox(br As Integer)
        If br < DTGRID.Rows.Count Then
            With dgKamar.Rows(br)
                txtIdKamar.Text = .Cells(0).Value.ToString
                txtTipe.Text = .Cells(1).Value.ToString
                txtTarif.Text = .Cells(2).Value.ToString
            End With
            lblBaris.Text = "Data ke-" & br + 1 & " dari " & dgKamar.RowCount - 1 & " data"
        End If
    End Sub

    Private Sub RefreshGrid()
        DTGRID = KontrolKamar.tampilData.ToTable
        dgKamar.DataSource = DTGRID
        If DTGRID.Rows.Count > 0 Then
            baris = DTGRID.Rows.Count - 1
            dgKamar.Rows(DTGRID.Rows.Count - 1).Selected = True
            dgKamar.CurrentCell = dgKamar.Item(1, baris)
            AturButton(True)
            IsiBox(baris)
        End If
    End Sub

    Private Sub TampilCari(kunci As String)
        DTGRID = KontrolKamar.cariData(kunci).ToTable
        If DTGRID.Rows.Count > 0 Then
            baris = DTGRID.Rows.Count - 1
            dgKamar.DataSource = DTGRID
            dgKamar.Rows(DTGRID.Rows.Count - 1).Selected = True
            dgKamar.CurrentCell = dgKamar.Item(1, baris)
            IsiBox(baris)
        Else
            MsgBox("Data tidak ditemukan")
            RefreshGrid()
        End If
    End Sub

    Private Sub FormKamar_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call RefreshGrid()
        txtIdKamar.Enabled = False
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        AturButton(False)
        modeProses = 1

        'kosongkan textbox 
        txtTipe.Text = ""
        txtTarif.Text = ""

        'isi textbox kode dengan memanggil fungsi kodebaru 
        txtIdKamar.Text = KontrolKamar.kodeBaru

        'posisikan cursor di textbox tipe
        txtTipe.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        FormPilihKategori.Show()
        Me.Hide()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        AturButton(False)
        txtTipe.Focus()
        modeProses = 2
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        RefreshGrid()
        AturButton(True)
        modeProses = 0
    End Sub

    Private Sub dgKamar_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgKamar.CellClick
        If modeProses = 0 Then
            baris = e.RowIndex
            dgKamar.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub

    Private Sub btnAwal_Click(sender As Object, e As EventArgs) Handles btnAwal.Click
        dgKamar.ClearSelection()
        baris = 0
        dgKamar.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnNaik_Click(sender As Object, e As EventArgs) Handles btnNaik.Click
        dgKamar.ClearSelection()
        If baris > 0 Then baris = baris - 1
        dgKamar.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnTurun_Click(sender As Object, e As EventArgs) Handles btnTurun.Click
        dgKamar.ClearSelection()
        If baris < DTGRID.Rows.Count - 1 Then baris = baris + 1
        dgKamar.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnAkhir_Click(sender As Object, e As EventArgs) Handles btnAkhir.Click
        dgKamar.ClearSelection()
        baris = DTGRID.Rows.Count - 1
        dgKamar.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click
        If txtCari.Text = "" Then
            Call RefreshGrid()
        Else
            Call TampilCari(txtCari.Text)
            txtCari.Focus()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        With EntitasKamar
            .kodeKamar = txtIdKamar.Text
            .tipeKamar = txtTipe.Text
            .tarifKamar = txtTarif.Text
        End With
        If modeProses = 1 Then
            KontrolKamar.InsertData(EntitasKamar)
        ElseIf modeProses = 2 Then
            KontrolKamar.updateData(EntitasKamar)
        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "info")
        RefreshGrid()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolKamar.cekKamarDireferensi(txtIdKamar.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "Peringatan")
            Exit Sub
        End If
        If MsgBox("Apakah anda yakin akan menghapus " & txtIdKamar.Text & "-" & txtTipe.Text & " ?", MsgBoxStyle.Question +
                  MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
            KontrolKamar.deleteData(txtIdKamar.Text)
        End If
        RefreshGrid()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class