﻿Imports System.Data.OleDb

Public Class FormTransaksiKamar
    Dim modeProses As Integer
    Dim baris As Integer
    Dim total, kembali As Integer

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        Dim id = ComboBox2.Text
        Dim cmd As New OleDbCommand(String.Format("SELECT * FROM customer WHERE id_customer='{0}'", id), BUKAKONEKSI)
        Dim read As OleDbDataReader = cmd.ExecuteReader

        While read.Read
            txtNama.Text = read.Item(1)
            txtJenkel.Text = read.Item(2)
            txtAlamat.Text = read.Item(3)
            txtNotelp.Text = read.Item(4)
        End While

    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox3.SelectedIndexChanged
        Dim id = ComboBox3.Text
        Dim cmd As New OleDbCommand(String.Format("SELECT * FROM kamar WHERE no_kamar='{0}'", id), BUKAKONEKSI)
        Dim read As OleDbDataReader = cmd.ExecuteReader

        While read.Read
            txtTipe.Text = read.Item(1)
            txtTarif.Text = read.Item(2)
        End While

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim idkaryawan, idcustomer, idkamar As String

        'dtpCheckin.Enabled = False
        'dtpCheckout.Enabled = False

        If ComboBox1.SelectedIndex > -1 And ComboBox2.SelectedIndex > -1 And ComboBox3.SelectedIndex > -1 And txtLama.Text.Length > 0 Then
            Dim subtotal As Integer = Val(txtTarif.Text) * Val(txtLama.Text)
            ListView1.Items.Add(New ListViewItem(New String() {ComboBox3.Text, txtTipe.Text, dtpCheckin.Value, dtpCheckout.Value, txtLama.Text, txtTarif.Text, subtotal.ToString}))
        End If
    End Sub

    Private Sub btnProses_Click(sender As Object, e As EventArgs) Handles btnProses.Click
        'MsgBox(ListView1.Items.Count)
        If ListView1.Items.Count > 0 Then
            Dim total As Integer = 0
            For index As Integer = 0 To ListView1.Items.Count - 1
                total = total + Val(ListView1.Items(index).SubItems(6).Text)
            Next
            txtTotal.Text = total
        End If


    End Sub

    Private Sub txtBayar_TextChanged(sender As Object, e As EventArgs) Handles txtBayar.TextChanged

    End Sub

    Private Sub FormTransaksiKamar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtIdtransaksi.Text = KontrolTransaksiKamar.kodeBaru()

        ListView1.View = View.Details
        ListView1.FullRowSelect = True

        ListView1.Columns.Add("ID Kamar", 100)
        ListView1.Columns.Add("Tipe Kamar", 100)
        ListView1.Columns.Add("Check-in", 100)
        ListView1.Columns.Add("Check-out", 100)
        ListView1.Columns.Add("Lama Inap", 100)
        ListView1.Columns.Add("Tarif", 100)
        ListView1.Columns.Add("Sub Total", 100)


        txtTanggal.Text = Date.Today
        Dim cmd1 As New OleDbCommand("SELECT * FROM karyawan", BUKAKONEKSI)
        Dim read1 As OleDbDataReader = cmd1.ExecuteReader

        While read1.Read()
            ComboBox1.Items.Add(read1.Item(0))
        End While

        Dim cmd2 As New OleDbCommand("SELECT * FROM customer", BUKAKONEKSI)
        Dim read2 As OleDbDataReader = cmd2.ExecuteReader

        While read2.Read()
            ComboBox2.Items.Add(read2.Item(0))
        End While

        Dim cmd3 As New OleDbCommand("SELECT * FROM kamar", BUKAKONEKSI)
        Dim read3 As OleDbDataReader = cmd3.ExecuteReader

        While read3.Read()
            ComboBox3.Items.Add(read3.Item(0))
        End While

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim eTransaksiKamar As New ClsEntTransaksiKamar
        eTransaksiKamar._idtransaksi = txtIdtransaksi.Text
        eTransaksiKamar._idcustomer = ComboBox2.Text
        eTransaksiKamar._idkaryawan = ComboBox1.Text
        eTransaksiKamar._tanggaltransaksi = txtTanggal.Text
        eTransaksiKamar._totalbayar = txtTotal.Text

        KontrolTransaksiKamar.InsertDataTransaksiKamar(eTransaksiKamar)

        For index As Integer = 0 To ListView1.Items.Count - 1
            Dim kodekamar As String = ListView1.Items(index).SubItems(0).Text
            Dim checkin As String = ListView1.Items(index).SubItems(2).Text
            Dim checkout As String = ListView1.Items(index).SubItems(3).Text

            TUTUPKONEKSI()
            Dim Command As New OleDbCommand(String.Format("INSERT INTO item_transaksi_reservasi VALUES ('{0}','{1}','{2}','{3}');", txtIdtransaksi.Text, kodekamar, checkin, checkout), BUKAKONEKSI)
            Command.ExecuteNonQuery()
        Next

        MsgBox("berhasil ditambahkan")

    End Sub

    Private Sub txtBayar_KeyDown(sender As Object, e As KeyEventArgs) Handles txtBayar.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim total As Integer = Val(txtTotal.Text)
            Dim bayar As Integer = Val(txtBayar.Text)
            txtKembali.Text = bayar - total
        End If
    End Sub
End Class