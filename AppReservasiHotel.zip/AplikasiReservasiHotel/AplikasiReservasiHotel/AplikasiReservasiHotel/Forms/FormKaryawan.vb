﻿Public Class FormKaryawan
    Dim modeProses As Integer
    Dim baris As Integer

    Private Sub AturButton(st As Boolean)
        btnAdd.Enabled = st
        btnEdit.Enabled = st
        btnDelete.Enabled = st
        btnSave.Enabled = Not st
        btnCancel.Enabled = Not st
        GroupBox1.Enabled = Not st
        GroupBox2.Enabled = st
        GroupBox3.Enabled = st
    End Sub
    Private Sub IsiBox(br As Integer)
        If br < DTGrid.Rows.Count Then
            With dgKaryawan.Rows(br)
                txtIdKaryawan.Text = .Cells(0).Value.ToString
                txtNama.Text = .Cells(1).Value.ToString
                If rbLaki.Checked = True Then
                    rbLaki.Text = .Cells(2).Value.ToString
                ElseIf rbPerempuan.Checked = True Then
                    rbPerempuan.Text = .Cells(2).Value.ToString
                End If
                txtAlamat.Text = .Cells(3).Value.ToString
                txtNoTelp.Text = .Cells(4).Value.ToString
            End With
            lblBaris.Text = "Data ke-" & br + 1 & " dari " & dgKaryawan.RowCount - 1 & " data"
        End If
    End Sub
    Private Sub RefreshGrid()
        DTGrid = KontrolKaryawan.tampilData.ToTable
        dgKaryawan.DataSource = DTGrid
        If DTGrid.Rows.Count > 0 Then
            baris = DTGrid.Rows.Count - 1
            dgKaryawan.Rows(DTGrid.Rows.Count - 1).Selected = True
            dgKaryawan.CurrentCell = dgKaryawan.Item(1, baris)
            AturButton(True)
            IsiBox(baris)
        End If
    End Sub

    Private Sub TampilCari(kunci As String)
        DTGRID = KontrolKaryawan.cariData(kunci).ToTable
        If DTGRID.Rows.Count > 0 Then
            baris = DTGRID.Rows.Count - 1
            dgKaryawan.DataSource = DTGRID
            dgKaryawan.Rows(DTGRID.Rows.Count - 1).Selected = True
            dgKaryawan.CurrentCell = dgKaryawan.Item(1, baris)
            IsiBox(baris)
        Else
            MsgBox("Data tidak ditemukan")
            RefreshGrid()
        End If

    End Sub
    Private Sub FormKaryawan_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call RefreshGrid()
        txtIdKaryawan.Enabled = False
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        AturButton(False)
        modeProses = 1

        'kosongkan textbox 
        txtNama.Text = ""
        rbLaki.Checked = False
        rbPerempuan.Checked = False
        txtAlamat.Text = ""
        txtNoTelp.Text = ""

        'isi textbox kode dengan memanggil fungsi kodebaru 
        txtIdKaryawan.Text = KontrolKaryawan.kodeBaru

        'posisikan cursor di textbox nama
        txtNama.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        FormMenuUtama.Show()
        Me.Hide()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        AturButton(False)
        txtNama.Focus()
        modeProses = 2
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        RefreshGrid()
        AturButton(True)
        modeProses = 0
    End Sub

    Private Sub dgKaryawan_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgKaryawan.CellClick
        If modeProses = 0 Then
            baris = e.RowIndex
            dgKaryawan.Rows(baris).Selected = True
            IsiBox(baris)
        End If
    End Sub

    Private Sub btnAwal_Click(sender As Object, e As EventArgs) Handles btnAwal.Click
        dgKaryawan.ClearSelection()
        baris = 0
        dgKaryawan.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnNaik_Click(sender As Object, e As EventArgs) Handles btnNaik.Click
        dgKaryawan.ClearSelection()
        If baris > 0 Then baris = baris - 1
        dgKaryawan.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnTurun_Click(sender As Object, e As EventArgs) Handles btnTurun.Click
        dgKaryawan.ClearSelection()
        If baris < DTGRID.Rows.Count - 1 Then baris = baris + 1
        dgKaryawan.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnAkhir_Click(sender As Object, e As EventArgs) Handles btnAkhir.Click
        dgKaryawan.ClearSelection()
        baris = DTGRID.Rows.Count - 1
        dgKaryawan.Rows(baris).Selected = True
        IsiBox(baris)
    End Sub

    Private Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click
        If txtCari.Text = "" Then
            Call RefreshGrid()
        Else
            Call TampilCari(txtCari.Text)
            txtCari.Focus()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        With EntitasKaryawan
            .idKaryawan = txtIdKaryawan.Text
            .namaKaryawan = txtNama.Text
            If rbLaki.Checked = True Then
                .jenkelKaryawan = rbLaki.Text
            ElseIf rbPerempuan.Checked = True Then
                .jenkelKaryawan = rbPerempuan.Text
            End If
            .alamatKaryawan = txtAlamat.Text
            .notelpKaryawan = txtNoTelp.Text
        End With
        If modeProses = 1 Then
            KontrolKaryawan.InsertData(EntitasKaryawan)
        ElseIf modeProses = 2 Then
            KontrolKaryawan.updateData(EntitasKaryawan)
        End If
        MsgBox("Data telah tersimpan", MsgBoxStyle.Information, "info")
        RefreshGrid()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim status_referensi As Boolean
        status_referensi = KontrolKaryawan.cekKaryawanDireferensi(txtIdKaryawan.Text)
        If status_referensi Then
            MsgBox("Data masih digunakan, tidak boleh dihapus", MsgBoxStyle.Exclamation, "Peringatan")
            Exit Sub
        End If
        If MsgBox("Apakah anda yakin akan menghapus " & txtIdKaryawan.Text & "-" & txtNama.Text & " ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
            KontrolKaryawan.deleteData(txtIdKaryawan.Text)
        End If
        RefreshGrid()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class