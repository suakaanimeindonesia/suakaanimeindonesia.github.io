﻿Public Class FormLapCustomer

End Class