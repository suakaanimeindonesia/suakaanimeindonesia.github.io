﻿Public Class ClsEntKaryawan
    Private idk As String
    Private nama As String
    Private jenkel As String
    Private alamat As String
    Private notelp As String

    Public Property idKaryawan() As String
        Get
            Return idk
        End Get
        Set(value As String)
            idk = value
        End Set
    End Property
    Public Property namaKaryawan() As String
        Get
            Return nama
        End Get
        Set(value As String)
            nama = value
        End Set
    End Property
    Public Property jenkelKaryawan() As String
        Get
            Return jenkel
        End Get
        Set(value As String)
            jenkel = value
        End Set
    End Property
    Public Property alamatKaryawan() As String
        Get
            Return alamat
        End Get
        Set(value As String)
            alamat = value
        End Set
    End Property

    Public Property notelpKaryawan() As String
        Get
            Return notelp
        End Get
        Set(value As String)
            notelp = value
        End Set
    End Property
End Class
