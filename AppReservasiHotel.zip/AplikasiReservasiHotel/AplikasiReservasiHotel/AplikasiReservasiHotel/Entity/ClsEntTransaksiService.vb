﻿Public Class ClsEntTransaksiService
    Private idt As String
    Private idp As String
    Private idc As String
    Private nama As String
    Private jenkel As String
    Private alamat As String
    Private notelp As String
    Private ids As String
    Private service As String
    Private harga As Integer
    Private jml As Integer
    Private tgl As String

    Public Property idTransaksi() As String
        Get
            Return idt
        End Get
        Set(value As String)
            idt = value
        End Set
    End Property

    Public Property idKaryawan() As String
        Get
            Return idp
        End Get
        Set(value As String)
            idp = value
        End Set
    End Property

    Public Property idCustomer() As String
        Get
            Return idc
        End Get
        Set(value As String)
            idc = value
        End Set
    End Property

    Public Property namaCustomer() As String
        Get
            Return nama
        End Get
        Set(value As String)
            nama = value
        End Set
    End Property
    Public Property jenkelCustomer() As String
        Get
            Return jenkel
        End Get
        Set(value As String)
            jenkel = value
        End Set
    End Property
    Public Property alamatCustomer() As String
        Get
            Return alamat
        End Get
        Set(value As String)
            alamat = value
        End Set
    End Property

    Public Property notelpCustomer() As String
        Get
            Return notelp
        End Get
        Set(value As String)
            notelp = value
        End Set
    End Property

    Public Property idService() As String
        Get
            Return ids
        End Get
        Set(value As String)
            ids = value
        End Set
    End Property

    Public Property serviceNama() As String
        Get
            Return service
        End Get
        Set(value As String)
            service = value
        End Set
    End Property

    Public Property hargaService() As Integer
        Get
            Return harga
        End Get
        Set(value As Integer)
            harga = value
        End Set
    End Property

    Public Property jmlService() As Integer
        Get
            Return jml
        End Get
        Set(value As Integer)
            jml = value
        End Set
    End Property

    Public Property tglTransaksi() As String
        Get
            Return tgl
        End Get
        Set(value As String)
            tgl = value
        End Set
    End Property
End Class
