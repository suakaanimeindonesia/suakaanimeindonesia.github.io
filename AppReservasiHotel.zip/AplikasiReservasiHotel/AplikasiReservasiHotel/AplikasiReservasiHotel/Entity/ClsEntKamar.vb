﻿Public Class ClsEntKamar
    Private kode As String
    Private tipe As String
    Private tarif As Integer


    Public Property kodeKamar() As String
        Get
            Return kode
        End Get
        Set(value As String)
            kode = value
        End Set
    End Property
    Public Property tipeKamar() As String
        Get
            Return tipe
        End Get
        Set(value As String)
            tipe = value
        End Set
    End Property
    Public Property tarifKamar() As Integer

        Get
            Return tarif
        End Get
        Set(value As Integer)
            tarif = value
        End Set
    End Property
End Class