﻿Public Class ClsEntCustomer
    Private idc As String
    Private nama As String
    Private jenkel As String
    Private alamat As String
    Private notelp As String

    Public Property idCustomer() As String
    Get
        Return idc
    End Get
    Set(value As String)
        idc = value
    End Set
End Property
Public Property namaCustomer() As String
    Get
        Return nama
    End Get
    Set(value As String)
        nama = value
    End Set
End Property
Public Property jenkelCustomer() As String
    Get
        Return jenkel
    End Get
    Set(value As String)
        jenkel = value
    End Set
End Property
Public Property alamatCustomer() As String
    Get
        Return alamat
    End Get
    Set(value As String)
        alamat = value
    End Set
End Property

Public Property notelpCustomer() As String
    Get
        Return notelp
    End Get
    Set(value As String)
        notelp = value
    End Set
End Property
End Class
