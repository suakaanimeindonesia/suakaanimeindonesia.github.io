﻿Public Class ClsEntTransaksiKamar
    Private idtransaksi, idcustomer, tanggaltransaksi, idkaryawan As String
    Private totalbayar As Integer

    Public Property _idtransaksi() As String
        Get
            Return idtransaksi
        End Get
        Set(value As String)
            idtransaksi = value
        End Set
    End Property

    Public Property _idcustomer() As String
        Get
            Return idcustomer
        End Get
        Set(value As String)
            idcustomer = value
        End Set
    End Property

    Public Property _tanggaltransaksi() As String
        Get
            Return tanggaltransaksi
        End Get
        Set(value As String)
            tanggaltransaksi = value
        End Set
    End Property

    Public Property _idkaryawan() As String
        Get
            Return idkaryawan
        End Get
        Set(value As String)
            idkaryawan = value
        End Set
    End Property

    Public Property _totalbayar As Integer
        Get
            Return totalbayar
        End Get
        Set(value As Integer)
            totalbayar = value
        End Set
    End Property

End Class
