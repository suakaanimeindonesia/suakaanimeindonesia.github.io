﻿Public Class ClsEntService
    Private kode As String
    Private nama As String
    Private harga As Integer
    Private jumlah As Integer

    Public Property jumlahService() As Integer
        Get
            Return jumlah
        End Get
        Set(value As Integer)
            jumlah = value
        End Set
    End Property


    Public Property kodeService() As String
        Get
            Return kode
        End Get
        Set(value As String)
            kode = value
        End Set
    End Property
    Public Property namaService() As String
        Get
            Return nama
        End Get
        Set(value As String)
            nama = value
        End Set
    End Property
    Public Property hargaService() As Integer

        Get
            Return harga
        End Get
        Set(value As Integer)
            harga = value
        End Set
    End Property
End Class
