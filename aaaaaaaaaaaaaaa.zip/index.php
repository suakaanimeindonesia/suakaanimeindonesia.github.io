<?php 
    session_start();
  
?>
<!doctype html>
<html style="height:100%" lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=PT+Sans&display=swap" rel="stylesheet">
    <title>Hello, world!</title>
    <style>

    #nav3{
        display:none
    }

    td {

    }

    #sectiondua{
        
        padding-left: 0px;
        padding-right:0px;
        padding-bottom:50px;
    }


    @keyframes slider {
        from {
            transform: translate(350px,0px);
        } to {
            transform: translate(0px,0px);
        }
    }

    @keyframes slideout {
        from {
            transform: translate(0px,0px);
        } to {
            transform: translate(350px,0px);
        }
    }

    .slider {
        animation: slider 0.5s;
    }

    .slideout {
        animation: slideout 0.5s;
    }

    .disabled {
        pointer-events:none;
        opacity:0.5;
    }

    #navbartext{
        font-family: 'Bebas Neue';
       
    }

     #menupilihan:hover{
        background-color:#fee5e0;
    }

    #menupilihan {
        cursor:pointer;
        text-decoration:none;
        font-size:1.8em
    }

    #g2 {
        width: 40vh;
    }

    #kirim2 {
        display:none;
    }

@media screen and (max-width: 1766px) {
  
}



@media screen and (max-width: 1402px) {
  
    

}


@media screen and (max-width: 1200px) {
  
    


}




@media screen and (max-width: 992px) {
  
    
  #gambar2 {
      display:none;
  }

  #gambar3{
      display:none;
  }

  #nav3 {
      display:flex;
  }

  #gambar4 {
      display:none;
  }

   #sectiondua {
       padding-bottom:0px;
   }

    #gambar1 {
       display:none
   }

   #kirim1 {
       display:none
   }
   
   #kirim2 {
       display:block;
   }

   
   #menupilihan {
       display:none
   }

}







   
    </style>
  </head>
  <body>

     <div class="slider" id="rightNavbar" style="position:fixed;background-color:white;z-index:100;padding:50px;height:100%;right:0;display:none;z-index:101">
        <div  style="display:flex;flex-direction:column;justify-content:center;align-items:center;margin-bottom:25px;"><img style="border-radius:200px" src="logo.png"></div>
        <?php
            if(!isset($_SESSION["user"])){
                echo ' <div style="display:flex;flex-direction:column;justify-content:center;align-items:center;border-bottom:solid 2px black">
                <a href="login.php" style="text-decoration:none;color:#212529;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: Bebas Neue, cursive;font-size:2em">LOGIN</a>
                <a href="daftar.php" style="text-decoration:none;color:#212529;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: Bebas Neue, cursive;font-size:2em">DAFTAR</a>
            
            </div>';
            }else{
                echo ' <div style="display:flex;flex-direction:column;justify-content:center;align-items:center;border-bottom:solid 2px black">
                <a href="logout.php" style="text-decoration:none;color:#212529;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: Bebas Neue, cursive;font-size:2em">LOGOUT</a>
            
            </div>';
            }
       ?>
       
        <div id="nav3" style="flex-direction:column;justify-content:center;align-items:center">
            <a href="" style="text-decoration:none;color:#212529;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">HOME</a>
            <div class="tombolcaridata" style="padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">CARI DATA</div>
            <div  class="tomboleditdata"  style="padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">EDIT DATA</div>
            <div  class="tombolberisaran" style="padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">BERI SARAN</div>
        </div>
    </div>

  
  <div id="rNav" style="background-color:#0000006b;width:100%;height:100%;z-index:100;position:fixed;display:none">
 
  </div>
  

  <nav class="container-fluid" style="padding:20px;display:flex;flex-direction:row; justify-content:space-between;align-items:center;background-color: white;z-index: 99;position: fixed;box-shadow: #00000045 1px 1px 30px;">
        <div style="padding-left:20px;"><a href="index.php"><img style="width:3rem;height:3rem" src="logo.png"></a></div>
        <div id="rightContainerNavbar" style="display:flex;flex-direction:row">
        <div id="navbartext" style="display:flex;flex-direction:row;align-items:center;margin-right:20px;">
                <a href="" id="menupilihan" style="padding-right:50px;padding-left:50px;color:#1c1f4c">HOME</a>
                <div id="menupilihan" class="tombolcaridata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">CARI DATA</div>
                <div id="menupilihan" class="tomboleditdata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">EDIT DATA</div>
                <div id="menupilihan" class="tombolberisaran" style="padding-right:50px;padding-left:50px;color:#1c1f4c">BERI SARAN</div>
        </div>
        <img src="https://lippianfamilydentistry.net/wp-content/uploads/2015/11/user-default.png" id="avatar" style="cursor:pointer;background-color:#fee5e0;width:50px;height:50px;border-radius:50px"></img>
        </div>   
    </nav>
    <section class="container-fluid row" style="min-height:100vh;margin:0;padding:0">
        <div class="col-lg-12" style="display:flex;justify-content:center;align-items:center;margin:0;padding:0;padding-top:90px;">
            <div class="row" style="background-color:red;width:100%;margin:0;padding:0;background-color:#fee5e0;">
                <div class="col-lg-7 col-md-12" style="padding:60px;display:flex;flex-direction:column;justify-content:center">
                    <div style="font-size:4em;color:#1c1f4c;font-family: 'Bebas Neue', cursive;letter-spacing: 1px;">EFISIENSIKAN WAKTU <br> ANDA DENGAN <br>DANDAN</div>
                    <div style="margin-top:5px;font-size:1.3em;color:#1c1f4c;font-family: 'PT Sans', sans-serif;">Cari, ubah dan tambah data Stakholder <br>Direktorat KND dalam waktu singkat!</div>
                </div>
                <div class="col-lg-5 col-md-12" style="padding:30px">
                    <img id="gambar1" style="width:100%;height:100%" src="1.png">
                </div>
            </div>
        </div>
    </section>
    <section id="sectiondua" class="container-fluid" style="margin:0">
            <div class="row" style="margin:0;padding:0;">
                <div class="col-lg-6" style="background-color:red;width:100%;padding:0px 0px">
                    <div style="font-size:3em;background-color:#b3dbda;font-family: 'Bebas Neue';padding: 0px 30px;">CARI DATA YANG ANDA BUTUHKAN</div>
                </div>
            </div>
          
            <div class="row" style="margin:0;0px;">
                <div class="col-lg-3 col-md-12 p-0">
                    <div id="gambar2" style="margin-top:25px;padding: 0px 25px"><img id="g2" style="height:100%;width:100%" src="2.png"></div>
                </div>
                <div class="col-lg-9 col-md-12" style="padding:25px 25px">
                    <div style="display:flex;flex-direction:row">
                        <input id="valuecaridata" type="text" style="width:400px;padding:5px;border: solid 2px #1c1f4c">
                        <div id="tombolcaridata" style="border: solid 2px #1c1f4c;border-left:solid 0px;padding-left:20px;padding-right:20px;align-items:center;justify-content:center;display:flex;background-color:#b3dbda;cursor:pointer">CARI</div>
                    </div>
                    <div id="isipencarian">
                        <div class="row" style="padding:10px 0;padding-top:25px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nama Stakeholder</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                        <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Instansi</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                        <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Kantor</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                        <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nomor Telepon</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                        <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nomor Faks</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                        <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Email</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                        <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Website</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                        <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                            <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Contact Person</div>
                            <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">&emsp;</div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <section class="container-fluid" style="padding:0;margin:0;padding-bottom:50px;">
         <div class="row" style="display:flex;justify-content:center;flex-direction:column;width:100%">
                    <div class= "col-lg-6"style="font-size:3em;font-family: 'Bebas Neue';padding-left:30px;padding-right:30px;padding-top:10px;">LAPORKAN DATA YANG BELUM MUTAKHIR</div>
         </div>
         <div class="row" style="padding:0;margin:0">
                 <div class="col-lg-6" style="background-color:#fee5e0;width:100%;padding:20px;padding-left:30px;display:flex;flex-direction:column">
                    <div class="row">
                        <div class="col-lg-5" style="display:flex;flex-direction:row;padding: 0px 10px">
                            <div id="idlaporandata" style="display:none"></div>
                            <div style="display:flex;flex-direction:row;align-items:center"><input id="radiolapordata" type="radio" name="mode" value="rubah"><div style="margin-left:20px;">Perubahan Data</div></div>
                            <div style="display:flex;flex-direction:row;align-items:center;margin-left:25px;"><input id="radiolapordata" type="radio" name="mode" value="tambah"><div style="margin-left:20px;">Penambahan Data</div></div>
                        </div>
                        <div class="col-lg-7" style="display:flex;flex-direction:row;padding: 10px 10px">
                            <input id="laporkandata" type="text" style="width:100%;padding:5px;border: solid 2px #1c1f4c">
                            <div id="klikcarilaporkandata" style="cursor:ponter;border: solid 2px #1c1f4c;border-left:solid 0px;padding-left:20px;padding-right:20px;align-items:center;justify-content:center;display:flex;background-color:white;cursor:pointer">CARI</div>
                        </div>
                    </div>
                </div>
         </div>
         <div class="row" style="padding:0;margin:0">
            <div class="col-lg-6" style="padding:0;margin:0">
            <div style="display:flex;flex-direction:row;padding:25px 25px;">
                        <div style="padding:0px;width:100%;">
                        <div class="row" style="padding:10px 0;padding-top:25px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nama Stakeholder</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">
                        <input id="form_idstakeholder" value="0" type="text" style="width:100%;background-color:none;border:none;outline:none;display:none">
                        <input id="form_namastakeholder" type="text" style="width:100%;background-color:none;border:none;outline:none">
                        </div>
                    </div>
                    <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Instansi</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529"><input id="form_namainstansi" type="text" style="width:100%;background-color:none;border:none;outline:none"></div>
                    </div>
                    <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Kantor</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529"><input id="form_alamatkantor" type="text" style="width:100%;background-color:none;border:none;outline:none"></div>
                    </div>
                    <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nomor Telepon</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529"><input id="form_nomortelepon" type="text" style="width:100%;background-color:none;border:none;outline:none"></div>
                    </div>
                    <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nomor Faks</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529"><input id="form_nomorfaks" type="text" style="width:100%;background-color:none;border:none;outline:none"></div>
                    </div>
                    <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Email</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529"><input id="form_alamatemail" type="text" style="width:100%;background-color:none;border:none;outline:none"></div>
                    </div>
                    <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Website</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529"><input id="form_alamatwebsite" type="text" style="width:100%;background-color:none;border:none;outline:none"></div>
                    </div>
                    <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                        <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Contact Person</div>
                        <div class="col-xl-12 col-12 p-0 m-0" style="border-bottom:solid 2px #212529"><input id="form_contactperson" type="text" style="width:100%;background-color:none;border:none;outline:none"></div>
                    </div>
                    <div class="row" style="padding:18px">
                        <div id="kirimlaporan" style="background-color:#fee5e0;padding:10px 20px;border:solid 2px #212529;cursor:pointer">KIRIM</div>
                    </div>
                        </div>
                       
                    </div>
            
            </div>
            <div class="col-lg-6" style="display:flex;justify-content:flex-end;align-items:flex-end">
                        <div>
                            <img id="gambar3" style="width:400px;height:500px;right:0px;margin-right: 80px;margin-top: -130px;" src="3.png">
                        </div>
            </div>
         <div>
    </section>
    <section class="container-fluid" style="padding:0;margin:0;margin-bottom:30px">
        <div class="row" style="padding:0;margin:0">
            <div class="col-lg-6" style="padding:0;margin:0">
                <div style="font-size:3em;background-color:#b3dbda;font-family: 'Bebas Neue';padding-left:15px;padding-top:10px;padding-right:15px">BERIKAN SARAN UNTUK DANDAN YANG LEBIH BAIK</div>
            </div>
        </div>
        <div class="row" style="padding:0;margin:0">
           <div id="gambar4" class="col-lg-3" style="padding:35px;">
                <img  src="4.png" style="height:100%;width:100%">
           </div>
           <div class="col-lg-4">
                <div style="margin-top:25px;width:100%;height:300px;display:flex;flex-direction:column;padding-left:4px">
                                <textarea style="width:100%;height:100%;border:solid 2px #212529"></textarea>
                                <div id="kirimsaran" style="cursor:pointer;padding:10px 20px;margin-top:15px;background-color:#b3dbda;width:fit-content;border:solid 2px #212529">KIRIM</div>
                           </div>
                       
                      </div>
           </div>
        </div>
    </section>
    <footer class="container-fluid" style="padding:0;margin:0;height:200px">
        <div class="row" style="background-color:#fee5e0;height:100%;padding:0px 30px;margin:0">
            <div class="col-lg-1 col-md-12" style="display:flex;align-items:center"><img src="logo.png"></div>
         
        </div>
    </footer>
  </body>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script>
        document.querySelectorAll(".tombolcaridata")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 725,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tomboleditdata")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 1463,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tombolberisaran")[0].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 2117,
            behavior: 'smooth',
            })
        })



            document.querySelectorAll(".tombolcaridata")[1].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 725,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tomboleditdata")[1].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 1463,
            behavior: 'smooth',
            })
        })

         document.querySelectorAll(".tombolberisaran")[1].addEventListener("click",(e)=>{
            e.preventDefault();
            window.scrollTo({
             top: 2117,
            behavior: 'smooth',
            })
        })


        document.querySelectorAll("#kirimsaran")[0].addEventListener('click',(ee)=>{
            let saran=document.querySelectorAll("textarea")[0].value;
            ee.currentTarget.classList.add("disabled");
            if(saran.length>0){
                let payload = {
                    aksi : "kirimsaran",
                    saran : saran
                }
                let xml = new XMLHttpRequest();
                xml.open("POST","api.php",true);
                xml.onload=function(ev){
                    document.querySelectorAll("#kirimsaran")[0].classList.remove("disabled");
                    if(ev.currentTarget.response==="logindulu"){
                        alert("Login terlebih dahulu!");
                        document.querySelectorAll("#kirimsaran")[0].classList.remove("disabled");
                    }else{
                        if(ev.currentTarget.response==="true"){
                            alert("Saran berhasil ditampung!");
                            document.location.reload();
                            document.querySelectorAll("#kirimsaran")[0].classList.remove("disabled");
                        }else{
                            alert("Terjadi kesalahan saat menampung saran!");
                            document.querySelectorAll("#kirimsaran")[0].classList.remove("disabled");
                        }
                    }
                };
                xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                let p = new URLSearchParams(payload).toString();
                xml.send(p);
            }else{
                alert("Isikan saran!");
                document.querySelectorAll("#kirimsaran")[0].classList.remove("disabled");
            }
        })
        

        document.querySelectorAll("#avatar")[0].addEventListener("click",(e)=>{
            document.querySelectorAll("#rNav")[0].style.display="";
            document.querySelectorAll("#rightNavbar")[0].style.display="";
        })

        document.querySelectorAll("#rNav")[0].addEventListener("click",()=>{
            document.querySelectorAll("#rightNavbar")[0].classList.add("slideout");
            setTimeout(() => {
               
                document.querySelectorAll("#rNav")[0].style.display="none";
            document.querySelectorAll("#rightNavbar")[0].style.display="none";
                document.querySelectorAll("#rightNavbar")[0].classList.remove("slideout");
            }, 300);
        })

        document.querySelectorAll("#kirimlaporan")[0].addEventListener("click",(xx)=>{
            xx.currentTarget.classList.add("disabled");
            let mode = "";
            document.querySelectorAll("#radiolapordata").forEach((a)=>{(a.checked === true ) ? mode=a.value:""; });
            let id = (mode === "rubah") ?  document.querySelectorAll("#form_idstakeholder")[0].value:"0";

            if(mode==="rubah" && id==="0"){
               
                alert("Cari data terlebih dahulu!");
                xx.currentTarget.classList.remove("disabled");
            }
            else{
                if(mode.length>0 && id.length>0){
                    let nama=document.querySelectorAll("#form_namastakeholder")[0].value
                    let instansi=document.querySelectorAll("#form_namainstansi")[0].value
                    let alamatkantor=document.querySelectorAll("#form_alamatkantor")[0].value
                    let nomortelepon=document.querySelectorAll("#form_nomortelepon")[0].value
                    let nomorfaks=document.querySelectorAll("#form_nomorfaks")[0].value
                    let alamatemail=document.querySelectorAll("#form_alamatemail")[0].value
                    let alamatwebsite=document.querySelectorAll("#form_alamatwebsite")[0].value
                    let contactperson=document.querySelectorAll("#form_contactperson")[0].value
                    
                    let payload = {
                        id_stakeholder:id,
                        nama_stakeholder:nama,
                        nama_instansi:instansi,
                        alamat_kantor:alamatkantor,
                        nomor_telepon:nomortelepon,
                        nomor_faks:nomorfaks,
                        alamat_email:alamatemail,
                        alamat_website:alamatwebsite,
                        contact_person:contactperson,
                        mode:mode,
                        aksi:"laporkandata"
                    }

                    let params = new URLSearchParams(payload).toString();

                    if(nama.length>0 && instansi.length>0){
                        let xml = new XMLHttpRequest();
                    xml.open("POST","api.php",true);
                    xml.onload=function(ev){
                        if(ev.currentTarget.response==="true"){
                            alert("Data berhasil direkam!");
                            document.querySelectorAll("#kirimlaporan")[0].classList.remove("disabled");
                            document.location.reload();
                            
                        }else{
                            alert("Login terlebih dahulu!")
                            document.querySelectorAll("#kirimlaporan")[0].classList.remove("disabled");
                        }
                    }
                    xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                    xml.send(params);
                    }else{
                        alert("Isikan data yang diperlukan!");
                        document.querySelectorAll("#kirimlaporan")[0].classList.remove("disabled");
                    }
                    
               
            }
            else{
                alert("Isikan data yang diperlukan!")
                document.querySelectorAll("#kirimlaporan")[0].classList.remove("disabled");
            }
            }
            
          
        })

        document.querySelectorAll("#klikcarilaporkandata")[0].addEventListener("click",(e)=>{
            <?php 
                     if(isset($_SESSION["user"])){
                        echo '
                        mode = "";
                        q = document.querySelectorAll("#laporkandata")[0].value; 
                        document.querySelectorAll("#radiolapordata").forEach((a)=>{(a.checked === true ) ? mode=a.value:""; });
                        e.currentTarget.classList.add("disabled");
                        if(mode.length>0 && q.length>0){
                            let query = q;
                            let xml=new XMLHttpRequest();
                            xml.open("POST","api.php",true);
                            xml.onload=function(ev){    
                                document.querySelectorAll("#klikcarilaporkandata")[0].classList.remove("disabled");
                               let response = JSON.parse(ev.currentTarget.response);
                               if(response!==null){
                                    document.querySelectorAll("#form_idstakeholder")[0].value=response.id_stakeholder;
                                    document.querySelectorAll("#form_namastakeholder")[0].value=response.nama_stakeholder;
                                    document.querySelectorAll("#form_namainstansi")[0].value=response.instansi;
                                    document.querySelectorAll("#form_alamatkantor")[0].value=response.alamat_kantor;
                                    document.querySelectorAll("#form_nomortelepon")[0].value=response.nomor_telepon;
                                    document.querySelectorAll("#form_nomorfaks")[0].value=response.nomor_faks;
                                    document.querySelectorAll("#form_alamatemail")[0].value=response.alamat_email;
                                    document.querySelectorAll("#form_alamatwebsite")[0].value=response.alamat_website;
                                    document.querySelectorAll("#form_contactperson")[0].value=response.contact_person;
                                    
                                  
                                }
                            }
                            xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                            xml.send(`aksi=caridata&nama=${query}`);

                        }else{
                            document.querySelectorAll("#klikcarilaporkandata")[0].classList.remove("disabled");
                            alert("Masukkan nama perusahaan dan jenis laporan!");
                        }

                        ';
                    }else{  
                        echo "alert('Login terlebih dahulu!');";
                      }
            
            ?>
        })


        document.querySelectorAll("#tombolcaridata")[0].addEventListener('click',(e)=>{
            <?php 
                if(isset($_SESSION["user"])){
                    echo '
                        let query=document.querySelectorAll("#valuecaridata")[0].value;
                        if(query.length>0){
                            let xml=new XMLHttpRequest();
                            xml.open("POST","api.php",true);
                            xml.onload=function(ev){
                                e.target.classList.add("disabled");
                                if(ev.currentTarget.response==="null"){
                                    alert("Data tidak ditemukan!");
                                    e.target.classList.remove("disabled");
                                }else{
                                    let decode = JSON.parse(ev.currentTarget.response);
                                    console.log(decode);
                                    document.querySelectorAll("#isipencarian")[0].innerHTML=`
                                    <div class="row" style="padding:10px 0;padding-top:25px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nama Stakeholder</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.nama_stakeholder}</div>
                                </div>
                                <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Instansi</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.instansi}</div>
                                </div>
                                <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Kantor</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.alamat_kantor}</div>
                                </div>
                                <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nomor Telepon</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.nomor_telepon}</div>
                                </div>
                                <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Nomor Faks</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.nomor_faks}</div>
                                </div>
                                <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Email</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.alamat_email}</div>
                                </div>
                                <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Alamat Website</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.alamat_website}</div>
                                </div>
                                <div class="row" style="padding:10px 0;padding-top:10px;margin:0;">
                                    <div class="col-xl-12 col-12 p-0 m-0" style="width:200px;font-weight:bold">Contact Person</div>
                                    <div class="col-xl-4 col-12 p-0 m-0" style="border-bottom:solid 2px #212529">${decode.contact_person}</div>
                                </div>
                                    `;
                                    e.target.classList.remove("disabled");
                                }
                            };
                            xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                            xml.send(`aksi=caridata&nama=${query}`);
                        }else{
                            alert("Isi kueri pencarian!");
                        }
                    ';
                }else{
                    echo "alert('Silakan login terlebih dahulu!');";
                } 
            ?>
        })
    </script>
</html>