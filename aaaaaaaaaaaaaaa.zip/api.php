<?php
session_start();

if(isset($_POST["aksi"]) && isset($_SESSION["user"])){
         include "koneksi.php";

         if($_POST["aksi"]=="kirimsaran"){
            $saran = $_POST["saran"];
            $hasil = $conn->query("INSERT INTO saran VALUES (NULL,'$saran');");
            if($hasil){
                echo "true";
            }else{
                echo "false";
            }
         }

         if($_POST["aksi"]=="laporkandata"){
            $id_stakeholder = $_POST["id_stakeholder"];
            $nama_stakeholder = $_POST["nama_stakeholder"];
            $nama_instansi = $_POST["nama_instansi"];
            $alamat_kantor = $_POST["alamat_kantor"];
            $nomor_telepon = $_POST["nomor_telepon"];
            $nomor_faks = $_POST["nomor_faks"];
            $alamat_email = $_POST["alamat_email"];
            $alamat_website = $_POST["alamat_website"];
            $contact_person = $_POST["contact_person"];
            $mode = $_POST["mode"];

            if($mode=="rubah"){
                $t = "perubahan";
            }
            else{
                $t = "penambahan";
            }

            $tgl=date(DATE_RFC822);
            $aaa=file_get_contents("https://api.telegram.org/bot1061091797:AAEva4aS5NXt5Jmi7OCtDkP6aSGjC4IE62w/sendMessage?chat_id=1025955575&text=$tgl - Terdapat laporan $t masuk pada database!");

            $hasil=$conn->query("INSERT INTO laporandata VALUES (NULL,$id_stakeholder,'$nama_stakeholder','$nama_instansi','$alamat_kantor','$nomor_telepon','$nomor_faks','$alamat_email','$alamat_website','$contact_person','$mode')");
            if($hasil){
                echo "true";
            }else{
                echo "false";
            }
        }


        if($_POST["aksi"]=="caridata"){
            $stake = $_POST["nama"];
            $q = $conn->query("SELECT * FROM stakeholder WHERE nama_stakeholder LIKE '%$stake%'");
            if($q->num_rows>0){
                $value = $q->fetch_assoc();
                echo json_encode($value);
            }else{
                echo "null";
            }
        }
    }else{
        echo "logindulu";
    }

    ?>