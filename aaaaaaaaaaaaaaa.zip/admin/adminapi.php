<?php
session_start();

if(isset($_POST["aksi"]) && isset($_SESSION["admin"])){
    include "../koneksi.php";


    if($_POST["aksi"]=="hapuslaporan"){
        $id = $_POST["id"];
        $hasil=$conn->query("DELETE FROM laporandata WHERE id_laporandata=$id");
        if($hasil){
            echo "true";
        }else{
            echo "false";
        }
    }


    if($_POST["aksi"]=="proseslaporan"){
        $id = $_POST["id"];
        $calonganti = $conn->query("SELECT * FROM laporandata WHERE id_laporandata=$id")->fetch_assoc();
        if($calonganti["mode"]=="tambah"){
            $id_stakeholder = $calonganti["id_stakeholder"];
            $nama_stakeholder = $calonganti["nama_stakeholder"];
            $nama_instansi = $calonganti["instansi"];
            $alamat_kantor = $calonganti["alamat_kantor"];
            $nomor_telepon = $calonganti["nomor_telepon"];
            $nomor_faks = $calonganti["nomor_faks"];
            $alamat_email = $calonganti["alamat_email"];
            $alamat_website = $calonganti["alamat_website"];
            $contact_person = $calonganti["contact_person"];

            $hasil=$conn->query("INSERT INTO stakeholder VALUES (NULL,'$nama_stakeholder','$nama_instansi','$alamat_kantor','$nomor_telepon','$nomor_faks','$alamat_email','$alamat_website','$contact_person')");
            if($hasil){
                $conn->query("DELETE FROM laporandata WHERE id_laporandata=$id");
                echo "true";
            }else{
                echo "false";
            }

    
        }else{
            $id_stakeholder = $calonganti["id_stakeholder"];
            $nama_stakeholder = $calonganti["nama_stakeholder"];
            $nama_instansi = $calonganti["instansi"];
            $alamat_kantor = $calonganti["alamat_kantor"];
            $nomor_telepon = $calonganti["nomor_telepon"];
            $nomor_faks = $calonganti["nomor_faks"];
            $alamat_email = $calonganti["alamat_email"];
            $alamat_website = $calonganti["alamat_website"];
            $contact_person = $calonganti["contact_person"];

            $hasil=$conn->query("UPDATE stakeholder SET nama_stakeholder='$nama_stakeholder',instansi='$nama_instansi',alamat_kantor='$alamat_kantor',nomor_telepon='$nomor_telepon',nomor_faks='$nomor_faks',alamat_email='$alamat_email',alamat_website='$alamat_website',contact_person='$contact_person' WHERE id_stakeholder=$id_stakeholder;");
            if($hasil){
                $conn->query("DELETE FROM laporandata WHERE id_laporandata=$id");
                echo "true";
            }else{
                echo "false";
            }
        }
    }


    if($_POST["aksi"]=="hapusdata"){
        $id = $_POST["id"];
        $hasil=$conn->query("DELETE FROM stakeholder WHERE id_stakeholder=$id");
        if($hasil){
            echo "true";
        } else{
            echo "false";
        }
    }

    if($_POST["aksi"]=="ubahdata"){
        $id_stakeholder = $_POST["idstakeholder"];
        $nama_stakeholder = $_POST["namastakeholder"];
        $nama_instansi = $_POST["instansi"];
        $alamat_kantor = $_POST["alamatkantor"];
        $nomor_telepon = $_POST["nomortelepon"];
        $nomor_faks = $_POST["nomorfaks"];
        $alamat_email = $_POST["alamatemail"];
        $alamat_website = $_POST["alamatwebsite"];
        $contact_person = $_POST["contactperson"];

        $hasil=$conn->query("UPDATE stakeholder SET nama_stakeholder='$nama_stakeholder',instansi='$nama_instansi',alamat_kantor='$alamat_kantor',nomor_telepon='$nomor_telepon',nomor_faks='$nomor_faks',alamat_email='$alamat_email',alamat_website='$alamat_website',contact_person='$contact_person' WHERE id_stakeholder=$id_stakeholder;");
        if($hasil){
            echo "true";
        }else{
            echo "false";
        }

    }

    if($_POST["aksi"]=="tambahdata"){
        $id_stakeholder = $_POST["idstakeholder"];
        $nama_stakeholder = $_POST["namastakeholder"];
        $nama_instansi = $_POST["instansi"];
        $alamat_kantor = $_POST["alamatkantor"];
        $nomor_telepon = $_POST["nomortelepon"];
        $nomor_faks = $_POST["nomorfaks"];
        $alamat_email = $_POST["alamatemail"];
        $alamat_website = $_POST["alamatwebsite"];
        $contact_person = $_POST["contactperson"];

        $hasil=$conn->query("INSERT INTO stakeholder VALUES (NULL,'$nama_stakeholder','$nama_instansi','$alamat_kantor','$nomor_telepon','$nomor_faks','$alamat_email','$alamat_website','$contact_person')");
        if($hasil){
            echo "true";
        }else{
            echo "false";
        }

    }
}

?>