<?php
    session_start();

    include "../koneksi.php";
    if(!isset($_SESSION["admin"])){
        Header("Location: index.php");
    }
?>



<!doctype html>
<html style="height:100%" lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=PT+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.16.0/dist/bootstrap-table.min.css">
    <title>Hello, world!</title>
    <style>
    #navbartext{
        font-family: 'Bebas Neue';
       
    }

     #menupilihan:hover{
        background-color:#fee5e0;
    }

    #menupilihan {
        cursor:pointer;
        text-decoration:none;
        font-size:1.8em
    }

    @keyframes slider {
        from {
            transform: translate(350px,0px);
        } to {
            transform: translate(0px,0px);
        }
    }

    @keyframes slideout {
        from {
            transform: translate(0px,0px);
        } to {
            transform: translate(350px,0px);
        }
    }

    .slider {
        animation: slider 0.5s;
    }

    .slideout {
        animation: slideout 0.5s;
    }

@media screen and (max-width: 1000px) {
   #gambar1 {
       display:none
   }
   #menupilihan {
       display:none
   }
}

   
    </style>
  </head>
  <body style="height:100%">


     <div class="slider" id="rightNavbar" style="position:fixed;background-color:white;z-index:100;padding:50px;height:100%;right:0;display:none;z-index:101">
    

        <div id="nav3" style="display:flex;flex-direction:column;justify-content:center;align-items:center">
            <a href="dashboard.php" class="tombolcaridata" style="text-decoration:none;color:#1c1f4c;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">Stakeholder</a>
            <a  href="laporan.php" class="tomboleditdata"  style="text-decoration:none;color:#1c1f4c;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">Laporan</a>
            <a  href="saran.php" class="tombolberisaran" style="text-decoration:none;color:#1c1f4c;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">Saran</a>
            <a  href="../logout.php" class="tombolberisaran" style="text-decoration:none;color:#1c1f4c;padding:10px 35px;width:200px;margin-bottom:10px;text-align:center;cursor:pointer;font-family: 'Bebas Neue', cursive;font-size:2em">Keluar</a>
        </div>
    </div>

  
  <div id="rNav" style="background-color:#0000006b;width:100%;height:100%;z-index:100;position:fixed;display:none">
 
  </div>

  <div style="height:100%">


 <div class="container-fluid" style="padding:20px;display:flex;flex-direction:row; justify-content:space-between;align-items:center;background-color: white;
    z-index: 99;
    position: fixed;
    box-shadow: #00000045 1px 1px 30px;">
        <div style="padding-left:20px;"><a href="../index.php"><img style="width:3rem;height:3rem" src="../logo.png"></a></div>
        <div id="rightContainerNavbar" style="display:flex;flex-direction:row">

         <div id="navbartext" style="display:flex;flex-direction:row;align-items:center;margin-right:20px;">
                <a href="dashboard.php" id="menupilihan" class="tombolcaridata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">Stakeholder</a>
                <a href="laporan.php" id="menupilihan" class="tomboleditdata" style="padding-right:50px;padding-left:50px;color:#1c1f4c">Laporan</a>
                <a href="saran.php" id="menupilihan" class="tombolberisaran" style="padding-right:50px;padding-left:50px;color:#1c1f4c">Saran</a>
        </div>
        <img src="https://image.flaticon.com/icons/png/512/40/40031.png" id="avatar" style="cursor:pointer;background-color:#fee5e0;width:50px;height:50px;border-radius:50px"></img>
        </div>
        
       
    </div>

    <div style="height:100%;width:100%;padding-top:120px;padding-bottom:20px;padding-left:20px;padding-right:20px;">
        <div class="row p-0 m-0" style="width:100%">
            <div class="col-lg-4" style="padding-bottom:20px;">
               <div  style="width:100%;box-shadow:#0000003b 1px 1px 10px;padding:25px">
                    <div class="form-group">
                        <label for="exampleInputPassword1">ID Stakeholder</label>
                        <input type="text"  readonly class="form-control" id="form_idstakeholder" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Nama Stakeholder</label>
                        <input type="text"  class="form-control" id="form_namastakeholder" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Instansi</label>
                        <input type="text"  class="form-control" id="form_instansi" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Alamat Kantor</label>
                        <input type="text"  class="form-control" id="form_alamatkantor" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Nomor Telepon</label>
                        <input type="text"  class="form-control" id="form_nomortelepon" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Nomor Faks</label>
                        <input type="text"  class="form-control" id="form_nomorfaks" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Alamat Email</label>
                        <input type="text"  class="form-control" id="form_alamatemail" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Alamat Website</label>
                        <input type="text"  class="form-control" id="form_alamatwebsite" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Contact Person</label>
                        <input type="text"  class="form-control" id="form_contactperson" >
                    </div>
                    <div class="form-group" style="margin-top:25px;">
                        <button id="tombolTambah" class="btn btn-primary ">Tambah</button>
                        <button id="tombolUbah" class="btn btn-primary ">Ubah</button>
                    </div>
               </div>
            </div>
            <div class="col-lg-8" style="margin-bottom:35px">
                <div style="width:100%;box-shadow:#0000003b 1px 1px 10px;padding:25px">
                <table id="table"></table>
                </div>
            </div>
        </div>
    </div>
   
  </body>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/bootstrap-table@1.16.0/dist/bootstrap-table.min.js"></script>
    
    <script>
       
       document.querySelectorAll("#avatar")[0].addEventListener("click",(e)=>{
            document.querySelectorAll("#rNav")[0].style.display="";
            document.querySelectorAll("#rightNavbar")[0].style.display="";
        })

        document.querySelectorAll("#rNav")[0].addEventListener("click",()=>{
            document.querySelectorAll("#rightNavbar")[0].classList.add("slideout");
            setTimeout(() => {
               
                document.querySelectorAll("#rNav")[0].style.display="none";
            document.querySelectorAll("#rightNavbar")[0].style.display="none";
                document.querySelectorAll("#rightNavbar")[0].classList.remove("slideout");
            }, 300);
        })

        <?php 
            $arr=array();
            $hasil=$conn->query("SELECT * FROM stakeholder;");
            while($f = $hasil->fetch_assoc()){
                array_push($arr,$f);
            }
            echo "data=".json_encode($arr);
        ?>


       $('#table').bootstrapTable({
  pagination: true,
  search: true,
  columns: [{
    field: 'id_stakeholder',
    title: 'ID Stakeholder'
  }, {
    field: 'nama_stakeholder',
    title: 'Nama Stakeholder'
  }, {
    field: 'instansi',
    title: 'Instansi'
  }, {
    field: 'alamat_kantor',
    title: 'Alamat Kantor'
  }, {
    field: 'nomor_telepon',
    title: 'Nomor Telepon'
  }, {
    field: 'nomor_faks',
    title: 'Nomor Faks'
  }, {
    field: 'alamat_email',
    title: 'Alamat Email'
  }, {
    field: 'alamat_website',
    title: 'Alamat Website'
  }, {
    field: 'contact_person',
    title: 'Contact Person'
  },
  {
                  field: 'operate',
                  title: 'Edit',
                  align: 'center',
                  valign: 'middle',
                  clickToSelect: false,
                  formatter : function(value,row,index) {
                    //return '<input name="elementname"  value="'+value+'"/>';
                    return '<button class=\'btn btn-primary \' id="tombolEdit" data-idstake='+row.id_stakeholder+' data-index='+index+'>Edit</button><button id="tombolHapus" class=\'btn btn-danger \' data-idstake='+row.id_stakeholder+' data-index="'+index+'">Hapus</button> ';
                  }
                }],
  data: data
})      

        $(document).on("click","#tombolHapus",(e)=>{
            let idstake = e.target.getAttribute("data-idstake");

            let payload = {
                id:idstake,
                aksi:"hapusdata"
            }

            let query = new URLSearchParams(payload).toString();

            let xml = new XMLHttpRequest();
                xml.open("POST","adminapi.php",true);
                xml.onload = function (ev){
                    if(ev.currentTarget.response==="true"){
                        alert("Berhasil menghapus data!");
                        document.location.reload();
                    }
                    else{
                        alert("Gagal menghapus data!");
                    }
                }
                xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                xml.send(query);

        })

         $(document).on("click","#tombolUbah",(e)=>{
            let idstakeholder= document.querySelector("#form_idstakeholder").value
            let namastakeholder = document.querySelector("#form_namastakeholder").value
            let instansi = document.querySelector("#form_instansi").value
            let alamatkantor =document.querySelector("#form_alamatkantor").value
            let nomortelepon = document.querySelector("#form_nomortelepon").value
            let nomorfaks = document.querySelector("#form_nomorfaks").value
            let alamatemail = document.querySelector("#form_alamatemail").value
            let alamatwebsite = document.querySelector("#form_alamatwebsite").value
            let contactperson = document.querySelector("#form_contactperson").value
            
            if(idstakeholder.length>0){
                let payload = {
                    idstakeholder,
                    namastakeholder,
                    instansi,
                    alamatkantor,
                    nomortelepon,
                    nomorfaks,
                    alamatemail,
                    alamatwebsite,
                    contactperson,
                    aksi:"ubahdata"
                }

                let query = new URLSearchParams(payload).toString();

                let xml = new XMLHttpRequest();
                xml.open("POST","adminapi.php",true);
                xml.onload = function (ev){
                    if(ev.currentTarget.response==="true"){
                        alert("Berhasil mengubah data!");
                        document.location.reload();
                    }
                    else{
                        alert("Gagal mengubah data!");
                    }
                }
                xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                xml.send(query);

            }else{
                alert("Pilih data yang ingin diubah!");
            }
         })
         
        $(document).on("click","#tombolTambah",(e)=>{
           let idstakeholder= document.querySelector("#form_idstakeholder").value
            let namastakeholder = document.querySelector("#form_namastakeholder").value
            let instansi = document.querySelector("#form_instansi").value
            let alamatkantor =document.querySelector("#form_alamatkantor").value
            let nomortelepon = document.querySelector("#form_nomortelepon").value
            let nomorfaks = document.querySelector("#form_nomorfaks").value
            let alamatemail = document.querySelector("#form_alamatemail").value
            let alamatwebsite = document.querySelector("#form_alamatwebsite").value
            let contactperson = document.querySelector("#form_contactperson").value

            if(namastakeholder.length>0 && instansi.length>0){
                let payload = {
                    idstakeholder,
                    namastakeholder,
                    instansi,
                    alamatkantor,
                    nomortelepon,
                    nomorfaks,
                    alamatemail,
                    alamatwebsite,
                    contactperson,
                    aksi:"tambahdata"
                }

                let query = new URLSearchParams(payload).toString();

      

                let xml = new XMLHttpRequest();
                xml.open("POST","adminapi.php",true);
                xml.onload = function (ev){
                    if(ev.currentTarget.response==="true"){
                        alert("Berhasil menambahkan data!");
                        document.location.reload();
                    }
                    else{
                        alert("Gagal menambahkan data!");
                    }
                }
                xml.setRequestHeader("content-type","application/x-www-form-urlencoded");
                xml.send(query);

            }else{
                alert("Masukkan data!");
            }
        })

        $(document).on("click","#tombolEdit",(e)=>{
            let index = e.target.getAttribute("data-index");
            let idstake = e.target.getAttribute("data-idstake");
            let el = data.filter((row)=>{
                return row.id_stakeholder===idstake;
            })[0];

            document.querySelector("#form_idstakeholder").value=idstake;
            document.querySelector("#form_namastakeholder").value=el.nama_stakeholder;
            document.querySelector("#form_instansi").value=el.instansi;
            document.querySelector("#form_alamatkantor").value=el.alamat_kantor;
            document.querySelector("#form_nomortelepon").value=el.nomor_telepon;
            document.querySelector("#form_nomorfaks").value=el.nomor_faks;
            document.querySelector("#form_alamatemail").value=el.alamat_email;
            document.querySelector("#form_alamatwebsite").value=el.alamat_website;
            document.querySelector("#form_contactperson").value=el.contact_person;
        })


    </script>
</html>