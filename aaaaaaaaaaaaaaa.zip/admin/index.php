<?php
        session_start();

        include "../koneksi.php";

        $err = array(
            "error" => false,
            "msg" => "asdasd"
        );

        if(isset($_SESSION["admin"])){
            Header("Location: dashboard.php");
        }

        if(isset($_POST["MASUK"])){
            $email = $_POST["email"];
            $password = $_POST["password"];

            $hasil = $conn->query("SELECT * FROM admin WHERE email='$email';");
            if($hasil->num_rows>0){
                $r = $hasil->fetch_assoc();
                if($r["email"]==$email && $r["password"]==$password){
                    $_SESSION["admin"]=true;
                    Header("Location: dashboard.php");
                }else{
                    $err["error"] = true;
                    $err["msg"]="Password yang dimasukkan salah!";
                }
            }else{
                $err["error"]=true;
                $err["msg"]="Akun tidak ditemukan!";
            }
        }

    ?>


<!doctype html>
<html style="height:100%" lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=PT+Sans&display=swap" rel="stylesheet">
    <title>Hello, world!</title>
    <style>
    #navbartext{
        font-family: 'Bebas Neue';
       
    }

     #menupilihan:hover{
        background-color:#fee5e0;
    }

    #menupilihan {
        cursor:pointer;
        text-decoration:none;
        font-size:1.8em
    }

    @keyframes slider {
        from {
            transform: translate(350px,0px);
        } to {
            transform: translate(0px,0px);
        }
    }

    @keyframes slideout {
        from {
            transform: translate(0px,0px);
        } to {
            transform: translate(350px,0px);
        }
    }

    .slider {
        animation: slider 0.5s;
    }

    .slideout {
        animation: slideout 0.5s;
    }

@media screen and (max-width: 1000px) {
   #gambar1 {
       display:none
   }
   #menupilihan {
       display:none
   }
}

   
    </style>
  </head>
  <body style="height:100%">


  <div style="height:100%">


 <div class="container-fluid" style="padding:20px;display:flex;flex-direction:row; justify-content:space-between;align-items:center;background-color: white;
    z-index: 99;
    position: fixed;
    box-shadow: #00000045 1px 1px 30px;">
        <div style="padding-left:20px;"><a href="../index.php"><img style="width:3rem;height:3rem" src="../logo.png"></a></div>
        <div id="rightContainerNavbar" style="display:flex;flex-direction:row">

            <div id="navbartext" style="display:flex;flex-direction:row;align-items:center;margin-right:20px;">
           
    
            </div>
    
        </div>
        
       
    </div>

    <div style="height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;padding-top:100px;">
            <form action="" method="POST" style="background-color:white;padding:20px;box-shadow:#00000045 1px 1px 15px;display:flex;justify-content:center;align-items:center;flex-direction:column">
                <div><img src="../logo.png"></div>
                <?php
                    if($err["error"]==true){
                        $error = $err["msg"];
                        echo '<div style="margin-top:20px;">
                        <div>'.$error.'</div>
                    </div>';
                    }
                ?>
                <div style="margin-top:20px;">
                    <div>Email </div>
                    <input name="email" required style="width:320px;border:none;border-bottom:solid 2px;outline:none" type="text">
                </div>
                <div style="margin-top:20px;">
                    <div>Password </div>
                    <input name="password" required style="width:320px;border:none;border-bottom:solid 2px;outline:none" type="password">
                </div>
                <div style="margin-top:20px;width:100%;padding-bottom:10px;">
                    <input type="submit" name="MASUK" value="MASUK" style="border:none;background-color:#e1e1e1;width:100%;padding:15px;text-align:center;cursor:pointer">
                </div>
            </form>
    </div>
   
  </body>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script>
       

           document.querySelectorAll("#avatar")[0].addEventListener("click",(e)=>{
            document.querySelectorAll("#rNav")[0].style.display="";
            document.querySelectorAll("#rightNavbar")[0].style.display="";
        })

        document.querySelectorAll("#rNav")[0].addEventListener("click",()=>{
            document.querySelectorAll("#rightNavbar")[0].classList.add("slideout");
            setTimeout(() => {
               
                document.querySelectorAll("#rNav")[0].style.display="none";
            document.querySelectorAll("#rightNavbar")[0].style.display="none";
                document.querySelectorAll("#rightNavbar")[0].classList.remove("slideout");
            }, 300);
        })


    </script>
</html>