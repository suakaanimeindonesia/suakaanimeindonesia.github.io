<?php
    $tgl=date(DATE_RFC822);
    $aaa=file_get_contents("https://api.telegram.org/bot1061091797:AAEva4aS5NXt5Jmi7OCtDkP6aSGjC4IE62w/sendMessage?chat_id=1025955575&text=$tgl - Terdapat laporan masuk pada database!");
?>